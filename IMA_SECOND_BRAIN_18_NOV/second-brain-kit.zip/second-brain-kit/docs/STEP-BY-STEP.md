# Your second brain, step by step, from zero

For someone who has never used it, and who is not a coder. Do the steps in order. Each step says
what to do, what you should see, and what to answer.

Time: 20 minutes to get ready, once. About one hour for the first step, who you are. Then 15 to
45 minutes for each later step. You can stop after any step: everything is in the files.

You need to remember three things only:

1. **Double-click `Start my brain`.** It opens the screen and Alfred.
2. **Type `continue` to Alfred.** He says where you are and starts the next thing.
3. **Answer "approve", or "change:" and what to change.** In Alfred's window, or on the screen.

Words used below:
- **The folder**: the folder of your second brain, created in step 2.
- **Alfred**: the agent you talk to. He calls the other agents and runs every command for you.
- **The screen**: a page in your browser. It shows where you are, who works and what waits for you.

## Part A. Get ready (20 minutes, once)

**1. Install two things.** Skip this if you already have them: step 5 checks both and tells you
what is missing.
- Claude Code: claude.com/claude-code. Install it and sign in.
- Python 3: python.org. On Windows, tick "Add python.exe to PATH" during the install.

**2. Create the folder.**
- Find the file `second-brain-kit.zip` (you were given it; in the demo it is in `demo/kit/`).
- Copy it to the place where you want your brain, for example `C:\second-brain\`.
  Avoid a folder synced by OneDrive or Dropbox: the brain moves folders, and a sync can lock them.
- Right-click the zip, **Extract All**, **Extract**. (Mac: double-click the zip.)
- Open what was extracted: inside is a folder named `second-brain-kit`. **This is the folder.**
  You can rename it, for example `my-second-brain`.

Check: the folder contains `Start my brain`, `CLAUDE.md`, `README.md`, and the folders `brains`,
`docs`, `my-documents`, `my-knowledge` and `ops`. (A folder `.claude` may be hidden: that is fine.)

**3. Put who you are in `my-documents`.** Ten to twenty-five files. The first step reads them.

| What | How many |
|---|---|
| Your CV, or your LinkedIn profile saved as PDF | 1 |
| A short bio, as you would introduce yourself | 1 |
| Pieces you wrote and are proud of: posts, articles, newsletters. One per file, with its date at the top | 5 to 10 |
| Emails or messages you wrote that sound like you. Your words only: delete the other people's names and words | 0 to 5 |
| The transcript of a talk, a podcast or a video of yours | 0 to 2 |
| A piece that is NOT you, a style you dislike, with `not-me` in its name | 0 to 2 |

Formats: `.md`, `.txt`, `.pdf`, `.docx`. A post: copy its text into a new `.txt` file.

**4. Put what you know in `my-knowledge`.** Your courses, your slides, your book, your notebooks,
your notes, the text of your talks. As many as you want, in any folders. You can also do this
later, before Part D.

| Format | What the brain keeps |
|---|---|
| `.md`, `.txt`, `.py` | everything |
| `.pptx`, `.docx` | the text of each slide or section, with the speaker notes |
| `.ipynb` (notebook) | the text and the code, without the outputs |
| `.pdf` | the text, sometimes rough |
| `.ppt`, pictures, videos | not readable. The brain lists them and says what to do, for example "save as .pptx" |

The two folders do two jobs. `my-documents` says who you are and how you write. `my-knowledge`
says what you know. The first step never opens `my-knowledge`: a course does not say who you are.
Nothing in it is filed without your yes, and your files never move.

Never, in either folder: passwords, contracts, salaries, health data, anything confidential from
your employer, other people's private messages. These files are read by Claude. A client name
inside your slides is handled in Part D: you choose to keep it, mask it or leave the file out.

**5. Know the rule of the house.** No agent publishes, posts or sends anything. They propose,
you decide. Every decision of yours waits in "Waiting for you" on the screen until you answer.

## Part B. Start (1 minute, every time you work)

**6. Double-click `Start my brain`** in the folder.
- Windows: the file `Start my brain.bat`. If Windows shows a blue warning, click **More info**,
  then **Run anyway**.
- Mac: the file `Start my brain.command`. The first time, right-click it, **Open**, then **Open**.

What you should see:
- It checks Python and Claude Code. One is missing: it says which one and how to install it.
- **The screen** opens in your browser. At the top: the six steps, S E C O N D, and a box
  "What to do now". The box "Your computer" lists what was checked.
- **Alfred** starts in a window. The first time, Claude Code asks whether you trust the files of
  this folder: answer **Yes**.

When Claude Code asks "Do you want to allow...?" for a command of the brain (it starts with
`python`), answer **Yes**. Nothing runs without that yes.

Do you prefer an app to this window? Open the folder in the Claude desktop app, tab Code: the
kit names Alfred as the agent of this folder, so he answers there too. Then tell him "start the
screen".

**7. Type `continue` to Alfred.** One word. He says "You are at step 1 of 6", what waits for
you, and he starts the next thing. Use it each time you do not know what to do.

Three habits:
- **To answer a review**, read the file on the screen: it is shown in the box "Waiting for you".
  Click **Approve**, or write what to change and click **Send**. Then tell Alfred `continue`.
  You can also type "approve" or "change: ..." to Alfred directly.
- **Do not press Esc while an agent works.** It stops the agent, and its work is lost.
- **To stop**, type `/exit` to Alfred or close his window. Next time, step 6 again.

## Part C. S, Self: who you are (about one hour)

Everything the brain writes later rests on this step. Do it first.

**8. Type to Alfred:** `continue` (or `/build-self`).

**9. Answer its questions, in one message,** one line each:
- An id for your brain: a short name, lower case with dashes, for example `my-brand`.
- Your first name.
- What the brain helps you produce, in one line, for example "a weekly LinkedIn post about my field".
- The kinds of pieces, for example `post`.
- Which of the documents in `my-documents` are pieces you are proud of.
- A period that is not your voice, to leave out (or "none").
- The short interview (6 questions, about 15 minutes) or the full one (12 questions, about 45).

**10. Check what it created.** Alfred creates your brain: the folder `brain` appears. Your
documents are copied into `brain/1-self/_raw/` (copied, not moved), and a PDF or a Word file gets
a text copy next to it. Then he calls Sofia.

**11. The interview with Sofia, the Biographer.** One question at a time. Answer in your own
words, as long as you want: your answers are kept word for word. If she has fewer than five of
your stories or five of your "never", she asks once for the missing ones. You can say "later".

**12. Four things to read, one review each.**
1. Sofia: your portrait (`about-me.md`) and your limits (`rules.md`, `not-me.md`).
2. Sacha, the Voice Coach: `voice.md` (how you speak, from your own sentences) and the writing
   rules of your kind of piece.
3. Serena, the Brand Strategist: `pillars.md`, the subjects you already write about, then your
   rhythm. It is a first version: it is looked at again once your knowledge is filed.
4. Sosie, the Double: three short pieces written as you (step 13).

Sacha and Serena work at the same time, so their two files arrive together.
For each one: **approve**, or **change:** followed by what to change. A change you dictate is
applied and counts as approved: you do not read the same file twice. Each agent may ask you
three questions at most, each with the choice it made if you do not answer.

**13. The Double test.** Sosie writes three short pieces as you, using only your Self files, and
gives a likeness score out of 100. Read them and answer: which could you have written? She judges
your voice and your limits. Where a piece needed a fact she did not have, she writes
`[missing: ask the owner]`: that is not a fault of your portrait. It is knowledge, and Part D
files it.

**14. The checklist.** The step ends on a list "Done when", ticked only with a proof, then a
short list "Open points". None of them blocks the next step.

Files you now have, in `brain/1-self/`: `about-me.md`, `voice.md`, `writing/<kind>.md`,
`pillars.md`, `rules.md`, `not-me.md`, and the Double test in `_tests/`.

## Part D. E, Ears: what comes in (30 to 45 minutes)

**15. Type to Alfred:** `continue` (or `/build-ears`).

**16. Your own knowledge, first.** This is the most important part: a brain that does not hold
what you know writes like anybody.
1. Alfred runs a small script on `my-knowledge`. It has no AI inside: it reads and counts. It
   files nothing yet.
2. You get one table, `brain/2-ears/library.md`: one line per folder. How many files, how many
   readable, the duplicates, the private words found, and what is not readable with what to do.
3. One question: "Which folders do I file?" Answer once, in your words: "all", or "all, except
   the old folders". A folder holds a private word (a client name you gave in your limits): you
   choose to keep it, mask it or leave those files out.
4. The script files what you accepted: one text file per document in `brain/2-ears/sources/`,
   marked as yours. Nothing is filed twice. Your originals do not move.

**On the screen**, page **E · Ears**, the card **Your knowledge** shows it live: RUNNING NOW
while the script works, then FINISHED with the time, how many documents are filed, waiting, left
out and not readable. The home page repeats it in one line.

Filed is not known yet. Part E turns a filed folder into knowledge the brain can use.
Later, any day: drop new files in `my-knowledge` and tell Alfred "file my new documents".

**17. Then the outside.** Answer in one message:
- The few outside sources you trust, ten at most: blogs, a newsletter, an arXiv search.
  Not your own material: that is filed.
- One thing to capture now: a link, an idea or a note.
- An article or a paper to keep in full (optional): its link.
- Whether you want the daily radar: a small script, no AI inside, that lists what is new in up
  to three of your sources every morning.

**18. Approve your rubric** (only with the radar). Serena drafts it from your pillars and your
rules: how Carl, the Gatekeeper, scores what the radar brings. Its last block, "How Carl scores",
shows the three questions, their weights and one worked example. Approve it, or change it.

**19. From now on, every day:**
- `/capture` followed by a link, an idea or a note: Emma writes one card in `brain/2-ears/inbox/`.
- `/capture fetch` followed by a link: the full text of the page or of the paper is filed too.
- "What is new today?": the radar runs, then Carl keeps 20 items at most, best first, in
  `brain/2-ears/shortlist/<date>.md`. You pick with `/capture` and the link.
- On the screen, the page **E · Ears** shows the radar: your sources, whether it is running now,
  whether it ran today and at what time, how many new items, and how many Carl kept.
  The 07:00 run exists only once you registered the schedule that Alfred prints for you.

## Part E. C, Condense: what is worth keeping (15 minutes for one source, 20 to 40 per folder)

**20. Type to Alfred:** `continue` (or `/build-condense`).

**21. Choose where to start:** one outside source, or one folder of your own knowledge.

- **A folder of yours.** Chloe, the Analyst, writes one knowledge card per document: what it
  teaches, its examples and labs, its figures, your stories, each line with its place ("slide
  12"). Cato, the Fact-Checker, checks each card against the document. Then one question for the
  whole folder: read two cards, approve or change. One folder at a time, 24 documents at most
  per run.
- **An outside source.** Chloe writes a faithful summary (`condensed.md`: the source's own
  headings, in its order, every figure exact) and Cato checks it: PASS, FIX or BLOCK.

Each one gets a line in the memory index. A line that comes from `my-knowledge` is marked as
yours: the planner prefers it, and the writer may only state what you built or taught from it.

**22. The planted-error test (optional, two minutes).** You change one figure in a copy of a
summary, and Cato must catch it.

## Part F. O, Orient: what to do next (10 minutes)

**23. Type to Alfred:** `continue` (or `/build-orient`).

What happens: Olivia, the Planner, proposes the next two weeks in `brain/4-orient/plan.md`: two
proposals per slot, each tied to something in your memory, yours first. Answer "approve", "swap
a slot" or "new proposals".

## Part G. N, Narrate: a first piece in your voice (20 minutes)

**24. Type to Alfred:** `continue` (or `/build-narrate`).

**25. Give a brief of three lines:** the subject, the source (its name), what you want the reader
to do or feel.

What happens: Naomi, the Ghostwriter, writes `piece.md` in `brain/5-narrate/drafts/<name>/`, and
Nora, the Editor, reviews it against the source, your voice and your rules (`review.md`). Where
Naomi needs a fact about you that the brain does not hold, she writes
`[missing: ask the owner: ...]`. She never invents it: you fill it.

**26. Read the draft. Change what you want. Post it yourself,** if you want to. Nothing is sent
by an agent.

**27. Only if it really went out,** tell Alfred: `Published: <the text as it went out>, on <date>.`
Noah, the Record Keeper, files it word for word.

## Part H. D, Debrief: learn from results (30 minutes, after a few pieces went out)

**28. Type to Alfred:** `continue` (or `/build-debrief`).

**29. Answer:** what you measure (views, comments, replies...), at which moments (24 hours,
72 hours, 7 days), and against which baseline. With no numbers at all, the brain still learns
from what you changed between the draft and the text you posted.

From then on: "Run the weekly council." once a week, "Run the monthly tune-up." once a month.
Each proposed change waits for your decision.

## When something goes wrong

| What you see | What to do |
|---|---|
| You do not know what to do | Type `continue` to Alfred. Or read "What to do now" on the screen |
| An agent stays "waiting" on the screen | It waits for you: the box "Waiting for you" says for what. Answer there, then `continue` |
| You pressed Esc and an agent stopped | Tell Alfred: "start that agent again" |
| "Ignoring permissions.allow entries" | Close Alfred's window, double-click `Start my brain`, answer Yes to the trust question |
| `Start my brain` says Python or Claude Code is missing | Step 1, then double-click it again |
| The screen does not open | Open http://127.0.0.1:8770 in your browser, or tell Alfred "start the screen" |
| A PDF of yours is "not readable on this computer" | The table says what to install or how to save the file. The rest is filed anyway |
| "Cannot move brain/: it is in use" | Close the file of `brain` that is open in a program, then try again |
| An agent wrote something that is not you | Tell Alfred: "It's not me:" and the sentence. It becomes one of your limits |
| You want to stop | Type `/exit` to Alfred, or close his window. Next time, step 6: everything is in the files |

Without the double-click, from a terminal opened in the folder:

```
python .claude/skills/mission-control/scripts/serve.py --open      the screen
claude                                                             Alfred, in a second terminal
```

Next to read: `docs/build-guide.html` (open it in your browser) has the same six steps on one
screen each, with the prompts to copy and the checklists.
