# Start your own second brain

You have the starter kit: the team of 16 agents, their skills, the tools, an empty brain and one
example brain. This page takes you from the zip file to a brain that is yours.
Never used a terminal or Claude Code? Read `docs/STEP-BY-STEP.md` first: every click, every command.

Plan one hour for the first step. The rest can wait for tomorrow.

## 0. Before you start (5 minutes)

1. Unzip the kit in a folder of its own. Not inside another project.
2. Double-click `Start my brain` (`.bat` on Windows, `.command` on a Mac). It checks Python and
   Claude Code, opens the screen and starts Alfred.
3. Claude Code asks whether you trust this folder: say yes. The permissions and the run trace
   of `.claude/settings.json` only apply after that.

Then one word is enough at any time: `continue`. Alfred says where you are and starts the next
thing. Nothing else to install. The kit never publishes, posts or sends anything: you do.

## 1. Look around with the example brain (15 minutes)

The example is a fictional project manager. Three meeting notes of her week are in the brain.
The team turns them into the status report she sends on Friday.

Say to Alfred: `Switch to the brain project-manager.`

Then: `Alfred, run the production line on the three meeting notes of week 46: one status report.`

Watch the screen while it runs. It takes a few minutes.

| You see | It means |
|---|---|
| Chloe, then Cato | one faithful summary per note, then a fact-check of each one against its note |
| Naomi, then Nora | a first version of the report, then a review: PASS, FIX or BLOCK |
| A line in "Waiting for you" | the chain stopped. The next move is yours |

Then open four files. They are the whole idea:

- `brain/BRAIN.md`: what this brain produces.
- `brain/1-self/voice.md` and `brain/1-self/writing/status-report.md`: how she writes.
- `brain/5-narrate/drafts/`: the draft, its earlier version and the review.
- `.claude/agents/nora.md`: an agent is one page. Read it.

## 2. Build your own, one step at a time

Do the steps in order. Step S first: every other step reads it. Each command checks what
exists, creates what is missing, asks a few questions, calls the right agents and never
overwrites a file.

A guide of the six steps, with every prompt to copy and the checklists: open `docs/build-guide.html`
in your browser. It works without the network.

| Order | Type | It asks you | You have, at the end |
|---|---|---|---|
| 1 | `/build-self` | a short id for your brain, an interview of 6 or 12 questions, a few pieces you are proud of | who you are, your voice, your pillars, your limits, and a Double test with a likeness score |
| 2 | `/build-ears` | which folders of `my-knowledge/` to file, the few outside sources you trust, one thing to capture now | your own knowledge filed as text, your sources, your first cards in the inbox |
| 3 | `/build-condense` | which source or which folder of yours to start with | a faithful summary or one knowledge card per document, each fact-checked, each with a line in the memory index |
| 4 | `/build-orient` | your rhythm, if it is not written yet | the plan of the next two weeks, two proposals per slot |
| 5 | `/build-narrate` | a brief of three lines | a first piece, reviewed, that waits for your hand |
| 6 | `/build-debrief` | what you measure, when, and against which baseline | the feedback loop, ready for your first results |

`continue` does the same as the command of the next step: you never have to remember which one.

Four things to know before the first step:

- **Bring your own words.** Before `/build-self`, put your CV and five to ten pieces you wrote
  in `my-documents/` (its README says what to put and what never to put). The command copies
  them into your brain. The voice file is built from your sentences, quoted exactly.
- **Bring what you know.** Put your courses, slides, book and notes in `my-knowledge/`. Step S
  never opens it. Step E scans it with a small script, asks you once which folders to file, and
  files them as text. Step C turns each folder into knowledge cards. Without it, the brain
  writes in your voice about things it does not know.
- **One review per file.** You answer "approve", or "change:" and what to change. A change you
  dictate is applied and approved: you do not read the same file twice.
- **Each step ends on a checklist, "Done when".** A box is ticked only with a proof: a path or a
  count. After a first run several boxes stay empty. That is the honest result, not a failure.
- **Some boxes say "not built".** The full method has agents that are not in this kit, such as
  a scout that reads your sources for you. In the kit, a small script (the radar) and Carl, the
  Gatekeeper, do the morning reading, and you do the rest by hand.

## 3. Once it runs: your week

| When | You say or type | What happens |
|---|---|---|
| Any time | `/capture` followed by a link, an idea or a note | one card in `brain/2-ears/inbox/`, in two seconds, no question |
| You want a piece | "Alfred, run the production line on [slug of the source]." | summary, fact-check, draft, review, then it waits for you |
| A piece went out | "Published", with the text as it went out and the date | Noah files the record, word for word. The memory index says `used` |
| You wonder | "What do I know about [subject], and did I already use it?" | an answer from the files, each one cited, yours and outside told apart |
| You made something new | drop it in `my-knowledge/`, then "File my new documents." | scanned, one question, filed. Then "Digest the folder [name]." |
| You are lost | `continue` | where you are, what waits, the next thing |
| Once a week | "Alfred, run the weekly council." | the scorecards, one card per piece, the lessons proposed, the plan |
| Once a month | "Alfred, run the monthly tune-up." | the feedback loop: a lesson, a pillar move or a writing rule is proposed, challenged, and you decide |

Your results go in `brain/6-debrief/metrics/posts.json`. `/build-debrief` writes the file with
you. With no numbers at all, the loop still runs: it learns from what you changed between the
draft and the text that went out.

## 4. The rules that keep it yours

1. You decide, the brain proposes. A decision of yours is never guessed: it waits in the queue.
2. Nobody reviews their own work. The four reviewers write only their review file.
3. Your taste beats the numbers. A measured lesson never overrides `brain/1-self/rules.md`.
4. One file, one writer. If you want to change a rule by hand, change it: it is your brain.
   If you want an agent to change it, ask the agent that keeps the file.
5. Every change of a rule has a proposal, a challenge, your decision and a line in the ledger.
   So every change can be undone.

The full list is in `CLAUDE.md`.

## 5. A second brain for another job

The agents are generic. To use the same team for another job, another project or your home:

```
/build-self my-other-job
python ops/tools/switch_brain.py list
python ops/tools/switch_brain.py use my-other-job
```

One brain is active at a time, in `brain/`. The others wait in `brains/`. A switch moves two
folders. It deletes nothing.

## 6. When something goes wrong

| What you see | What to do |
|---|---|
| "Ignoring permissions.allow entries: this workspace has not been trusted" | Type `claude` once in the folder and accept the trust question |
| The screen shows no agent running although one works | Reload the page. Check that `ops/runs/` gets a new line |
| An agent stays "waiting" | It waits for you: answer in "Waiting for you" on the screen, then say `continue` |
| You pressed Esc while an agent worked | It stopped. Tell Alfred: "start that agent again" |
| `python` is not found | Install Python 3 from python.org. On Windows, tick "Add python.exe to PATH" |
| The port 8770 is taken | The screen runs already: open http://127.0.0.1:8770 |
| A switch says "it is in use" | A file of `brain/` is open in a program or a terminal. Close it and try again |
| An agent wrote something you do not like | Say "it's not me" to Alfred, with the sentence. It becomes a line of your limits |
| You want to start again from a clean point | `python ops/tools/demo_state.py save before-test`, try, then `restore before-test` |
