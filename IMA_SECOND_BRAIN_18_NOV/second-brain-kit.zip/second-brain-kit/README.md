# A second brain, built with the SECOND method

This folder is a small team of AI agents that works on plain files. It knows who you are, it
listens, it remembers, it proposes, it writes in your voice and it learns from results. You
decide. Nothing here publishes, posts or sends anything.

It runs in Claude Code. The agents and the skills are markdown files. The tools are small Python
scripts with no AI inside. The memory is six folders.

## What you need

- Claude Code. Built and tested with version 2.1.323.
- Python 3, on the path as `python`. Built and tested with version 3.15. Standard library only:
  nothing to install.
- No network at run time, except the one Claude Code needs, and two tools that you launch
  yourself: the radar, and the download of one page or paper (`library.py fetch`).

## Start in one minute

Double-click **`Start my brain`** in this folder (`.bat` on Windows, `.command` on a Mac). It
checks Python and Claude Code, opens the screen in your browser and starts Alfred, the Chief of
Staff. The first time, Claude Code asks whether you trust this folder: say yes, the permissions
and the run trace of `.claude/settings.json` only apply after that.

Then type one word to Alfred: `continue`. He says where you are in the six steps, what waits
for you, and starts the next thing. The screen says the same at its top.

From a terminal opened in this folder, the same two things:

```
python .claude/skills/mission-control/scripts/serve.py --open     the screen, on http://127.0.0.1:8770
claude                                                            Alfred (the settings of the folder name him)
```

You can also say one of the phrases of the table "The routines" below.

## The method

SECOND = Self, Ears, Condense, Orient, Narrate, Debrief. Each step is one organ of an agent.

| Step | Organ | The question it answers | Its folder | Its agents |
|---|---|---|---|---|
| S Self | identity | Who am I, how do I speak, what do I refuse? | `brain/1-self/` | Sofia the Biographer (interviews), Sacha the Voice Coach (tunes), Serena the Brand Strategist (positions), Sosie the Double (imitates, reviewer) |
| E Ears | perception | What should reach me? | `brain/2-ears/` | Emma the Front Desk (captures), Carl the Gatekeeper (scores) |
| C Condense | memory | What is worth keeping, and what does it really say? | `brain/3-condense/` | Chloe the Analyst (summarizes), Cato the Fact-Checker (verifies, reviewer) |
| O Orient | planning | What do I do next? | `brain/4-orient/` | Olivia the Planner (plans) |
| N Narrate | action | How do I say it, in my voice, with proof? | `brain/5-narrate/` | Naomi the Ghostwriter (drafts), Nora the Editor (reviews, reviewer), Noah the Record Keeper (records) |
| D Debrief | learning | What worked, and what do I change? | `brain/6-debrief/` | Dexter the Scorekeeper (measures), Diane the Coach (coaches), Diego the Skeptic (challenges, reviewer) |

Alfred routes the work. That makes 16 agents: 11 workers, 4 reviewers, 1 chief of staff.
Debrief feeds Self: what you learn goes back into who you are and how you write.

The one-page constitution, with the seven house rules, is `CLAUDE.md`. Every agent reads it.

## The folder map

```
CLAUDE.md            the constitution: the method, the seven rules, the tools
README.md            this page
.claude/agents/      the team, one file per agent
.claude/skills/      the know-how, one folder per skill (31 skills)
.claude/settings.json  the permissions and the run trace
brain/               the ACTIVE brain: BRAIN.md, then 1-self to 6-debrief
brains/              the shelf: the brains not in use, and _template/ (an empty brain)
ops/tools/           small scripts, no AI inside
ops/runs/            the run log, one line per start and per stop
ops/queue.json       "Waiting for you" (readable view: ops/waiting-for-you.md)
ops/routines.json    the routines, as the screen shows them
demo/                saved states for rehearsals, and the starter kit
docs/                the guides. From zero: docs/STEP-BY-STEP.md
my-documents/        who you are: your CV and your own writing, read at Step S
my-knowledge/        what you know: courses, slides, a book, notebooks. Filed at Step E, with your yes
LICENSE              CC BY-NC 4.0: reuse and adapt with credit to Hanane Dupouy, no commercial use
Start my brain       double-click it: the screen and Alfred (.bat on Windows, .command on a Mac)
```

## The routines

A routine is a fixed chain: who is called, in which order, and where it stops for you.

| Routine | Say to Alfred | It stops when |
|---|---|---|
| Onboarding | "Alfred, start my onboarding." | you approve your portrait, then your voice and your pillars, then you read the Double test |
| Production Line | "Alfred, run the production line on [slug of the source]." | the draft is reviewed and waits for you |
| Memory question | "What do I know about [subject], and did I already use it?" | it answers, with the files it read |
| Weekly Council | "Alfred, run the weekly council." | you decide each lesson, then you choose the plan |
| Monthly Tune-up | "Alfred, run the monthly tune-up." | you decide each change: a lesson, a pillar move, a writing rule |
| Brain switch | "Alfred, switch to the brain [id]." | the other brain is active |

**Every morning, remember:** Carl runs when you say "what is new today" or "score today's radar" to Alfred. Alfred runs the radar, then Carl scores it against your
rubric and keeps 20 at most. You pick from `brain/2-ears/shortlist/<date>.md` with `/capture`. The 07:00
schedule (`radar.py --print-schedule`) runs the radar only, never Carl.

**Your own knowledge:** drop files in `my-knowledge/` and say "file my new documents". A small
script scans them, you answer one question (which folders), it files the text in
`brain/2-ears/sources/`. Then "digest the folder [name]": Chloe writes one knowledge card per
document and Cato checks it.

Ten skills are launched by you, with a slash:

| Command | What it does |
|---|---|
| `/build-self`, `/build-ears`, `/build-condense`, `/build-orient`, `/build-narrate`, `/build-debrief` | build one step of your own brain, with you |
| `/capture` followed by anything | stores a link, an idea or a note in two seconds |
| `/mission-control` | starts the screen |
| `/mission-control-design` | the look of the screen, when you want to change it |
| `/agent-card` | writes or checks the card of an agent |

The 21 other skills are the know-how of the agents. They use them on their own.

## The screen

Mission Control is one local page. It reads the agent files, the run log, the queue and the
active brain. It shows where you are in the six steps and what to do now, what waits for you
(with the file to read, inside the page), who runs, whether the radar and the library tool are
running or finished, and where each result is. A click on a choice, or a change you type,
records your decision in the queue. It changes no other file. Then tell Alfred: `continue`.

```
python .claude/skills/mission-control/scripts/serve.py [--port 8770] [--open]
python .claude/skills/mission-control/scripts/serve.py --check      read everything once and stop
python .claude/skills/mission-control/scripts/serve.py --journey    where you are, in plain text
```

## The brains

The agents are generic. They say "piece". What a piece is comes from `brain/BRAIN.md` and from
`brain/1-self/writing/<kind>.md`. Change the brain and the same team does another job.

| Brain | What it is | Where |
|---|---|---|
| `content-creator` | The owner's brain: 24 pieces that really went out, with their real readings | the demo only, never in the kit |
| `project-manager` | A fictional project manager: three meeting notes in, one status report out | the demo and the kit |
| `_template` | An empty brain, with one guiding line per file | the demo and the kit |

```
python ops/tools/switch_brain.py list
python ops/tools/switch_brain.py use project-manager
```

## The tools

Run them from this folder. Each one has `--help`.

| Tool | What it does |
|---|---|
| `ops/tools/memory_index.py` | the memory index: add a line, set a status, find |
| `ops/tools/library.py` | your own knowledge: `scan` the folder `my-knowledge/`, `file` the folders you accepted as text in `brain/2-ears/sources/`, `fetch` one page or paper, `convert` a PDF or a Word file to text, `status` |
| `ops/tools/radar.py` | the daily radar: what is new in up to three sources, one page a day in `brain/2-ears/radar/`, then Carl scores it. `--print-schedule` gives the lines to run it at 07:00 |
| `ops/tools/scorecard.py` | each piece against a fixed baseline, per pillar, with the triggers found |
| `ops/tools/edit_diff.py` | what you changed between the draft and the text that went out |
| `ops/tools/ledger.py` | the ledger of changes: accepted, trial, rejected, applied, kept, rolled back |
| `ops/tools/switch_brain.py` | puts another brain in use, or starts a new one from the empty brain (`new`). It moves folders, it deletes nothing |
| `ops/tools/demo_state.py` | saves a state before a rehearsal and puts it back after |
| `ops/tools/make_kit.py` | exports the starter kit, without any real brain |
| `.claude/skills/run-trace/scripts/log_run.py` | the run log: a start line and a stop line per run |
| `.claude/skills/run-trace/scripts/queue.py` | the queue "Waiting for you": add, list, resolve, applied |
| `.claude/skills/agent-card/scripts/check_cards.py` | checks that every agent file is complete |

## Saved states and the starter kit

```
python ops/tools/demo_state.py list
python ops/tools/demo_state.py restore stage        the state before the demo
python ops/tools/make_kit.py                        writes demo/kit/second-brain-kit.zip
python ops/tools/make_kit.py --list                 shows what would go in, writes nothing
```

The kit holds the team, the skills, the tools, the empty brain and the fictional brain. A brain
is exported only when its `BRAIN.md` says `kind: fictional`. Your own brain stays with you.

## Read next

- `docs/START-YOUR-OWN.md`: build your own brain, one step at a time.
- `docs/DEMO-SCRIPT.md`: the path of the demo, with what to type and what to show (the demo only).
- `CLAUDE.md`: the rules every agent follows.
