# <Brain name>
- id: <short-id>
- owner: <first name>, or "fictional"
- kind: real | fictional
- produces: <one line: what this brain helps you produce>
- piece_kinds: piece
- sample_data: no

## How to start a brain from this template

1. Copy this folder to `brains/<your-id>/`.
2. Fill the six lines above. `id` is a short name in lower case with dashes, the same as the folder
   name. `piece_kinds` lists the kinds of pieces you produce, for example `post` or `status-report`.
   Each kind has its writing rules in `1-self/writing/<kind>.md`: rename `piece.md` to match.
3. Put it in use: `python ops/tools/switch_brain.py use <your-id>`.
4. Build Step S first: type `/build-self`. Then the other steps, in order.

Write `sample_data: yes` when any number in `6-debrief/` was invented. The screen then says
"sample numbers". Each of the six folders has a short README: what goes there, and who writes it.
