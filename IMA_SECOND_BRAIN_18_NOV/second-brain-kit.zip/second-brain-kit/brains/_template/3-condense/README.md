# 3-condense: what is worth keeping

Step C, the memory. What the brain knows, in a form you can trust.

- `index.md`: one line per source, with its status: new, summarized, checked, drafted, used. Written only by the tool `ops/tools/memory_index.py`.
- `summaries/<slug>/condensed.md`: one faithful summary per source. For a document of yours (its index source starts with `my-knowledge/`), a knowledge card: what it teaches, its labs, its figures, its stories, each line with its place in the document. Written by Chloe, the Analyst.
- `summaries/<slug>/fact-check.md`: the proof that the summary matches the source. Written by Cato, the Fact-Checker.

A new session answers "what do I know about this, and did I use it?" from this folder.
