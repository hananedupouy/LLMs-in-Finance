# 4-orient: what to do next

Step O, the planning. What you have, crossed with who you are and when you act.

- `plan.md`: what to produce next, and when, with two proposals per slot. Written by Olivia, the Planner.

You choose. A plan stays a proposal until you approve it.
