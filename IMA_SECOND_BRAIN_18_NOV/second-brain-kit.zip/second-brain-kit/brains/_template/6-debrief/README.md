# 6-debrief: what worked, what to change

Step D, the learning. The loop: measure, review, propose, challenge, you decide, apply, verify.

- `metrics/posts.json` and `baseline.json`: your results and your fixed baseline. `metrics/scorecards.*` and `metrics/edits/`: written by Dexter, the Scorekeeper, through his tools.
- `reviews/posts/<slug>.md`, `reviews/<date>-weekly.md` and `lessons.md`: written by Diane, the Coach.
- `changes/<id>-proposal.md`: one proposed change, by Diane (lesson), Serena (pillar) or Sacha (writing).
- `changes/<id>-challenge.md`: the challenge of that proposal. Written by Diego, the Skeptic.
- `changes/ledger.md`: every decision you took, and whether it worked. Written only by the tool `ops/tools/ledger.py`.

Nothing changes in the brain without your decision.
