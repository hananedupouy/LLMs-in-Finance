# 5-narrate: say it in my voice

Step N, the action. The brain writes a first version. You finish it and you send it yourself.

- `drafts/<slug>/piece.md`, then `piece-v1.md` and so on: the draft and its earlier versions. Written by Naomi, the Ghostwriter.
- `drafts/<slug>/review.md`: the independent review: PASS, FIX or BLOCK. Written by Nora, the Editor.
- `posted/<date>-<slug>.md`: what really went out, with the final text under a line `## Text`. Recorded when you say it is out.

No agent publishes anything.
