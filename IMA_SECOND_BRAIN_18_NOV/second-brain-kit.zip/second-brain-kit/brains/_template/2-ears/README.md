# 2-ears: what comes in

Step E, the perception. Your own knowledge filed first, one door for everything you capture by hand, an optional radar that looks for you, and a Gatekeeper who keeps the best of it.

- `inbox/<date>-<slug>.md`: one capture card per idea, link, file or note. Written by Emma, the Front Desk.
- `sources/<slug>.md`: the full text of a source, with where it came from, the date and its origin: `mine` (a document of yours) or `external`. Saved at capture, or filed by the library tool.
- `library.md` and `library/`: your own knowledge. One line per folder of `my-knowledge/`: how many files, how many readable, the duplicates, the private words found, and whether it is filed, left out by you or still waiting. Written only by `ops/tools/library.py`, a script with no AI inside. Nothing is filed without your yes, and your originals never move.
- `radar.json` and `radar/<date>.md`: optional, the daily radar. Your few sources, and one page a day with every new item, each with its abstract or first paragraph (and the same items as data in `radar/<date>.json`). Written only by `ops/tools/radar.py` (skill `radar`). Nothing goes in the inbox by itself: you keep an item with `/capture`.

- `shortlist/<date>.md`: what deserves your attention today. The radar items scored against your rubric (`1-self/rubric.md`), 0.7 or more and 20 at most, then what was skipped. Written by Carl, the Gatekeeper.

Only what the radar brings is scored: what you capture by hand or file from `my-knowledge/` is never judged. Filed is not known yet: summaries and knowledge cards are written in `3-condense/`.
