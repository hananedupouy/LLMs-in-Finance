# Rubric of the Gatekeeper

status: draft
drafted: <date>, by Serena, from pillars.md, about-me.md, rules.md and not-me.md
approved: not yet. The owner edits it in their own words, then writes "status: approved" and the date.
A "Hard no" is a subject you refuse to read about. A rule about how you write is not one.

> Carl scores what the radar brings against these lines, and only these. One screen, on purpose.
> Score = 0.5 x Fit + 0.3 x Substance + 0.2 x Use, each 0, 0.5 or 1. Keep 0.7 or more, 20 a day at most.
> Every line ends with the file it comes from, in brackets. Nothing here is invented.

## Topics that score high (Fit)
- <Pillar 1>: the topics and ideas a source must be about to serve this pillar. (pillars.md, <Pillar 1>)
- <Pillar 2>: ... (pillars.md, <Pillar 2>)

## Not fed by the radar
- <A pillar no feed can serve, for example personal stories>. (pillars.md)

## Substance that scores high
- <What makes a source worth keeping for you: data, code, a measured result, a failure told honestly>. (about-me.md, Beliefs)

## What scores low
- <A subject or a style you refuse>. (rules.md, not-me.md)

## Hard no: score 0
- <A line of "Never" that a source can break>. (rules.md)

## Audience
- <Who you write for, one line>. (about-me.md, Audience)

## How Carl scores (the same for every brain: keep this block as it is)
| Question | Weight | 1 | 0.5 | 0 |
|---|---|---|---|---|
| Fit: does it serve one pillar above? | 0.5 | squarely the topics of one pillar | near a pillar, a stretch | no pillar |
| Substance: does it bring something to keep? | 0.3 | data, code, a measured result, an honest failure | a clear idea, no proof yet | an announcement, an opinion |
| Use: could it become a piece for your audience? | 0.2 | new for your memory and useful | useful but narrow, or close to what you have | already in memory, or not for them |

Score = 0.5 x Fit + 0.3 x Substance + 0.2 x Use. Kept: 0.7 or more, 20 a day at most. A "Hard no": 0.
Example: on a pillar (1), a method with no result yet (0.5), new for you (1): 0.5 + 0.15 + 0.2 = 0.85, kept.
