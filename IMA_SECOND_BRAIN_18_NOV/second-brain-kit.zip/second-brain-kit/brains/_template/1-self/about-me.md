# About me

> Written by Sofia, the Biographer, from the interview and your documents. You approve every line.
> Each sentence says where it comes from: "stated by you" or "inferred".
> A portrait, not a catalogue: 80 lines at most. What you built and taught lives in your memory
> (`my-knowledge/`, filed at Step E), not here.

## Facts
Roles, years, degrees, certifications. Things anyone can check.

## Proof
The work you would show first: five lines at most. The rest of your work is in the memory.

## Stories
5 to 7 lived moments, three lines each: a failure, a turning point, a first time, a disagreement.

## Beliefs
What you think that others in your field do not. Your own frameworks.

## Audience
Who you serve, and what they need from you.

## Goals
What you want in 12 months. It decides what is worth your time.
