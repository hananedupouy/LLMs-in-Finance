# 1-self: who I am

Step S, the identity. Every agent reads this folder before it writes a word.

- `about-me.md`: facts, proof, stories, beliefs, audience, goals. Written by Sofia, the Biographer.
- `voice.md` and `writing/<kind>.md`: how you write, and your rules for one kind of piece. Written by Sacha, the Voice Coach.
- `pillars.md`: the few subjects you own, and your rhythm. Written by Serena, the Brand Strategist.
- `rules.md` and `not-me.md`: your limits, in your own words, and the private words the brain never writes. An agent writes them down, you confirm each line.
- `rubric.md`: what scores high and low when Carl, the Gatekeeper, filters the radar. Drafted by Serena, approved by you.
- `_tests/`: the Double tests. Can the brain imitate you with this folder only? Written by Sosie, the Double.

This folder says who you are. What you know (your courses, slides, book, notes) is not here: it is filed in `2-ears/` from `my-knowledge/`.

Nothing enters this folder without your approval.
