# Not me

> What you rejected, in your own words. Each time you say "it's not me", one line is added here.
> No numbers are needed: your taste beats the numbers.

## Subjects I do not touch
One subject per line, with the date and your reason.

## Styles and words that are not mine
One style or expression per line, with the date.

## Changes I rejected
A proposed change you refused as a matter of taste: its id, the date, your reason.
