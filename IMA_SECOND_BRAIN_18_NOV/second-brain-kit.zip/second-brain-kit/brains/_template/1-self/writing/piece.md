# Writing rules: <kind of piece>

> Your rules for one kind of piece: a post, a status report, an email. One file per kind, named
> `<kind>.md`, with the same word as in `piece_kinds` of `BRAIN.md`.
> Written by Sacha, the Voice Coach. The feedback loop tunes this file: one small change at a time,
> each with a before and after example, each approved by you.
> 120 lines at most. Rules only, no history: the story of a change is in the ledger.

## What this piece is
What it is for, who reads it, where it goes.

## Opening
How the first line is written. It is the line you rewrite most often.

## Length and layout
How long it is, and how it is cut into lines or sections.

## Structure
The parts, in their order.

## Closing
How it ends, and what it asks of the reader.

## Examples
One or two of your own pieces, quoted exactly.

## Checklist
The few points to check before the draft goes to the Editor. One per line.
