# Rules

> Your limits, in your own words. One rule per line, with its date.
> A rule you gave beats any number. Nobody changes this file without you.
> One rule, one home: a limit is written here once. The other files point to it, they do not copy it.

## Never
What the brain must never do, say or propose.

## Always
What every piece must respect.

## Private words
Names the brain must never write: an employer, a client, a person. One per line, with a dash.
The library tool looks for them before it files a document of yours, and the Editor in every draft.

## From my corrections
Rules that came from a correction you made, so that you never have to say it twice.
