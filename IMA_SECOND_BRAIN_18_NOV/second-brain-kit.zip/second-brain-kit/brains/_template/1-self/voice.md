# Voice

> Written by Sacha, the Voice Coach, from 10 to 20 pieces you wrote and are proud of.
> Samples, not adjectives: each claim quotes one of your own sentences.
> 120 lines at most. Rules only: a subject you refuse is in `rules.md`, not copied here.

## Tone
How you sound. Quote three sentences that show it.

## Structure habits
How you open, how you build, how you close. How long your sentences and paragraphs are.

## Signature phrases
Phrases you really use, quoted exactly. At least 10.

## Do
What a text must do to sound like you.

## Do not
What makes a text sound like somebody else.

## Words I never use
One word or expression per line.
