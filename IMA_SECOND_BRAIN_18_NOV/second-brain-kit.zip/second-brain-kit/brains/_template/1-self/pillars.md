# Pillars

> Written by Serena, the Brand Strategist, from what you already write about. The number of
> pillars is yours: as many as your material shows. One move a month at most.
> A first version at Step S. It is looked at again once your knowledge is filed (Step E).
> One "##" heading per pillar: the scorecard reads the pillar names from these headings.
> Copy the block below once per pillar, and write the name of the pillar in its heading.

## <Name of the pillar>
- promise: what the reader gets from this pillar, in one sentence.
- audience: who it is for.
- share: how much of your pieces it takes, for example 2 pieces out of 5.
- proof: where `about-me.md` shows that you read, used or lived this subject.
- serves: what it brings besides views (credibility, a goal, your pleasure).

## Rhythm
Which kind of piece, on which day. And the rest days.
