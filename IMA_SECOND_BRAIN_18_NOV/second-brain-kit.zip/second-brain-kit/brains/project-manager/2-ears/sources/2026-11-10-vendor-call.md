# Lighthouse, call with Kestrel of Tuesday 10 November 2026
- url: none
- fetched: 2026-11-12
- how: pasted by the owner

Present: Maya, Tom, and for Kestrel the delivery manager and the support lead. Notes taken by
Maya. 30 minutes.

## 1. The label defect

Kestrel confirms the defect: 1 label in 20 prints with a cut barcode on the thermal printers.
The cause is found. The fix is in release 4.2.

## 2. The date of release 4.2

Release 4.2 was promised for Tuesday 17 November. Kestrel now says Tuesday 24 November: 7 days
later. The reason given: the fix touches the print queue, and they want a full regression test.
Our test plan needs 6 working days after the release. From Tuesday 24 November to the go-live of
Tuesday 1 December there are 4 working days. It does not fit.

Kestrel proposes a workaround for the go-live: print the labels in batches and check each batch
by eye. On our volumes this is about 2 people per shift for the first week.

## 3. Support during the go-live

Kestrel commits to 2 consultants on site for the first 3 days, and a hotline from 6:00 to 22:00
for 2 weeks. The night shift is not covered by the hotline. Maya asked for a night contact:
Kestrel answers by Friday 13 November.

## 4. Actions

- Kestrel: confirm in writing the date of Tuesday 24 November, by Thursday 12 November.
- Kestrel: answer on a night contact by Friday 13 November.
- Maya: put the choice in front of the steering committee: go live on Tuesday 1 December with
  the workaround, or move the go-live to Tuesday 8 December.
