# Lighthouse, weekly team meeting of Monday 9 November 2026
- url: none
- fetched: 2026-11-12
- how: pasted by the owner

Present: Maya, Karim (data), Lea (training), Tom (interfaces). Notes taken by Maya. 45 minutes.

## 1. Data migration

Karim ran the fourth load on Friday. 41,200 of 43,000 stock records pass the checks. 1,800 fail,
all for the same reason: the unit of measure is missing. The list is with the Lyon stock team
since this morning. Karim needs their answer by Wednesday 18 November to load again on Friday
20 November. If the list comes back late, the last load moves into the cut-over week.

## 2. Training

3 of 5 sessions are done. 38 of 62 operators are trained. The session cancelled on Thursday
5 November was replaced on Friday 6 November. The last 24 operators are in 2 sessions: Tuesday
17 November and Thursday 19 November. Lea asks for 10 scanners in the room for these two
sessions: the operators trained so far used 4 scanners for 13 people, and it was not enough.

## 3. Interfaces

Tom tested the carrier interface with 2 of 4 carriers. Both tests passed. The other 2 carriers
are booked for Wednesday 18 November. One of them changed its label format in October: Tom does
not know yet if it has an effect.

## 4. Actions

- Karim: get the units of measure back from the Lyon stock team by Wednesday 18 November.
- Lea: book 10 scanners for the sessions of 17 and 19 November.
- Tom: ask the carrier for its new label format before Wednesday 18 November.
- Maya: raise the label defect on the call with Kestrel tomorrow.
