# Lighthouse, site visit in Lyon of Thursday 12 November 2026
- url: none
- fetched: 2026-11-12
- how: pasted by the owner

Present: Maya, the site director, 3 shift leaders, Karim. Notes taken by Maya on site.

## 1. Dry run of the cut-over

We played the cut-over night on the test system. It took 9 hours 40 minutes. The window on
Saturday 28 November is 8 hours. We are 1 hour 40 minutes over.

The step that slipped is the stock count: 3 hours 10 minutes, against 1 hour 30 minutes planned.
Two reasons: only 46 scanners, and the count list was printed by aisle instead of by zone.

The site director proposes a second dry run on Saturday 21 November, with the count list by
zone. He needs a yes by Tuesday 17 November to plan the staff.

## 2. Scanners

46 of 60 scanners are delivered and configured. The last 14 are due on Monday 23 November.
With 60 scanners the count should fit in the plan. This is not tested.

## 3. What the shift leaders said

- They want a printed quick guide at each station: one page, with pictures. Lea can write it.
- 2 of the 3 shift leaders are worried about the night shift on the first days: no hotline at
  night, and the newest operators are on that shift.
- They like the new picking screen. "It is faster than the old one once you know it."

## 4. Actions

- Maya: ask the steering committee for the second dry run on Saturday 21 November.
- Lea: write the one-page quick guide by Wednesday 25 November.
- Maya: bring the night shift question to Kestrel and to the site director.
