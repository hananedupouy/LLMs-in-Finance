# 2-ears: what comes in

Step E, the perception. One door for everything you capture by hand, an optional radar that looks for you, and a Gatekeeper who keeps the best of it.

- `inbox/<date>-<slug>.md`: one capture card per idea, link, file or note. Written by Emma, the Front Desk.
- `sources/<slug>.md`: the full text of a source, with its URL and the date it was fetched. Saved at capture, or dropped there by you.
- `radar.json` and `radar/<date>.md`: optional, the daily radar. Your few sources, and one page a day with every new item, each with its abstract or first paragraph (and the same items as data in `radar/<date>.json`). Written only by `ops/tools/radar.py` (skill `radar`). Nothing goes in the inbox by itself: you keep an item with `/capture`.

- `shortlist/<date>.md`: what deserves your attention today. The radar items scored against your rubric (`1-self/rubric.md`), 0.7 or more and 20 at most, then what was skipped. Written by Carl, the Gatekeeper.

Only what the radar brings is scored: what you capture by hand is never judged. Summaries are written in `3-condense/`.
