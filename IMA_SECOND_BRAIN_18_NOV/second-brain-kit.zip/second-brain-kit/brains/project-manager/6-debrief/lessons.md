# Lessons

> Kept by Diane, the Coach. The owner's rules win: a lesson never beats `brain/1-self/rules.md`
> or `brain/1-self/not-me.md`.
> At most 10 lessons that are not retired. Each one rests on at least 2 pieces and is written as
> a rule one can apply and check. Fictional, for the demo.

### L01: The decisions come first
- Status: confirmed
- Since: 2026-09-15
- Rule: the block "Decisions needed" comes right after the status line. Each decision names who decides and by when. No decision: write "Decisions needed: none."
- Evidence: status-week-44 (the decision on the cut-over night was asked for Tuesday 3 November and taken that day), status-week-45 (it records the decision, and writes "Decisions needed: none."). Against: none
- Change: none: written with the owner when the brain was set up

### L02: A color needs a reason and a date
- Status: confirmed
- Since: 2026-10-06
- Rule: never a color alone. The first line gives the color and its reason in one sentence. "On track" always carries the date.
- Evidence: status-week-43 (GREEN, with the go-live date), status-week-45 (AMBER, with its two reasons). Against: none
- Change: none: written with the owner when the brain was set up

## Retired
- none
