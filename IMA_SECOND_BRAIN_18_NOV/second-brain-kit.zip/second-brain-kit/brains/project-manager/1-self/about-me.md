# About me

> Written by Sofia, the Biographer, from an interview. A fictional person, for the demo.
> Each line says where it comes from: "stated by you" or "inferred".

## Facts
- Maya, project manager at Tessera Logistics, in the operations department. (stated by you)
- Eleven years in logistics: six as a warehouse team leader, five as a project manager. (stated by you)
- I run "Lighthouse": the new warehouse management system in three warehouses. Lyon goes first,
  then Lille, then Nantes. (stated by you)
- The team: Karim (data), Lea (training), Tom (interfaces), and the vendor, Kestrel. (stated by you)

## Proof
- Two earlier projects delivered: the scanner roll-out of 2023 and the new dock scheduling of 2024. (stated by you)
- The last three status reports of Lighthouse: `5-narrate/posted/`. (stated by you)

## Stories
1. The green report. On an earlier project I wrote "on track" for five weeks. The go-live slipped
   by a month in week six. Nobody had seen it coming, because I had not written it. (stated by you)
2. The night shift. As a team leader I lived a go-live at 2 a.m. with no printed guide. I do not
   plan a go-live without asking the shift leaders first. (stated by you)
3. The question that changed my reports. A director told me: "I read your report for one thing:
   what do you need from me?" Since then the decisions come first. (stated by you)

## Beliefs
- A status report is a tool to get decisions, not a diary. (stated by you)
- Amber early is better than red late. (stated by you)
- A risk with no owner and no date is a wish. (stated by you)
- The people on the floor know before the plan does. (stated by you)

## Audience
The steering committee of Lighthouse. Ten lines about them:
1. Four people: the operations director, the site director of Lyon, the IT director, the finance controller. (stated by you)
2. They meet every other Tuesday at 9:00. They read the report on their phone ten minutes before. (stated by you)
3. They read the first screen. Rarely more. (inferred, from their questions)
4. The operations director decides the dates. She wants to know what I need from her. (stated by you)
5. The site director cares about one thing: will my warehouse ship on Monday? (stated by you)
6. The IT director looks for the vendor's commitments and their dates. (stated by you)
7. The finance controller looks for anything that moves a milestone. (stated by you)
8. They hate surprises more than bad news. (stated by you)
9. They do not know the names of the modules. They know the sites and the dates. (inferred)
10. When a report says "on track" with no date, they stop trusting the color. (stated by you)

## Goals
- Lyon live on Tuesday 1 December 2026, with no shipment missed. (stated by you)
- Lille and Nantes live before the end of March 2027. (stated by you)
- No decision of the committee taken on an incomplete report. (stated by you)
