# Not me

> What I rejected, in my own words. Each time I say "it's not me", one line is added here.

## Subjects I do not touch
- Who is to blame. (2026-09-01)
- The contract and its penalties: that is for the IT director, not for the report. (2026-09-15)

## Styles and words that are not mine
- "On track" with no date. (2026-10-06)
- A cheerful opening: "Great week for Lighthouse". (2026-09-01)
- Long sentences with "however" and "nevertheless". (2026-09-01)
- A summary that hides the bad news in the third paragraph. (2026-09-15)

## Changes I rejected
- None yet.
