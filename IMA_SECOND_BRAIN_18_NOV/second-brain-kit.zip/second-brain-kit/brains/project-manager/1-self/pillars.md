# Pillars

> Written by Serena, the Brand Strategist. For a project manager, the pillars are the subjects
> every report must cover. One "##" heading per pillar.

## Decisions needed
- promise: the committee knows in ten seconds what it must decide, and by when.
- audience: the operations director first.
- share: in every report, first.
- proof: the story "the question that changed my reports" (`about-me.md`, Stories).
- serves: decisions taken on time.

## Schedule and milestones
- promise: each milestone, its planned date, its forecast date, and what moved.
- audience: the whole committee.
- share: in every report.
- proof: two projects delivered (`about-me.md`, Proof).
- serves: trust in the dates.

## Risks and blockers
- promise: every risk with its owner, its date and the next action. Amber early.
- audience: the IT director and the site director.
- share: in every report.
- proof: the story "the green report" (`about-me.md`, Stories).
- serves: no surprise.

## People on the floor
- promise: what the shift leaders and the operators said this week.
- audience: the site director.
- share: when there was a site visit or a training session.
- proof: six years as a warehouse team leader (`about-me.md`, Facts).
- serves: a go-live that the warehouse accepts.

## Rhythm
- One status report a week, sent on Friday before 16:00.
- The steering committee meets every other Tuesday at 9:00.
- The report is written from the meeting notes of the week, never from memory.
