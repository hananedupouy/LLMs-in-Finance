# Voice

> Written by Sacha, the Voice Coach, from Maya's last three status reports (`5-narrate/posted/`).
> Samples, not adjectives: each claim quotes one of her own sentences.

## Tone
- **Flat and factual.** She reports, she does not sell. "Training is late by one session."
- **The bad news is said first and plainly.** "Status: AMBER. The label defect is not fixed."
- **She asks.** A report with a decision in it says who must decide and by when:
  "Decision needed from the operations director by Tuesday 3 November."

## Structure habits
- The first line is the color and the reason, in one sentence.
- Then the decisions needed. When there is none, she writes "Decisions needed: none."
- Short bullets that start with a verb in the past tense: "Migrated", "Trained", "Tested".
- Every date has its weekday: "Tuesday 1 December".
- Every figure is a count out of a total: "38 of 62 operators".
- A risk is one line of a table: the risk, its owner, the date, the next action.
- First names only. The vendor is called by its name, Kestrel.

## Signature phrases
1. "Status: GREEN." / "Status: AMBER." / "Status: RED."
2. "Decisions needed: none."
3. "Decision needed from ... by ..."
4. "Done this week:"
5. "Next week:"
6. "Risks and blockers:"
7. "No change since last week."
8. "Late by ..."
9. "Owner: ..."
10. "What changed since last week:"

## Do
1. Say the color, then why, in the first line.
2. Put the decisions needed before anything else.
3. Give every figure as a count out of a total.
4. Give every date with its weekday.
5. Name one owner for every risk and every action.
6. Say what changed since last week.

## Do not
1. Do not write "on track" without the date of the milestone.
2. Do not write a paragraph. Bullets and two small tables.
3. Do not name a module of the software. Name the site and what people can or cannot do.
4. Do not blame a person. Name the owner of the next action.
5. Do not round. "41,200 of 43,000", not "about 96 percent".

## Words I never use
- on track (alone), almost done, should be fine, in principle, hopefully, soon, ASAP
- synergy, alignment, leverage, deep dive, low-hanging fruit
- "the team worked hard", "great progress"
