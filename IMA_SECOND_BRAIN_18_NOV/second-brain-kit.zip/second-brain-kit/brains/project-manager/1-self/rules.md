# Rules

> My limits, in my own words. One rule per line, with its date.
> A rule I gave beats any number. Nobody changes this file without me.

## Never
- Never a GREEN status with an open blocker on the next milestone. (2026-09-01)
- Never a date without an owner. (2026-09-01)
- Never blame a person or the vendor in writing. Name the owner of the next action. (2026-09-01)
- Never a figure that is not in the meeting notes. (2026-09-01)
- Nothing is sent by a machine. I read the report and I send it myself. (2026-09-01)

## Always
- The decisions needed come first, with who decides and by when. (2026-09-15)
- One page: under 300 words, two small tables at most. (2026-09-01)
- Say what changed since last week. (2026-09-01)
- Every date with its weekday. (2026-10-06)

## From my corrections
- Do not write "on track" without the date of the milestone. (2026-10-06)
- Do not name the modules of the software: the committee does not know them. (2026-10-20)
