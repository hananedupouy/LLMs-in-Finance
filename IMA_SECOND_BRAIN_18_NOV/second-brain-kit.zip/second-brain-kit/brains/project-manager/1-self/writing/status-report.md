# Writing rules: status-report

> My rules for one kind of piece: the weekly status report of the project. Written by Sacha, the
> Voice Coach. The feedback loop tunes this file: one small change at a time, approved by me.

## What this piece is
One page, sent every Friday to the steering committee. They read it on a phone, ten minutes
before the meeting. It exists to get decisions and to avoid surprises.

## Opening
- The first line is the color and the reason: "Status: AMBER. The label defect is not fixed."
- GREEN: every milestone holds its date. AMBER: one milestone is at risk, a decision can save it.
  RED: a milestone is lost.
- Never GREEN with an open blocker on the next milestone.

## Length and layout
- Under 300 words. Bullets, and two small tables at most.
- Every date with its weekday. Every figure as a count out of a total.

## Structure
1. `Status:` the color and the reason, one line.
2. `Decisions needed:` each with who decides and by when. Or "none."
3. `What changed since last week:` two or three bullets.
4. `Done this week:` bullets, verbs in the past tense.
5. `Next week:` bullets, each with its owner.
6. `Risks and blockers:` a table: risk, owner, date, next action.
7. `Milestones:` a table: milestone, planned, forecast.

## Closing
- The report ends with the milestones table. No sign-off, no "do not hesitate to".

## Examples
The opening of the report of Friday 6 November 2026:

"Status: AMBER. Training is late by one session, and the label defect is not fixed.
Decisions needed: none."

## Checklist
- The first line is a color and a reason.
- The decisions needed come second, with a name and a date.
- Every figure is in the meeting notes of the week, as a count out of a total.
- Every risk has an owner, a date and a next action.
- No module name, no blame, no "on track" without a date.
- Under 300 words.
