# Maya's project brain
- id: project-manager
- owner: fictional
- kind: fictional
- produces: the weekly status report of a project, for its steering committee, from the meeting notes of the week
- piece_kinds: status-report
- sample_data: yes

## What this brain is

A fictional brain, written for the demo. Maya is a project manager at Tessera Logistics. She runs
"Lighthouse": the replacement of the warehouse management system in three warehouses (Lyon, Lille,
Nantes). The company, the people, the vendor and every figure are invented.

The team of agents is the same as for any other brain. Only this folder changes:

- `1-self/` says who Maya is, who reads her reports and how she writes them.
- `2-ears/sources/` holds three meeting notes of the week.
- `5-narrate/posted/` holds her last three status reports, word for word.
- `6-debrief/lessons.md` holds what the steering committee taught her.

Put it in use: `python ops/tools/switch_brain.py use project-manager`.
