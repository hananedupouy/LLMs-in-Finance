@echo off
rem Start my brain (Windows): double-click this file. It starts the screen, then Alfred.
setlocal
cd /d "%~dp0"
title My second brain
echo.
echo   My second brain
echo   ---------------
echo.

python --version >nul 2>nul
if errorlevel 1 (
  echo   Python 3 is missing. Install it from python.org and tick "Add python.exe to PATH"
  echo   during the install. Then double-click this file again.
  echo.
  pause
  exit /b 1
)
where claude >nul 2>nul
if errorlevel 1 (
  echo   Claude Code is missing. Install it from claude.com/claude-code, sign in,
  echo   then double-click this file again.
  echo.
  pause
  exit /b 1
)

echo   1. The screen opens in your browser: what waits for you, who works.
echo      Keep the small window "Second brain screen" open: closing it stops the screen.
start "Second brain screen" /min python ".claude\skills\mission-control\scripts\serve.py"
timeout /t 2 /nobreak >nul
start "" "http://127.0.0.1:8770"

echo   2. Alfred starts below. The first time, answer Yes to the question about
echo      trusting the files of this folder.
echo.
echo      Then type:  continue
echo      Do not press Esc while an agent works: it stops the agent.
echo.
call claude --agent alfred

echo.
echo   Alfred is closed. Everything is in the files: double-click this file again
echo   to go on where you stopped. Close the window "Second brain screen" to stop the screen.
echo.
pause
