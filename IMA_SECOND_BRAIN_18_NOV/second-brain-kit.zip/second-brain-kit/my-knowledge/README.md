# my-knowledge: what you know

Drop here what you know: the courses you teach, your book, your slides, your notebooks, your
notes, the transcripts of your talks. This is the material your brain will write from.

Nothing here is read during the Self step. At the Ears step (`/build-ears`), a small script with
no AI inside counts what is here and shows you a table, one line per folder. You say which
folders to file. Nothing is filed without your yes.
Nothing here is changed, moved or sent anywhere by the brain.

## Two folders, two jobs

| Folder | What goes in | Read at |
|---|---|---|
| `my-documents/` | Who you are and how you write: your CV, a bio, a few pieces you are proud of | Step S, Self |
| `my-knowledge/` | What you know: courses, a book, slides, notebooks, notes, talks | Step E, Ears |

A piece of yours can be in both: in `my-documents/` it teaches your voice, here it is knowledge.

## How

- Keep your own folders. Copy a whole course folder as it is: sub folders are fine.
- The table shows the first two levels: `Training/Module-2/old/lab.ipynb` is counted in the
  line `Training/Module-2`.
- The same file in two places is filed once.
- You can add files later. Only what is new or changed is filed.

## What is read

| Type | What is kept |
|---|---|
| `.md` `.txt` `.rst` | Everything |
| `.ipynb` (notebook) | The text and the code, in order. The outputs are dropped |
| `.pptx` (slides) | The text of each slide, in order, and the speaker notes |
| `.docx` (Word) | The paragraphs, the headings and the tables |
| `.pdf` | The text. The layout is lost, and a scanned PDF has no text to read |
| `.html` | The text of the page |
| `.py` | The code |

Not read: old `.ppt` and `.doc` files (save them as `.pptx` and `.docx`), images, videos, sound
and data files. The table lists each one, with the reason and what to do.
A PDF needs a small reader that comes with Git for Windows. Without it, the table says so.

## Private words

A name that must not enter your brain, such as an employer or a client, goes in your rules:
one line `- the word` under the heading `## Private words` in `brain/1-self/rules.md`.

The scan counts the documents that hold one of these words, in their name or in their text.
Before filing them you choose:

- **keep**: file them as they are.
- **mask**: each private word becomes `[private]`.
- **skip**: leave these documents out.

A word of four letters or more is caught anywhere, also inside a longer word. A shorter word is
caught only when it stands alone. The check finds the words you listed, nothing else: read a
document before you share it.

## Never put here

Passwords, contracts, salaries, health data, anything your employer or a client did not allow
you to copy, private data about other people. Once filed, these texts are read by the agents,
like anything you paste into a chat.

## Two sentences to say to Alfred

- **"Scan my knowledge."** He runs the count and shows you the table.
- **"File my new documents."** He files what is new in the folders you chose.

Filed is not known yet. A filed document is plain text in `brain/2-ears/sources/`. The Condense
step turns it into a knowledge card: a faithful summary, then a check.
