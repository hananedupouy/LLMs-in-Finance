#!/bin/bash
# Start my brain (Mac): double-click this file. It starts the screen, then Alfred.
# The first time, macOS may ask you to allow it: right-click the file, Open, then Open.
cd "$(dirname "$0")" || exit 1
clear
echo
echo "  My second brain"
echo "  ---------------"
echo

# The agents call "python". A Mac often has only "python3": give it the name python, for
# this window only. Nothing is installed and nothing is changed on the Mac.
if ! (command -v python >/dev/null 2>&1 && python --version 2>&1 | grep -q "Python 3"); then
  if command -v python3 >/dev/null 2>&1; then
    SHIM="$(mktemp -d)"
    ln -s "$(command -v python3)" "$SHIM/python"
    export PATH="$SHIM:$PATH"
  else
    echo "  Python 3 is missing. Install it from python.org, then double-click this file again."
    read -r -p "  Press Enter to close. " _
    exit 1
  fi
fi
if ! command -v claude >/dev/null 2>&1; then
  echo "  Claude Code is missing. Install it from claude.com/claude-code, sign in,"
  echo "  then double-click this file again."
  read -r -p "  Press Enter to close. " _
  exit 1
fi

echo "  1. The screen opens in your browser: what waits for you, who works."
python ".claude/skills/mission-control/scripts/serve.py" >/dev/null 2>&1 &
SCREEN=$!
sleep 2
open "http://127.0.0.1:8770" >/dev/null 2>&1

echo "  2. Alfred starts below. The first time, answer Yes to the question about"
echo "     trusting the files of this folder."
echo
echo "     Then type:  continue"
echo "     Do not press Esc while an agent works: it stops the agent."
echo
claude --agent alfred

kill "$SCREEN" >/dev/null 2>&1
echo
echo "  Alfred is closed and the screen is stopped. Everything is in the files:"
echo "  double-click this file again to go on where you stopped."
read -r -p "  Press Enter to close. " _
