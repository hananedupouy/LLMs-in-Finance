# my-documents: what you put here before /build-self

Drop your own documents in this folder before you type `/build-self`. When the command creates
your brain, it copies them into `brain/1-self/_raw/`. Sofia, the Biographer, reads them before she
interviews you, and Sacha, the Voice Coach, builds your voice from your own sentences.
Nothing here is changed, moved or sent anywhere by the brain.

This folder says **who you are and how you write**: ten to twenty-five files. What you know
(your courses, your slides, your book, your notebooks) goes in `my-knowledge/`, next to this
folder. The first step never opens it.

## What to put here

| What | How many | Example file name |
|---|---|---|
| Your CV, or your LinkedIn profile saved as PDF | 1 | `cv.pdf` |
| A short bio, as you would introduce yourself | 1 | `bio.md` |
| Pieces you wrote and are proud of: posts, articles, newsletters | 5 to 10, the more the better | `post-2026-03-agents-in-finance.md` |
| Emails or messages you wrote that sound like you (your text only) | 0 to 5 | `email-to-a-new-client.md` |
| The transcript of a talk, a podcast or a video of yours | 0 to 2 | `talk-2025-meetup.md` |
| A piece that is NOT you (a style you dislike), with "not me" in the name | 0 to 2 | `not-me-hype-post.md` |

## How

- One piece per file. Copy the text and paste it into a `.md` or `.txt` file. Put the date at the top.
- PDF and Word (`.docx`) work too: the brain makes a text copy of each one.
- Only text you wrote yourself. In an email, delete the other people's names, addresses and words.

## Never put here

Passwords, contracts, salaries, health data, client files, anything confidential from your
employer, or private messages from other people. These files are read by Claude, like anything
you paste into a chat with it.
