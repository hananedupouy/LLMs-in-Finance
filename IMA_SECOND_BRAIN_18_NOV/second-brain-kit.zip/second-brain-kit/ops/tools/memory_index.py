#!/usr/bin/env python3
"""The memory index: one line per source the brain knows, in <brain>/3-condense/index.md.

Commands (run from the project root):

  python ops/tools/memory_index.py add --slug S --title "T" --source "URL or path" --pillar "P" --summary PATH
  python ops/tools/memory_index.py status --slug S --set new|summarized|checked|drafted|used
  python ops/tools/memory_index.py find "words"

Every command accepts --brain DIR (default: brain), to work on a brain of the shelf (brains/<id>).

The index is a markdown table. Columns: date | slug | title | source | pillar | status | summary.
This script is its only writer.

  add     creates the file with its header when it is missing. On a slug that already exists, the line is
          updated: the date and the status are kept. A new line starts as "summarized" when the summary
          file exists, else as "new". A line still "new" moves to "summarized" when the summary file appears.
  status  moves one source along its life: new, summarized, checked, drafted, used.
  find    not case sensitive. A source matches when every word is found in its index line, or in the text
          of its summary. Prints the matching lines and the path of each summary.

Standard library only.
"""
from __future__ import annotations

import argparse
import re
import sys
from datetime import date
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
COLUMNS = ["date", "slug", "title", "source", "pillar", "status", "summary"]
STATUSES = ["new", "summarized", "checked", "drafted", "used"]
HEADER = [
    "# Memory index",
    "",
    "One line per source the brain knows. Newest first.",
    "Written only by `ops/tools/memory_index.py`. Do not edit by hand.",
    "Status: new, summarized, checked, drafted, used.",
    "",
]


class Stop(Exception):
    """An expected problem: one clear line for the user, no stack trace."""


def show(path: Path) -> str:
    try:
        return path.resolve().relative_to(ROOT).as_posix()
    except ValueError:
        return path.as_posix()


def explain(error: OSError) -> str:
    """A system error in a few words, with a path from the project root, never a full one."""
    name = ""
    if error.filename:
        try:
            name = Path(str(error.filename)).resolve().relative_to(ROOT).as_posix()
        except (ValueError, OSError):
            name = Path(str(error.filename)).name
    reason = error.strerror or type(error).__name__
    return f"{reason}: {name}" if name else reason


def resolve_brain(text: str) -> Path:
    path = Path(text)
    for candidate in ([path] if path.is_absolute() else [ROOT / path, Path.cwd() / path]):
        if candidate.is_dir():
            return candidate.resolve()
    raise Stop(f"No brain folder at {text}. Give an existing one with --brain DIR, for example --brain brains/<id>.")


def locate(brain: Path, text: str) -> Path | None:
    """Find a file named in the index, even when the brain moved between brain/ and brains/<id>/."""
    text = text.strip().replace("\\", "/")
    if not text:
        return None
    path = Path(text)
    if path.is_absolute():
        return path if path.is_file() else None
    candidates = []
    for position, part in enumerate(path.parts):
        if re.match(r"^[1-6]-[a-z]", part):
            candidates.append(brain.joinpath(*path.parts[position:]))
            break
    candidates += [brain / path, ROOT / path, Path.cwd() / path]
    return next((candidate for candidate in candidates if candidate.is_file()), None)


def clean(text) -> str:
    """One table cell: one line, no pipe, no long dashes."""
    text = "" if text is None else str(text)
    text = re.sub(r"\s*" + chr(0x2014) + r"\s*", ", ", text).replace(chr(0x2013), "-")
    return " ".join(text.split()).replace("|", "/")


def read_rows(path: Path) -> list[dict]:
    rows: list[dict] = []
    header: list[str] | None = None
    for line in path.read_text(encoding="utf-8-sig").splitlines():
        line = line.strip()
        if not line.startswith("|"):
            continue
        cells = [cell.strip() for cell in line.strip("|").split("|")]
        if header is None:
            header = [cell.lower() for cell in cells]
            continue
        if all(set(cell) <= set("-: ") for cell in cells):
            continue
        row = {column: "" for column in COLUMNS}
        for name, cell in zip(header, cells):
            if name in row:
                row[name] = cell
        if row["slug"]:
            rows.append(row)
    return rows


def write_rows(path: Path, rows: list[dict]) -> None:
    rows = sorted(rows, key=lambda row: row["date"], reverse=True)
    lines = HEADER + ["| " + " | ".join(COLUMNS) + " |", "|" + "---|" * len(COLUMNS)]
    lines += ["| " + " | ".join(clean(row[column]) for column in COLUMNS) + " |" for row in rows]
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="\n") as handle:
        handle.write("\n".join(lines) + "\n")


def entries(count: int) -> str:
    return f"{count} entry" if count == 1 else f"{count} entries"


def slug_of(text: str) -> str:
    slug = clean(text).strip()
    if not slug or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]*", slug):
        raise Stop(f'"{text}" is not a valid slug. Use letters, digits and dashes, for example agent-memory.')
    return slug


def cmd_add(brain: Path, index: Path, args) -> None:
    slug = slug_of(args.slug)
    title = clean(args.title)
    if not title:
        raise Stop('--title is empty. Give the title of the source, for example --title "How agents remember".')
    if args.date:
        try:
            date.fromisoformat(args.date)
        except ValueError:
            raise Stop(f'"{args.date}" is not a date. Write it as YYYY-MM-DD.')
    summary = clean(args.summary or f"{show(brain)}/3-condense/summaries/{slug}/condensed.md").replace("\\", "/")
    has_summary = locate(brain, summary) is not None
    status = (args.status or "").lower()
    rows = read_rows(index) if index.is_file() else []
    row = next((row for row in rows if row["slug"] == slug), None)
    if row is None:
        row = {"date": args.date or date.today().isoformat(), "slug": slug,
               "status": status or ("summarized" if has_summary else "new")}
        rows.append(row)
        action = "added"
    else:
        if status:
            row["status"] = status
        elif row["status"] in ("", "new") and has_summary:
            row["status"] = "summarized"
        if args.date:
            row["date"] = args.date
        action = "updated"
    row.update({"title": title, "source": clean(args.source), "pillar": clean(args.pillar) or "none",
                "summary": summary})
    write_rows(index, rows)
    print(f'{action}: {slug} [{row["status"]}] in {show(index)} ({entries(len(rows))})')
    if not has_summary:
        print(f"note: the summary file does not exist yet ({summary})")


def cmd_status(brain: Path, index: Path, args) -> None:
    slug = slug_of(args.slug)
    if not index.is_file():
        raise Stop(f"No memory index yet at {show(index)}. Add a source first with: memory_index.py add ...")
    rows = read_rows(index)
    row = next((row for row in rows if row["slug"] == slug), None)
    if row is None:
        raise Stop(f'No source "{slug}" in {show(index)} ({entries(len(rows))}). Check the slug with: memory_index.py find "words"')
    before = row["status"] or "none"
    row["status"] = args.set
    write_rows(index, rows)
    print(f"{slug}: {before} -> {args.set} in {show(index)}")


def cmd_find(brain: Path, index: Path, args) -> None:
    words = [word.casefold() for word in " ".join(args.words).split()]
    if not words:
        raise Stop('Nothing to look for. Example: memory_index.py find "agent memory"')
    if not index.is_file():
        raise Stop(f"No memory index yet at {show(index)}. Nothing is known. Add a source first with: memory_index.py add ...")
    rows = read_rows(index)
    matches = []
    for row in rows:
        line = " ".join(row.values()).casefold()
        summary_file = locate(brain, row["summary"])
        where = None
        if all(word in line for word in words):
            where = "the index line"
        elif summary_file is not None:
            try:
                text = summary_file.read_text(encoding="utf-8-sig", errors="replace").casefold()
            except OSError:
                text = ""
            if all(word in line or word in text for word in words):
                where = "the text of the summary"
        if where:
            matches.append((row, summary_file, where))
    query = " ".join(args.words)
    if not matches:
        print(f'No match for "{query}" in {show(index)} ({entries(len(rows))}).')
        return
    print(f'{len(matches)} match{"es" if len(matches) != 1 else ""} for "{query}" in {show(index)} ({entries(len(rows))})')
    print("| " + " | ".join(COLUMNS) + " |")
    print("|" + "---|" * len(COLUMNS))
    for row, _, _ in matches:
        print("| " + " | ".join(row[column] for column in COLUMNS) + " |")
    print()
    for row, summary_file, where in matches:
        path = show(summary_file) if summary_file else f'{row["summary"] or "none"} (file not found)'
        print(f'{row["slug"]} [{row["status"] or "no status"}]: summary at {path} (words found in {where})')


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="memory_index.py",
        description="The memory index of a brain: <brain>/3-condense/index.md, one line per source.",
        epilog='Example: python ops/tools/memory_index.py add --slug agent-memory --title "How agents remember" '
               '--source "https://example.org/a" --pillar "AI agents" --summary brain/3-condense/summaries/agent-memory/condensed.md',
    )
    parser.add_argument("--brain", default="brain", metavar="DIR", help="the brain to work on (default: brain)")
    brain = argparse.ArgumentParser(add_help=False)  # the same option, accepted after the command too
    brain.add_argument("--brain", default=argparse.SUPPRESS, metavar="DIR", help="the brain to work on (default: brain)")
    sub = parser.add_subparsers(dest="command", metavar="add | status | find")

    add = sub.add_parser("add", parents=[brain], help="add a source, or update the line of a slug that exists")
    add.add_argument("--slug", required=True, help="short name of the source, also its folder name")
    add.add_argument("--title", required=True, help="the title of the source")
    add.add_argument("--source", default="", help="the URL or the path of the source")
    add.add_argument("--pillar", default="none", help='the pillar it serves, or "none"')
    add.add_argument("--summary", default="", help="the path of the summary (default: <brain>/3-condense/summaries/<slug>/condensed.md)")
    add.add_argument("--status", choices=STATUSES, default=None, help="force a status (default: see --help of the tool)")
    add.add_argument("--date", default=None, help="force the date, YYYY-MM-DD (default: today for a new line)")

    status = sub.add_parser("status", parents=[brain], help="change the status of one source")
    status.add_argument("--slug", required=True, help="the slug of the source")
    status.add_argument("--set", required=True, choices=STATUSES, help="the new status")

    find = sub.add_parser("find", parents=[brain], help="what do I know about these words, and did I use it?")
    find.add_argument("words", nargs="+", help="one or several words. All must be found")
    return parser


def main() -> None:
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass
    parser = build_parser()
    args = parser.parse_args()
    if not args.command:
        parser.print_help()
        sys.exit(2)
    try:
        brain = resolve_brain(args.brain)
        index = brain / "3-condense" / "index.md"
        {"add": cmd_add, "status": cmd_status, "find": cmd_find}[args.command](brain, index, args)
    except Stop as problem:
        print(f"memory_index: {problem}", file=sys.stderr)
        sys.exit(1)
    except OSError as error:
        print(f"memory_index: cannot read or write the index ({explain(error)}).", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
