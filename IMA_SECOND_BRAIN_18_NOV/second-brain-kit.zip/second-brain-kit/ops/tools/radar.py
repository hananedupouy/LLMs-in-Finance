"""The daily radar of a brain: what is new in a few sources, in one page. No AI inside.

Reads   brain/2-ears/radar.json             the sources of this brain (3 is a good start)
Writes  brain/2-ears/radar/<date>.md        the page of the day, for you: every new item, newest first
        brain/2-ears/radar/<date>.json      the same items, as data, for the agent that scores later
        brain/2-ears/radar/seen.json        what was already listed, so nothing comes twice
        ops/runs/<date>.jsonl               a start line and a stop line (agent "radar", source "tool"),
                                            so Alfred and the screen know when it runs and when it ended

Every item gets the same detail: title, link, date, authors, and its text (the whole abstract of
an arXiv paper, the first paragraph of a blog post). No ranking, no cut: a fair input for scoring.
One safety limit, "max" per source and per run (default 50). Above it the page says so.
Nothing twice across sources: an item found by two sources is listed once, under the first one,
and its record names the other source in "also_from".

The radar lists. It never judges, never summarizes, never writes in the inbox.
The owner keeps an item with /capture <its link>. Emma does the rest.

Usage (from the project folder, or from anywhere: paths are taken from this file):
  python ops/tools/radar.py                     run once: fetch, list what is new, write the digest
  python ops/tools/radar.py --check             read the sources once, write nothing
  python ops/tools/radar.py --print-schedule    the command that runs it every day at 07:00
  python ops/tools/radar.py --brain brains/ID   another brain than the active one

Two kinds of source:
  arxiv   a search of the arXiv API, e.g. "cat:cs.AI AND abs:agentic"
  rss     any RSS or Atom feed, e.g. https://openai.com/news/rss.xml
"""

from __future__ import annotations

import argparse
import gzip
import html
import json
import platform
import re
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta, timezone
from email.utils import parsedate_to_datetime
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[2]
ARXIV_API = "https://export.arxiv.org/api/query"
ARXIV_PAUSE = 3.5            # arXiv asks for about 3 seconds between calls
RETRY_WAITS = (10, 30)       # seconds before each retry of a refused or failed call
USER_AGENT = "second-brain-radar/1.0 (personal reading list)"
DEFAULT_MAX = 50             # safety limit: items listed per source and per run
DEFAULT_LOOKBACK = 3         # days: older items are never listed, even on a first run
KEEP_SEEN_DAYS = 90
FIRST_PARAGRAPH_CHARS = 800  # a blog text: its first paragraph, cut here if it has none
NS = {"a": "http://www.w3.org/2005/Atom"}

_last_arxiv_call = 0.0


# ---------- small helpers ----------

def now_local() -> datetime:
    return datetime.now().astimezone()


def log_run(event: str, status: str, summary: str = "", outputs: list | None = None) -> None:
    """One line in ops/runs/<date>.jsonl, the run log of the project (house rule 7), in the shape
    of the skill run-trace. A start with no stop yet: the radar is running. Never stops the run."""
    stamp = datetime.now().replace(microsecond=0)
    record = {"ts": stamp.isoformat(), "agent": "radar", "event": event, "status": status,
              "routine": "radar", "summary": " ".join(summary.split())[:300], "outputs": outputs or [],
              "verdict": None, "source": "tool"}
    try:
        folder = PROJECT / "ops" / "runs"
        folder.mkdir(parents=True, exist_ok=True)
        with open(folder / f"{stamp.date().isoformat()}.jsonl", "a", encoding="utf-8", newline="\n") as handle:
            handle.write(json.dumps(record, ensure_ascii=False, separators=(",", ":")) + "\n")
    except OSError as exc:
        print(f"Note: the run log could not be written ({exc}).")


def clean(text: str | None) -> str:
    """Tags out, entities decoded, white space collapsed. The words are kept as they are."""
    if not text:
        return ""
    text = re.sub(r"<[^>]+>", " ", text)
    text = html.unescape(text).replace(chr(0x2014), "-").replace(chr(0x2013), "-")  # house rule: no long dash
    return " ".join(text.split())


def cut(text: str, limit: int = FIRST_PARAGRAPH_CHARS) -> str:
    if len(text) <= limit:
        return text
    return text[:limit].rsplit(" ", 1)[0] + " ..."


def first_paragraph(raw: str | None) -> str:
    """The first paragraph of a feed text (HTML or plain), cleaned, never longer than the limit."""
    if not raw:
        return ""
    for chunk in re.split(r"</p\s*>|<br\s*/?>\s*<br\s*/?>|\n\s*\n", raw, flags=re.I):
        text = clean(chunk)
        if text:
            return cut(text)
    return ""


def resolve(path: str) -> Path:
    p = Path(path)
    return p if p.is_absolute() else PROJECT / p


def http_get(url: str, timeout: int = 60) -> bytes:
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    last: Exception | None = None
    for attempt in range(len(RETRY_WAITS) + 1):
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                body = resp.read()
            if body[:2] == b"\x1f\x8b":  # some feeds answer gzip even when not asked
                body = gzip.decompress(body)
            return body
        except urllib.error.HTTPError as exc:
            last = exc
            if exc.code != 429 and exc.code < 500:
                raise
        except (urllib.error.URLError, TimeoutError, ConnectionError) as exc:
            last = exc
        if attempt < len(RETRY_WAITS):
            time.sleep(RETRY_WAITS[attempt])
    raise last  # type: ignore[misc]


def link_key(link: str | None) -> str:
    """One key per document, whatever the source that found it. An arXiv link becomes its id,
    without the version: abs/2611.18493v1 and pdf/2611.18493v2 are the same paper. Any other
    link: no http, no www, no #part, no last slash. No link: no key."""
    link = (link or "").strip()
    if not link:
        return ""
    paper = re.search(r"arxiv\.org/(?:abs|pdf)/([^?#\s]+?)(?:v\d+)?(?:\.pdf)?/?(?:[?#].*)?$", link, re.I)
    if paper:
        return "arxiv:" + paper.group(1).lower()
    return re.sub(r"^https?://(www\.)?", "", link.split("#")[0], flags=re.I).rstrip("/").lower()


def one_per_link(found: list[dict], earlier: list[dict] | None = None) -> tuple[list[dict], int]:
    """Nothing twice across sources. `found` holds the records of this run, in the order of the
    sources. `earlier` holds the records already listed today. The first record with a link is
    kept. Each other source that found the same link is named on it, in `also_from`, and its own
    record is dropped. Returns the records kept from `found` and how many were dropped."""
    first: dict[str, dict] = {}
    for record in earlier or []:
        key = link_key(record.get("link"))
        if key:
            first.setdefault(key, record)
    kept, dropped = [], 0
    for record in found:
        record.setdefault("also_from", [])
        key = link_key(record.get("link"))
        if key and key in first:
            owner = first[key]
            name = record.get("source_name") or record.get("source") or ""
            others = owner.setdefault("also_from", [])
            if name and name != owner.get("source_name") and name not in others:
                others.append(name)
            dropped += 1
            continue
        if key:
            first[key] = record
        kept.append(record)
    return kept, dropped


def parse_date(text: str | None) -> datetime | None:
    if not text:
        return None
    text = text.strip()
    try:
        d = datetime.fromisoformat(text.replace("Z", "+00:00"))
    except ValueError:
        try:
            d = parsedate_to_datetime(text)
        except (TypeError, ValueError):
            return None
    return d if d.tzinfo else d.replace(tzinfo=timezone.utc)


# ---------- the two kinds of source ----------

def fetch_arxiv(src: dict, limit: int) -> list[dict]:
    global _last_arxiv_call
    wait = ARXIV_PAUSE - (time.monotonic() - _last_arxiv_call)
    if wait > 0:
        time.sleep(wait)
    params = {"search_query": src["query"], "start": 0, "max_results": limit,
              "sortBy": "submittedDate", "sortOrder": "descending"}
    body = http_get(ARXIV_API + "?" + urllib.parse.urlencode(params))
    _last_arxiv_call = time.monotonic()
    root = ET.fromstring(body)
    items = []
    for e in root.findall("a:entry", NS):
        link = (e.findtext("a:id", "", NS) or "").strip()
        authors = [clean(a.findtext("a:name", "", NS)) for a in e.findall("a:author", NS)]
        items.append({
            "key": link,
            "title": clean(e.findtext("a:title", "", NS)),
            "link": link,
            "published": parse_date(e.findtext("a:published", "", NS)),
            "authors": authors,
            "text": clean(e.findtext("a:summary", "", NS)),
        })
    return items


def fetch_rss(src: dict, limit: int) -> list[dict]:
    root = ET.fromstring(http_get(src["feed"]))
    items = []
    for it in root.iter("item"):  # RSS 2.0
        link = clean(it.findtext("link"))
        items.append({
            "key": clean(it.findtext("guid")) or link,
            "title": clean(it.findtext("title")),
            "link": link,
            "published": parse_date(it.findtext("pubDate")),
            "authors": [],
            "text": first_paragraph(it.findtext("description")),
        })
    for e in root.iter("{http://www.w3.org/2005/Atom}entry"):  # Atom
        link_el = e.find("a:link[@rel='alternate']", NS)
        if link_el is None:  # an Element with no child is falsy: never chain finds with "or"
            link_el = e.find("a:link", NS)
        link = link_el.get("href", "") if link_el is not None else ""
        items.append({
            "key": clean(e.findtext("a:id", "", NS)) or link,
            "title": clean(e.findtext("a:title", "", NS)),
            "link": link,
            "published": parse_date(e.findtext("a:published", "", NS) or e.findtext("a:updated", "", NS)),
            "authors": [clean(a.findtext("a:name", "", NS)) for a in e.findall("a:author", NS)],
            "text": first_paragraph(e.findtext("a:summary", "", NS) or e.findtext("a:content", "", NS)),
        })
    items.sort(key=lambda x: x["published"] or datetime.min.replace(tzinfo=timezone.utc), reverse=True)
    return items[:limit]


FETCHERS = {"arxiv": fetch_arxiv, "rss": fetch_rss}


# ---------- config and state ----------

def load_config(brain: Path) -> dict:
    path = brain / "2-ears" / "radar.json"
    if not path.exists():
        sys.exit(f"No radar for this brain: {path.relative_to(PROJECT) if path.is_relative_to(PROJECT) else path} "
                 "does not exist. Copy brains/_template/2-ears/radar.json, or run /build-ears.")
    try:
        cfg = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        sys.exit(f"radar.json is not valid JSON: {exc}")
    sources = cfg.get("sources") or []
    if not sources:
        sys.exit("radar.json holds no source. Add one under \"sources\".")
    problems = []
    ids = set()
    for i, s in enumerate(sources, 1):
        sid = s.get("id") or f"source {i}"
        if sid in ids:
            problems.append(f"{sid}: the id is used twice")
        ids.add(sid)
        kind = s.get("kind")
        if kind not in FETCHERS:
            problems.append(f"{sid}: kind must be arxiv or rss, not {kind!r}")
        elif kind == "arxiv" and not s.get("query"):
            problems.append(f"{sid}: an arxiv source needs a query")
        elif kind == "rss" and not s.get("feed"):
            problems.append(f"{sid}: an rss source needs a feed URL")
        if not s.get("name"):
            problems.append(f"{sid}: a name is needed, it is the title in the digest")
    if problems:
        sys.exit("radar.json has problems:\n  " + "\n  ".join(problems))
    if len(sources) > 3:
        print(f"Note: {len(sources)} sources. Three is a good start: a radar that lists too much is not read.")
    return cfg


def load_seen(path: Path) -> dict:
    try:
        return json.loads(path.read_text(encoding="utf-8")).get("items", {})
    except (FileNotFoundError, json.JSONDecodeError):
        return {}


def save_seen(path: Path, seen: dict, today: str) -> None:
    limit = (now_local() - timedelta(days=KEEP_SEEN_DAYS)).strftime("%Y-%m-%d")
    seen = {k: v for k, v in seen.items() if v >= limit}
    path.write_text(json.dumps({"written_by": "ops/tools/radar.py", "items": seen}, indent=1, ensure_ascii=False),
                    encoding="utf-8")


# ---------- the run ----------

def run(brain: Path) -> tuple[int, str, list[str]]:
    cfg = load_config(brain)
    out_dir = brain / "2-ears" / "radar"
    out_dir.mkdir(parents=True, exist_ok=True)
    seen_path = out_dir / "seen.json"
    seen = load_seen(seen_path)
    stamp = now_local()
    today = stamp.strftime("%Y-%m-%d")
    lookback = int(cfg.get("lookback_days", DEFAULT_LOOKBACK))
    oldest = stamp - timedelta(days=lookback)

    data_path = out_dir / f"{today}.json"
    try:
        earlier = json.loads(data_path.read_text(encoding="utf-8")).get("items", [])
    except (FileNotFoundError, json.JSONDecodeError):
        earlier = []

    # 1. Read every source. Nothing is written yet: two sources can bring the same item.
    results, failed = [], 0
    for src in cfg["sources"]:
        sid, limit = src["id"], int(src.get("max", cfg.get("max_per_source", DEFAULT_MAX)))
        try:
            fetched = FETCHERS[src["kind"]](src, 100)
        except Exception as exc:  # one source down never stops the others
            failed += 1
            results.append({"src": src, "error": exc})
            print(f"  {sid}: FAILED ({exc})")
            continue
        fresh = [it for it in fetched
                 if f"{sid}|{it['key']}" not in seen
                 and f"link|{link_key(it['link'])}" not in seen  # listed on an earlier day by another source
                 and (it["published"] is None or it["published"] >= oldest)]
        shown = fresh[:limit]
        for it in fresh:  # above the limit too: a second run brings nothing new
            seen[f"{sid}|{it['key']}"] = today
        pairs = [(it, {"source": sid, "source_name": src["name"], "title": it["title"], "link": it["link"],
                       "published": it["published"].isoformat() if it["published"] else None,
                       "authors": it["authors"], "text": it["text"],
                       "listed_at": stamp.isoformat(timespec="minutes")}) for it in shown]
        results.append({"src": src, "error": None, "fresh": fresh, "pairs": pairs, "limit": limit})
        print(f"  {sid}: {len(fetched)} read, {len(fresh)} new, {len(shown)} listed")

    # 2. Nothing twice across sources: one record per link, the other source named in "also_from".
    records, twice = one_per_link([record for res in results if res["error"] is None for _, record in res["pairs"]],
                                  earlier)
    kept = {id(record) for record in records}
    for record in records:
        if link_key(record["link"]):
            seen[f"link|{link_key(record['link'])}"] = today
    if twice:
        print(f"  {twice} item(s) found by two sources: listed once.")
    total_new = len(records)

    # 3. The page: one block per source.
    blocks = []
    for res in results:
        src = res["src"]
        head = f"## {src['name']}\n\n"
        if res["error"] is not None:
            exc = res["error"]
            blocks.append(head + f"Could not be read: {type(exc).__name__}: {exc}. "
                                 "It will be tried again at the next run.\n")
            continue
        fresh, limit = res["fresh"], res["limit"]
        listed = [(it, record) for it, record in res["pairs"] if id(record) in kept]
        if not fresh:
            blocks.append(head + "Nothing new.\n")
        else:
            more = (f" {len(fresh) - len(res['pairs'])} more were found above the limit of {limit} and are not listed:"
                    " narrow the search.") if len(fresh) > len(res["pairs"]) else ""
            double = len(res["pairs"]) - len(listed)
            more += f" {double} more already listed under another source: not listed twice." if double else ""
            lines = [head + f"{len(listed)} new.{more}\n"]
            for n, (it, record) in enumerate(listed, 1):
                when = it["published"].astimezone().strftime("%Y-%m-%d") if it["published"] else "no date"
                who = ""
                if it["authors"]:
                    names = it["authors"][:3]
                    who = ", ".join(names) + (" et al." if len(it["authors"]) > 3 else "")
                meta = f"{when}" + (f" · {who}" if who else "")
                also = f"- also found by: {', '.join(record['also_from'])}\n" if record.get("also_from") else ""
                lines.append(f"### {n}. {it['title'] or '(no title)'}\n"
                             f"- link: {it['link']}\n"
                             f"- published: {meta}\n"
                             + also +
                             f"- keep it: `/capture {it['link']}`\n"
                             + (f"\n> {it['text']}\n" if it["text"] else ""))
            blocks.append("\n".join(lines))

    digest = out_dir / f"{today}.md"
    run_line = (f"Run of {stamp.strftime('%H:%M')}: {total_new} new item(s) from {len(cfg['sources'])} source(s)"
                + (f", {failed} source(s) could not be read" if failed else "") + ".")
    if digest.exists():
        body = f"\n---\n\n# Run of {stamp.strftime('%H:%M')}\n\n{run_line}\n\n" + "\n".join(blocks)
        with digest.open("a", encoding="utf-8") as f:
            f.write(body)
    else:
        body = (f"# Radar, {today}\n\n"
                f"> Written by `ops/tools/radar.py`. Every item new since the last run, newest first, each\n"
                f"> with the same detail. It does not judge, rank or summarize. Keep an item with `/capture`\n"
                f"> and its link: Emma files it, then Chloe and Cato can work on it.\n\n"
                f"{run_line}\n\n" + "\n".join(blocks))
        digest.write_text(body, encoding="utf-8")
    data_path.write_text(json.dumps({"written_by": "ops/tools/radar.py", "date": today, "items": earlier + records},
                                    indent=1, ensure_ascii=False), encoding="utf-8")
    save_seen(seen_path, seen, today)
    rel = digest.relative_to(PROJECT) if digest.is_relative_to(PROJECT) else digest
    print(f"{run_line}\nDigest: {rel}")
    outputs = [(p.relative_to(PROJECT) if p.is_relative_to(PROJECT) else p).as_posix() for p in (digest, data_path)]
    return (1 if failed == len(cfg["sources"]) else 0), run_line, outputs


def run_logged(brain: Path) -> int:
    """The run, between its start line and its stop line in the run log."""
    log_run("start", "running", f"Radar: reading the sources of {brain.name}/2-ears/radar.json")
    try:
        code, run_line, outputs = run(brain)
    except BaseException as exc:  # a missing radar.json, a crash, Ctrl+C: the stop line says so
        if isinstance(exc, SystemExit) and not isinstance(exc.code, (int, type(None))):
            reason = str(exc.code)
        else:
            reason = f"{type(exc).__name__}: {exc}"
        log_run("stop", "failed", f"Radar stopped: {reason}")
        raise
    log_run("stop", "failed" if code else "done", run_line, outputs)
    return code


def check(brain: Path) -> int:
    cfg = load_config(brain)
    bad = 0
    for src in cfg["sources"]:
        try:
            items = FETCHERS[src["kind"]](src, 5)
            newest = next((i["published"] for i in items if i["published"]), None)
            if not items:
                bad += 1
                print(f"  EMPTY {src['id']}: it answers, but finds nothing. Check the query or the feed URL.")
                continue
            print(f"  OK    {src['id']}: {len(items)} item(s) read"
                  + (f", newest {newest.astimezone().strftime('%Y-%m-%d')}" if newest else ""))
        except Exception as exc:
            bad += 1
            print(f"  FAIL  {src['id']}: {type(exc).__name__}: {exc}")
    print("Nothing was written.")
    return 1 if bad else 0


def print_schedule(brain_arg: str) -> int:
    py = sys.executable
    script = Path(__file__).resolve()
    extra = "" if brain_arg == "brain" else f" --brain {brain_arg}"
    if platform.system() == "Windows":
        print("Windows: paste these four lines in PowerShell (not as administrator). The task runs every day\n"
              "at 07:00, and as soon as the computer wakes up if it was off at 07:00.\n")
        print(f'$a = New-ScheduledTaskAction -Execute "{py}" -Argument \'"{script}"{extra}\' -WorkingDirectory "{PROJECT}"')
        print("$t = New-ScheduledTaskTrigger -Daily -At 7am")
        print("$s = New-ScheduledTaskSettingsSet -StartWhenAvailable")
        print('Register-ScheduledTask -TaskName "second-brain radar" -Action $a -Trigger $t -Settings $s')
        print('\nTo test it now:  Start-ScheduledTask -TaskName "second-brain radar"')
        print('To remove it:    Unregister-ScheduledTask -TaskName "second-brain radar"')
    else:
        print("Mac or Linux: type `crontab -e` and add this line. It runs every day at 07:00,\n"
              "only when the computer is awake at that time.\n")
        print(f'0 7 * * * cd "{PROJECT}" && "{py}" "{script}"{extra}')
        print("\nTo remove it: `crontab -e` and delete the line.")
    print("\nNothing was registered. The schedule is yours to add, and to remove.")
    return 0


def main() -> int:
    ap = argparse.ArgumentParser(
        description="The daily radar: new items of a few sources, in brain/2-ears/radar/<date>.md. No AI inside.",
        epilog="Example: python ops/tools/radar.py --check, then python ops/tools/radar.py")
    ap.add_argument("--brain", default="brain", help="the brain folder (default: brain, the active one)")
    mode = ap.add_mutually_exclusive_group()
    mode.add_argument("--check", action="store_true", help="read each source once, write nothing")
    mode.add_argument("--print-schedule", action="store_true", help="print the command that runs it daily at 07:00")
    args = ap.parse_args()
    if args.print_schedule:
        return print_schedule(args.brain)
    brain = resolve(args.brain)
    if not (brain / "BRAIN.md").exists():
        sys.exit(f"No brain in {brain}: BRAIN.md is missing. Start with /build-self, then /build-ears.")
    return check(brain) if args.check else run_logged(brain)


if __name__ == "__main__":
    sys.exit(main())
