"""The library of a brain: your own knowledge, turned into text and filed. No AI inside.

Reads   my-knowledge/                       what you know: courses, a book, slides, notebooks, notes
        brain/1-self/rules.md               its section "## Private words", when there is one
Writes  brain/2-ears/library.md             the page: one line per folder, what is filed, what waits
        brain/2-ears/library/state.json     the same, as data, for the screen
        brain/2-ears/library/seen.json      what was filed and what you left out, so nothing comes twice
        brain/2-ears/sources/<slug>.md      one text file per document filed (commands file and fetch)
        ops/runs/<date>.jsonl               a start line and a stop line (agent "library", source "tool"),
                                            so Alfred and the screen know when it runs and when it ended

The Self step never reads my-knowledge/. The Ears step files it, folder by folder, on your word.
The originals are never changed, moved or deleted. A filed document is text in sources/, nothing
more: Condense turns it into a knowledge card (a summary, then a check).

Usage (from the project folder, or from anywhere: paths are taken from this file):
  python ops/tools/library.py scan                          read everything, count, file nothing
  python ops/tools/library.py file "Training/Module-2"      convert and file one folder
  python ops/tools/library.py file --all --except old       every folder, without what is named "old"
  python ops/tools/library.py file Book --private mask      private words become [private]
  python ops/tools/library.py leave-out "Training/Module-4" the scan stops proposing this folder
  python ops/tools/library.py fetch https://arxiv.org/abs/1706.03762   one outside document, on your word
  python ops/tools/library.py convert brain/1-self/_raw     a PDF, a Word file or slides become .txt
  python ops/tools/library.py status                        is it running, the last run, the totals

What is read: .md .markdown .txt .rst (everything), .py (the code, in a block), .ipynb (text cells
and code cells in order, outputs dropped), .pptx (text per slide, in the slide order, with the
speaker notes), .docx (paragraphs, headings, tables), .html .htm (the text), .pdf (the text,
through pdftotext, which comes with Git for Windows, or through pypdf when it is installed).
Anything else is listed as not readable, with the reason and what to do.

The table groups the files by the first two folders of their path: Training/Module-2/old/x.ipynb
belongs to the row Training/Module-2. Files at the top of my-knowledge/ are the row (top).
Each readable file is in one place only: filed, waiting, duplicate or left out.
The column "Private words" counts the waiting documents that hold one of your private words.

What you left out stays out: a folder (leave-out), or files (--except, --private skip). "file --all"
never takes it back. Naming a folder decides again for that folder: "file FOLDER" takes back the
folder and every file of it that was left out, unless the same command leaves them out again.

Private words: one "- word" per line under "## Private words" in brain/1-self/rules.md. They are
looked for in file names and in the text, with no difference between capitals and small letters.
A word of four letters or more is caught anywhere, also inside a longer word. A shorter one is
caught only when it stands alone. In the page, the data and the run log, a private word in a path
is always written [private]. Long dashes of a document are written as commas (house rule).
"""

from __future__ import annotations

import argparse
import gzip
import hashlib
import io
import json
import os
import posixpath
import re
import shutil
import subprocess
import sys
import tempfile
import time
import unicodedata
import urllib.error
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
import zipfile
from datetime import datetime, timedelta
from html.parser import HTMLParser
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[2]
USER_AGENT = "second-brain-library/1.0 (personal reading list)"
WRITTEN_BY = "ops/tools/library.py"
TOP = "(top)"                # the row of the files at the top of the knowledge folder
FETCHED = "(fetched)"        # the folder of a document brought by the command fetch
MASK = "[private]"
TEXT_TYPES = (".md", ".markdown", ".txt", ".rst")
CODE_TYPES = {".py": "python"}
READABLE = TEXT_TYPES + tuple(CODE_TYPES) + (".ipynb", ".pptx", ".docx", ".html", ".htm", ".pdf")
MAX_DOWNLOAD = 60_000_000    # bytes: a larger download is refused
PDF_TIMEOUT = 180            # seconds for one PDF
STUCK_AFTER = 45             # minutes: a start line with no stop line after that is not a run any more
SLUG_MAX = 80

WHY_NOT = {
    "old .ppt format: open it and save it as .pptx": (".ppt", ".pps", ".pot"),
    "old .doc format: open it and save it as .docx": (".doc", ".dot"),
    "an image: no text is read from a picture. Write what it says in a .md file if it matters":
        (".png", ".jpg", ".jpeg", ".gif", ".bmp", ".webp", ".tif", ".tiff", ".svg", ".ico", ".heic"),
    "a video or a sound file: add its transcript as a .txt file":
        (".mp4", ".mov", ".avi", ".mkv", ".webm", ".wmv", ".mp3", ".wav", ".m4a", ".ogg", ".flac"),
    "a data file: describe it in a .md file if it matters":
        (".csv", ".tsv", ".json", ".jsonl", ".xlsx", ".xls", ".xlsm", ".ods", ".xml", ".yaml", ".yml",
         ".toml", ".parquet", ".pkl", ".pickle", ".npy", ".npz", ".db", ".sqlite", ".h5"),
    "an archive: unzip it first": (".zip", ".tar", ".gz", ".tgz", ".7z", ".rar"),
    "save it as .docx or as .pdf": (".odt", ".rtf", ".pages"),
    "save it as .pptx or as .pdf": (".odp", ".key"),
    "an e-book file: save it as .pdf or as .txt": (".epub", ".mobi"),
}


# ---------- small helpers ----------

def now_local() -> datetime:
    return datetime.now().astimezone()


def stamp() -> str:
    return datetime.now().replace(microsecond=0).isoformat()


def log_run(event: str, status: str, summary: str = "", outputs: list | None = None) -> None:
    """One line in ops/runs/<date>.jsonl, the run log of the project (house rule 7), in the shape
    of the skill run-trace. A start with no stop yet: the library is running. Never stops the run."""
    moment = datetime.now().replace(microsecond=0)
    record = {"ts": moment.isoformat(), "agent": "library", "event": event, "status": status,
              "routine": "library", "summary": " ".join(summary.split())[:300], "outputs": outputs or [],
              "verdict": None, "source": "tool"}
    try:
        folder = PROJECT / "ops" / "runs"
        folder.mkdir(parents=True, exist_ok=True)
        with open(folder / f"{moment.date().isoformat()}.jsonl", "a", encoding="utf-8", newline="\n") as handle:
            handle.write(json.dumps(record, ensure_ascii=False, separators=(",", ":")) + "\n")
    except OSError as exc:
        print(f"Note: the run log could not be written ({exc}).")


def resolve(path: str) -> Path:
    p = Path(path)
    return p if p.is_absolute() else PROJECT / p


def rel(path: Path) -> str:
    """A path from the project folder, with forward slashes."""
    try:
        return path.resolve().relative_to(PROJECT).as_posix()
    except (ValueError, OSError):
        return path.as_posix()


def write_text(path: Path, text: str) -> None:
    """Write through a temporary file, so the screen never reads half a file. Line ends: LF."""
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + ".tmp")
    with open(temp, "w", encoding="utf-8", newline="\n") as handle:
        handle.write(text)
    for _ in range(10):
        try:
            os.replace(temp, path)
            return
        except PermissionError:  # Windows: another program is reading the file right now
            time.sleep(0.05)
    with open(path, "w", encoding="utf-8", newline="\n") as handle:
        handle.write(text)
    try:
        temp.unlink()
    except OSError:
        pass


def write_json(path: Path, data) -> None:
    write_text(path, json.dumps(data, indent=1, ensure_ascii=False) + "\n")


def read_json(path: Path, default=None):
    try:
        return json.loads(path.read_text(encoding="utf-8-sig"))
    except (OSError, ValueError):
        return default


def reason_of(exc: BaseException) -> str:
    """An error in a few words, with a path from the project folder, never the full one."""
    if isinstance(exc, OSError) and exc.filename:
        text = f"{exc.strerror or type(exc).__name__}: {rel(Path(str(exc.filename)))}"
    else:
        text = f"{type(exc).__name__}: {exc}"
    for full, short in ((str(PROJECT), "."), (str(Path.home()), "~")):
        for form in (full, full.replace("\\", "/"), full.replace("\\", "\\\\")):
            text = text.replace(form, short)
    return " ".join(text.split())


def pid(text: str) -> str:
    """A short id of a path or of a link. It names a file without showing its name."""
    return hashlib.sha256(text.casefold().encode("utf-8")).hexdigest()[:16]


def decode(data: bytes) -> str:
    if data[:2] in (b"\xff\xfe", b"\xfe\xff"):
        return data.decode("utf-16", errors="replace")
    try:
        return data.decode("utf-8-sig")
    except UnicodeDecodeError:
        return data.decode("cp1252", errors="replace")


def tidy(text: str) -> str:
    """LF line ends, no long dash (house rule), no space at the end of a line, one blank line at most."""
    text = text.replace("\r\n", "\n").replace("\r", "\n").replace("\x00", "")
    text = re.sub(r"[ \t]*" + chr(0x2014) + r"[ \t]*", ", ", text).replace(chr(0x2013), "-")
    text = "\n".join(line.rstrip() for line in text.split("\n"))
    return re.sub(r"\n{3,}", "\n\n", text).strip("\n")


def one_line(text: str) -> str:
    return " ".join(tidy(text or "").split())


def clean_name(stem: str) -> str:
    return " ".join(re.sub(r"[_\-.]+", " ", stem).split()) or "document"


def slugify(text: str) -> str:
    text = unicodedata.normalize("NFKD", text).encode("ascii", "ignore").decode("ascii").lower()
    text = re.sub(r"[^a-z0-9]+", "-", text).strip("-")
    return text[:SLUG_MAX].strip("-") or "document"


def fenced(code: str, lang: str = "") -> str:
    fence = "```"
    while fence in code:
        fence += "`"
    return f"{fence}{lang}\n{code}\n{fence}"


# ---------- from a file to text ----------

class NotReadable(Exception):
    """This file cannot become text here. The message says why, and what to do."""


class Doc:
    """A converted document: its text, its title when it has one, and what was kept, in a few words."""

    def __init__(self, text: str, title: str = "", kept: str = "everything"):
        self.text, self.title, self.kept = text, title, kept
        self.words = 0


def why_not(ext: str) -> str:
    """The reason a type is not read, or "" when it is read."""
    if ext in READABLE:
        return ""
    for why, types in WHY_NOT.items():
        if ext in types:
            return why
    if not ext:
        return "no file type in its name: save it as .md, .txt, .pdf, .docx or .pptx"
    return f"the type {ext} is not read: save it as .md, .txt, .pdf, .docx or .pptx"


HEADING = re.compile(r"^(#{1,6})\s+(.+?)\s*#*\s*$")


def plain_title(text: str) -> str:
    text = re.sub(r"<[^>]+>", " ", text)
    text = re.sub(r"!?\[([^\]]*)\]\([^)]*\)", r"\1", text)
    return one_line(text.replace("*", "").replace("`", ""))


def first_heading(text: str) -> str:
    """The first heading of a markdown text, code blocks left aside. Else a line that is underlined."""
    lines = text.split("\n")
    fence = False
    for line in lines:
        s = line.strip()
        if s.startswith("```") or s.startswith("~~~"):
            fence = not fence
            continue
        if fence:
            continue
        m = HEADING.match(s)
        if m and plain_title(m.group(2)):
            return plain_title(m.group(2))
    marks = set("=-~*^")
    for i in range(min(len(lines) - 1, 30)):
        a, b = lines[i].strip(), lines[i + 1].strip()
        if a and len(b) >= 3 and len(set(b)) == 1 and set(b) <= marks and not set(a) <= marks:
            return plain_title(a)
    return ""


def conv_text(data: bytes) -> Doc:
    text = tidy(decode(data))
    return Doc(text, first_heading(text), "everything")


def conv_code(data: bytes, lang: str) -> Doc:
    return Doc(fenced(tidy(decode(data)), lang), "", "the code, in one block")


def conv_notebook(data: bytes) -> Doc:
    try:
        nb = json.loads(decode(data))
    except ValueError:
        raise NotReadable("not a valid notebook (its JSON is damaged): open it and save it again")
    if not isinstance(nb, dict):
        raise NotReadable("not a notebook")
    cells = nb.get("cells")
    if cells is None:  # the old notebook format
        cells = [c for sheet in nb.get("worksheets") or [] for c in sheet.get("cells") or []]
    meta = nb.get("metadata") or {}
    lang = ((meta.get("kernelspec") or {}).get("language") or (meta.get("language_info") or {}).get("name")
            or "python").lower()
    parts, n_text, n_code = [], 0, 0
    for cell in cells:
        source = cell.get("source", cell.get("input", ""))
        if isinstance(source, list):
            source = "".join(str(piece) for piece in source)
        source = re.sub(r"data:image/[\w.+-]+;base64,[A-Za-z0-9+/=]+", "data:image", str(source))  # pasted pictures
        source = tidy(source)
        if not source.strip():
            continue
        kind = cell.get("cell_type")
        if kind == "code":
            parts.append(fenced(source, lang))
            n_code += 1
        else:
            if kind == "heading":
                source = "#" * int(cell.get("level") or 1) + " " + source
            parts.append(source)
            n_text += 1
    text = "\n\n".join(parts)
    return Doc(text, first_heading(text), f"{n_text} text cell(s) and {n_code} code cell(s), outputs dropped")


# Office files are zip folders of XML. Tags are read by their name, whatever the namespace.

def local(tag) -> str:
    return tag.rsplit("}", 1)[-1] if isinstance(tag, str) else ""


def attr(el, name: str) -> str:
    for key, value in el.attrib.items():
        if local(key) == name:
            return value
    return ""


def zip_xml(zf: zipfile.ZipFile, name: str):
    try:
        return ET.fromstring(zf.read(name))
    except (KeyError, ET.ParseError):
        return None


def open_zip(data: bytes, kind: str) -> zipfile.ZipFile:
    try:
        return zipfile.ZipFile(io.BytesIO(data))
    except zipfile.BadZipFile:
        raise NotReadable(f"not a real {kind} file, or protected by a password: open it and save it again")


def rels_of(zf: zipfile.ZipFile, part: str) -> dict:
    """The links of one part of an Office file: {id: (type, the part it points to)}."""
    folder, name = posixpath.split(part)
    root = zip_xml(zf, f"{folder}/_rels/{name}.rels")
    out = {}
    if root is None:
        return out
    for link in root:
        if local(link.tag) != "Relationship" or link.get("TargetMode") == "External":
            continue
        target = link.get("Target", "")
        target = target.lstrip("/") if target.startswith("/") else posixpath.normpath(posixpath.join(folder, target))
        out[link.get("Id", "")] = (link.get("Type", ""), target)
    return out


def para_text(p) -> str:
    """The text of one paragraph of a slide. A line break inside it stays a line break."""
    out = []
    for el in p.iter():
        name = local(el.tag)
        if name == "t" and el.text:
            out.append(el.text)
        elif name == "br":
            out.append("\n")
    return "".join(out)


def placeholder(shape):
    """The kind of placeholder of a shape (title, body, sldNum...), or None for a plain text box."""
    for el in shape.iter():
        if local(el.tag) == "ph":
            return el.get("type", "body")
    return None


def shape_lines(shape) -> list[str]:
    """The lines of a shape. A paragraph below the first level becomes a bullet."""
    lines = []
    for body in shape:
        if local(body.tag) != "txBody":
            continue
        for p in body:
            if local(p.tag) != "p":
                continue
            level = 0
            for child in p:
                if local(child.tag) == "pPr":
                    level = int(child.get("lvl") or 0)
            for piece in para_text(p).split("\n"):
                piece = " ".join(piece.split())
                if piece:
                    lines.append("  " * (level - 1) + "- " + piece if level > 0 else piece)
    return lines


def frame_of(shape) -> dict:
    """The place and the size of a shape or of a group, as written in the file: {"off": (x, y), ...}."""
    out = {}
    for props in shape:
        if local(props.tag) not in ("spPr", "grpSpPr"):
            continue
        for xfrm in props:
            if local(xfrm.tag) != "xfrm":
                continue
            for el in xfrm:
                try:
                    pair = (float(el.get("x", el.get("cx", ""))), float(el.get("y", el.get("cy", ""))))
                except ValueError:
                    continue
                out[local(el.tag)] = pair
    return out


def slide_blocks(root, height: float = 0) -> tuple[str, list[str], bool]:
    """The title of a slide, its blocks of text in the order of the slide, and whether the title
    was guessed. A slide made without a title box (many exports) has no title in the file: the
    guess is the short line of text that sits highest, in the top third of the slide."""
    found = {"title": ""}
    blocks: list = []   # [text, how high it sits on the slide or None]

    def walk(node, scale: float, shift: float) -> None:
        for child in node:
            name = local(child.tag)
            if name == "sp":
                kind = placeholder(child)
                if kind in ("sldNum", "dt", "ftr", "hdr"):
                    continue
                lines = shape_lines(child)
                if not lines:
                    continue
                if kind in ("title", "ctrTitle") and not found["title"]:
                    found["title"] = " ".join(lines)
                else:
                    off = frame_of(child).get("off")
                    blocks.append(["\n".join(lines), off[1] * scale + shift if off else None])
            elif name == "grpSp":
                frame = frame_of(child)
                inner_scale, inner_shift = scale, shift
                if all(key in frame for key in ("off", "ext", "chOff", "chExt")) and frame["chExt"][1]:
                    ratio = frame["ext"][1] / frame["chExt"][1]
                    inner_scale = ratio * scale
                    inner_shift = (frame["off"][1] - frame["chOff"][1] * ratio) * scale + shift
                walk(child, inner_scale, inner_shift)
            elif name == "AlternateContent":
                for option in child:
                    if local(option.tag) == "Choice":
                        walk(option, scale, shift)
                        break
            elif name == "graphicFrame":
                for table in child.iter():
                    if local(table.tag) != "tbl":
                        continue
                    rows = []
                    for row in table:
                        if local(row.tag) != "tr":
                            continue
                        cells = [" ".join(" ".join(para_text(p) for p in cell.iter() if local(p.tag) == "p").split())
                                 for cell in row if local(cell.tag) == "tc"]
                        if any(cells):
                            rows.append(" | ".join(cells))
                    if rows:
                        blocks.append(["\n".join(rows), None])

    for el in root.iter():
        if local(el.tag) == "spTree":
            walk(el, 1.0, 0.0)
            break
    guessed = False
    if not found["title"] and height:
        short = [b for b in blocks if b[1] is not None and 0 <= b[1] <= height / 3 and "\n" not in b[0]
                 and not b[0].startswith("- ") and len(b[0].split()) <= 15 and re.search(r"[^\W\d_]{2}", b[0])]
        if short:
            top = min(short, key=lambda b: b[1])
            found["title"], guessed = top[0], True
            blocks.remove(top)
    return found["title"], [b[0] for b in blocks], guessed


def slide_parts(zf: zipfile.ZipFile) -> tuple[list[str], float]:
    """The slides in the order of the presentation (else in the order of their number), and the
    height of a slide."""
    names = set(zf.namelist())
    ordered: list[str] = []
    height = 0.0
    deck = zip_xml(zf, "ppt/presentation.xml")
    links = rels_of(zf, "ppt/presentation.xml")
    if deck is not None:
        for el in deck.iter():
            if local(el.tag) == "sldSz":
                try:
                    height = float(el.get("cy") or 0)
                except ValueError:
                    height = 0.0
            if local(el.tag) != "sldId":
                continue
            link_id = next((v for k, v in el.attrib.items() if k.endswith("}id")), "")
            target = links.get(link_id, ("", ""))[1]
            if target in names and target not in ordered:
                ordered.append(target)
    if not ordered:
        slides = [n for n in names if re.fullmatch(r"ppt/slides/slide\d+\.xml", n)]
        ordered = sorted(slides, key=lambda n: int(re.search(r"(\d+)\.xml$", n).group(1)))
    return ordered, height


def conv_pptx(data: bytes) -> Doc:
    with open_zip(data, ".pptx") as zf:
        parts, height = slide_parts(zf)
        if not parts:
            raise NotReadable("no slide inside")
        out, first_title, notes_count, guesses, any_text = [], "", 0, 0, False
        for number, part in enumerate(parts, 1):
            root = zip_xml(zf, part)
            if root is None:
                continue
            title, blocks, guessed = slide_blocks(root, height)
            guesses += guessed
            notes = ""
            for kind, target in rels_of(zf, part).values():
                other = zip_xml(zf, target) if kind.endswith(("/notesSlide", "/diagramData")) else None
                if other is None:
                    continue
                if kind.endswith("/notesSlide"):
                    lines = [line for shape in other.iter() if local(shape.tag) == "sp" and placeholder(shape) == "body"
                             for line in shape_lines(shape)]
                    notes = "\n".join(lines)
                else:  # a diagram (SmartArt): its words are kept, one per line
                    words = [" ".join(para_text(p).split()) for p in other.iter() if local(p.tag) == "p"]
                    words = ["- " + w for w in words if w]
                    if words:
                        blocks.append("\n".join(words))
            if number == 1:
                first_title = title
            piece = [f"## Slide {number}: {title}" if title else f"## Slide {number}"] + blocks
            if notes:
                piece.append("Notes: " + notes)
                notes_count += 1
            any_text = any_text or bool(title or blocks or notes)
            out.append("\n\n".join(piece))
    if not any_text:
        raise NotReadable("no text in the slides (pictures only)")
    kept = f"text of {len(parts)} slide(s)" + (f", {notes_count} with speaker notes" if notes_count else "")
    if guesses:
        kept += f", {guesses} title(s) guessed from the top line of the slide"
    return Doc("\n\n".join(out), first_title, kept)


def docx_runs(node):
    """The pieces of text under a node of a Word file, deleted text and settings left aside."""
    for child in node:
        name = local(child.tag)
        if name in ("pPr", "rPr", "del", "delText", "instrText", "Fallback"):
            continue
        if name == "t":
            yield child.text or ""
        elif name == "tab":
            yield "\t"
        elif name in ("br", "cr"):
            yield "\n"
        elif name == "noBreakHyphen":
            yield "-"
        else:
            yield from docx_runs(child)


def docx_heading_styles(zf: zipfile.ZipFile) -> dict:
    """The styles that are headings: {style id: level}. Read from the style names, so any language."""
    levels = {}
    root = zip_xml(zf, "word/styles.xml")
    if root is None:
        return levels
    for style in root.iter():
        if local(style.tag) != "style":
            continue
        name = next((attr(c, "val").lower() for c in style if local(c.tag) == "name"), "")
        m = re.fullmatch(r"heading (\d)", name)
        if m:
            levels[attr(style, "styleId")] = int(m.group(1))
        elif name == "title":
            levels[attr(style, "styleId")] = 1
    return levels


def docx_blocks(node, levels: dict, out: list) -> None:
    """Appends (kind, text) for each paragraph and table under a node, in order."""
    for child in node:
        name = local(child.tag)
        if name == "p":
            style, in_list, depth = "", False, 0
            for props in child:
                if local(props.tag) != "pPr":
                    continue
                for prop in props:
                    if local(prop.tag) == "pStyle":
                        style = attr(prop, "val")
                    elif local(prop.tag) == "numPr":
                        in_list = True
                        depth = next((int(attr(e, "val") or 0) for e in prop if local(e.tag) == "ilvl"), 0)
            text = re.sub(r"[ \t]+", " ", "".join(docx_runs(child))).strip()
            if not text:
                continue
            level = levels.get(style, 0)
            if not level:
                m = re.fullmatch(r"(?i)heading\s*(\d)", style or "")
                level = int(m.group(1)) if m else 0
            if level:
                out.append(("heading", "#" * min(level, 6) + " " + " ".join(text.split())))
            elif in_list:
                out.append(("item", "  " * depth + "- " + " ".join(text.split())))
            else:
                out.append(("text", text))
        elif name == "tbl":
            rows = []
            for row in child:
                if local(row.tag) != "tr":
                    continue
                cells = [" ".join(" ".join("".join(docx_runs(p)) for p in cell.iter() if local(p.tag) == "p").split())
                         for cell in row if local(cell.tag) == "tc"]
                if any(cells):
                    rows.append(" | ".join(cells))
            if rows:
                out.append(("text", "\n".join(rows)))
        elif name in ("sdt", "sdtContent", "body", "document"):
            docx_blocks(child, levels, out)


def conv_docx(data: bytes) -> Doc:
    with open_zip(data, ".docx") as zf:
        root = zip_xml(zf, "word/document.xml")
        if root is None:
            raise NotReadable("not a real .docx file: open it in Word and save it again")
        blocks: list = []
        docx_blocks(root, docx_heading_styles(zf), blocks)
    title = next((text.lstrip("#").strip() for kind, text in blocks if kind == "heading"), "")
    pieces: list[str] = []
    for i, (kind, text) in enumerate(blocks):
        if i:
            pieces.append("\n" if kind == "item" and blocks[i - 1][0] == "item" else "\n\n")
        pieces.append(text)
    return Doc("".join(pieces), title, "paragraphs, headings and tables")


class PageText(HTMLParser):
    """The text of a web page: headings as #, list items as "-", scripts, styles and menus dropped."""

    SKIP = {"script", "style", "noscript", "template", "svg", "nav", "button", "select", "iframe"}
    BLOCK = {"p", "div", "section", "article", "main", "header", "footer", "aside", "ul", "ol", "table",
             "blockquote", "figure", "figcaption", "dl", "dt", "dd", "hr"}
    HEADINGS = {"h1", "h2", "h3", "h4", "h5", "h6"}

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.out: list[str] = []
        self.skip = 0
        self.head = False
        self.in_title = False
        self.in_h1 = False
        self.pre = 0
        self.cells = 0
        self.title: list[str] = []
        self.h1: list[str] = []

    def handle_starttag(self, tag, attrs):
        if tag in self.SKIP:
            self.skip += 1
        elif self.skip:
            return
        elif tag == "head":
            self.head = True
        elif tag == "body":
            self.head = False
        elif tag == "title":
            self.in_title = self.head
        elif tag in self.HEADINGS:
            self.out.append("\n\n" + "#" * int(tag[1]) + " ")
            self.in_h1 = tag == "h1" and not "".join(self.h1).strip()
        elif tag == "li":
            self.out.append("\n- ")
        elif tag == "br":
            self.out.append("\n")
        elif tag == "tr":
            self.cells = 0
        elif tag in ("td", "th"):
            if self.cells:
                self.out.append(" | ")
            self.cells += 1
        elif tag == "pre":
            self.pre += 1
            self.out.append("\n\n```\n")
        elif tag in self.BLOCK:
            self.out.append("\n\n")

    def handle_endtag(self, tag):
        if tag in self.SKIP:
            self.skip = max(0, self.skip - 1)
        elif self.skip:
            return
        elif tag == "head":
            self.head = False
        elif tag == "title":
            self.in_title = False
        elif tag in self.HEADINGS:
            self.out.append("\n\n")
            self.in_h1 = False
        elif tag == "pre":
            self.pre = max(0, self.pre - 1)
            self.out.append("\n```\n\n")
        elif tag in self.BLOCK or tag == "tr":
            self.out.append("\n\n" if tag != "tr" else "\n")

    def handle_data(self, data):
        if self.skip:
            return
        if self.in_title:
            self.title.append(data)
            return
        if self.head:
            return
        if self.in_h1:
            self.h1.append(data)
        self.out.append(data if self.pre else re.sub(r"\s+", " ", data))


def conv_html(data: bytes) -> Doc:
    declared = re.search(rb"charset\s*=\s*[\"']?\s*([\w-]+)", data[:4096], re.I)
    text = None
    if declared:
        try:
            text = data.decode(declared.group(1).decode("ascii", "ignore"), errors="replace")
        except LookupError:
            text = None
    parser = PageText()
    parser.feed(text if text is not None else decode(data))
    parser.close()
    lines, fence = [], False
    for line in "".join(parser.out).split("\n"):
        if line.strip() == "```":
            fence = not fence
            lines.append("```")
        elif fence:
            lines.append(line.rstrip())
        elif not re.fullmatch(r"\s*#{1,6}\s*", line):   # a heading with no text is dropped
            lines.append(" ".join(line.split()))
    # The <title> of a page names the page; its first big heading is often the name of the site.
    title = one_line("".join(parser.title)).split(" | ")[0].strip() or one_line("".join(parser.h1))
    return Doc("\n".join(lines), title, "the text of the page, scripts and menus dropped")


_PDF_READER: list = []


def pdf_reader() -> tuple:
    """What reads a PDF on this computer: ("pdftotext", its path), ("pypdf", the module) or (None, None)."""
    if _PDF_READER:
        return _PDF_READER[0]
    exe = shutil.which("pdftotext")
    if not exe:
        places = []
        for var in ("ProgramFiles", "ProgramW6432", "ProgramFiles(x86)", "LOCALAPPDATA"):
            base = os.environ.get(var)
            if base:
                places.append(Path(base) / "Git" / "mingw64" / "bin" / "pdftotext.exe")
                places.append(Path(base) / "Programs" / "Git" / "mingw64" / "bin" / "pdftotext.exe")
        git = shutil.which("git")
        if git:
            home = Path(git).resolve().parent
            places += [home / "pdftotext.exe", home.parent / "mingw64" / "bin" / "pdftotext.exe",
                       home.parent.parent / "mingw64" / "bin" / "pdftotext.exe"]
        places += [Path("/opt/homebrew/bin/pdftotext"), Path("/usr/local/bin/pdftotext"), Path("/usr/bin/pdftotext")]
        exe = next((str(p) for p in places if p.is_file()), None)
    found: tuple = (None, None)
    if exe:
        found = ("pdftotext", exe)
    else:
        for name in ("pypdf", "PyPDF2"):
            try:
                found = ("pypdf", __import__(name))
                break
            except Exception:
                continue
    _PDF_READER.append(found)
    return found


def conv_pdf(data: bytes) -> Doc:
    if b"%PDF" not in data[:1024]:
        raise NotReadable("not a real PDF (it does not start with %PDF)")
    kind, tool = pdf_reader()
    if kind is None:
        raise NotReadable("no PDF reader on this computer: install Git for Windows (it brings pdftotext), "
                          "or save the PDF as text")
    if kind == "pdftotext":
        handle, temp = tempfile.mkstemp(suffix=".pdf")  # a plain name: the tool is weak on accents and long paths
        try:
            with os.fdopen(handle, "wb") as copy:
                copy.write(data)
            try:
                done = subprocess.run([tool, "-enc", "UTF-8", temp, "-"], capture_output=True, timeout=PDF_TIMEOUT)
            except subprocess.TimeoutExpired:
                raise NotReadable(f"too long to read (more than {PDF_TIMEOUT // 60} minutes)")
            except OSError as exc:
                raise NotReadable(f"pdftotext did not start ({exc.strerror or type(exc).__name__})")
        finally:
            try:
                os.unlink(temp)
            except OSError:
                pass
        if done.returncode != 0:
            locked = b"assword" in done.stderr or b"ncrypt" in done.stderr
            raise NotReadable("protected by a password: save a copy without it" if locked
                              else "pdftotext could not read it: the file may be damaged")
        text = done.stdout.decode("utf-8", errors="replace")
    else:
        pages = [page.extract_text() or "" for page in tool.PdfReader(io.BytesIO(data)).pages]
        text = "\f".join(pages)
    pages_count = text.count("\f") + (0 if text.endswith("\f") or not text else 1)
    text = tidy(text.replace("\f", "\n\n"))
    if not text.split():
        raise NotReadable("no text inside (scanned pages): it needs a text version, there is no OCR here")
    return Doc(text, "", f"text of {pages_count} page(s) through {kind}, layout lost")


def convert(name: str, data: bytes) -> Doc:
    """The text of one file, from its bytes and its name. Raises NotReadable with the reason."""
    ext = Path(name).suffix.lower()
    why = why_not(ext)
    if why:
        raise NotReadable(why)
    try:
        if ext in TEXT_TYPES:
            doc = conv_text(data)
        elif ext in CODE_TYPES:
            doc = conv_code(data, CODE_TYPES[ext])
        elif ext == ".ipynb":
            doc = conv_notebook(data)
        elif ext == ".pptx":
            doc = conv_pptx(data)
        elif ext == ".docx":
            doc = conv_docx(data)
        elif ext == ".pdf":
            doc = conv_pdf(data)
        else:
            doc = conv_html(data)
    except NotReadable:
        raise
    except Exception as exc:  # a damaged file never stops the run
        raise NotReadable(f"could not be read ({type(exc).__name__}): the file may be damaged")
    doc.text = tidy(doc.text)
    if not doc.text.split():
        raise NotReadable("no text inside")
    doc.title = one_line(doc.title)[:150]
    doc.words = len(doc.text.split())
    return doc


# ---------- private words ----------

class Private:
    """The private words of the owner: found in a text, or replaced by [private]."""

    def __init__(self, words):
        kept, known = [], set()
        for word in words:
            word = " ".join(str(word).split())
            if len(word) >= 2 and word.lower() not in known:
                known.add(word.lower())
                kept.append(word)
        kept.sort(key=len, reverse=True)  # the longest first: "Acme Bank" before "Acme"
        parts = []
        for word in kept:
            pattern = re.escape(word).replace(r"\ ", r"[\s_.-]*")
            parts.append(pattern if len(word) > 3 else r"(?<![A-Za-z0-9])" + pattern + r"(?![A-Za-z0-9])")
        self.words = kept
        self.rx = re.compile("|".join(parts), re.I) if parts else None

    def found(self, text: str) -> bool:
        return bool(self.rx and text and self.rx.search(text))

    def mask(self, text: str) -> str:
        return self.rx.sub(MASK, text) if self.rx and text else text


def read_private_words(brain: Path, extra) -> list[str]:
    """The lines "- word" under "## Private words" in brain/1-self/rules.md, plus --private-word."""
    words = list(extra or [])
    try:
        text = (brain / "1-self" / "rules.md").read_text(encoding="utf-8-sig")
    except OSError:
        return words
    inside = False
    for line in text.splitlines():
        if line.startswith("#"):
            inside = bool(re.match(r"^##\s+private words\b", line.strip(), re.I))
            continue
        m = re.match(r"^\s*[-*]\s+(.+?)\s*$", line) if inside else None
        if m:
            word = re.sub(r"\s*\([^)]*\)\s*$", "", m.group(1)).strip().strip("`\"'")  # a date in brackets is left aside
            if word:
                words.append(word)
    return words


# ---------- the knowledge folder, the brain and what was done before ----------

class Entry:
    """One file of the knowledge folder."""

    def __init__(self, path: Path, relative: str):
        self.path, self.rel = path, relative
        parts = relative.split("/")
        self.folder = "/".join(parts[:-1][:2]) or TOP
        self.depth = len(parts)
        self.pid = pid(relative)


def walk(knowledge: Path) -> list[Entry]:
    """Every file to look at. Left aside without a word: names that start with "." or "_", .pyc,
    empty files, README.md at the top, CLAUDE.md, AGENTS.md, and a x.pdf.txt written by convert."""
    out = []
    if not knowledge.is_dir():
        return out
    for root, dirs, files in os.walk(knowledge):
        dirs[:] = sorted(d for d in dirs if not d.startswith((".", "_")))
        for name in sorted(files):
            low = name.lower()
            if name.startswith((".", "_")) or low.endswith(".pyc") or low in ("claude.md", "agents.md"):
                continue
            path = Path(root) / name
            relative = path.relative_to(knowledge).as_posix()
            if relative.lower() == "readme.md":
                continue
            if low.endswith(".txt") and Path(name[:-4]).suffix and (Path(root) / name[:-4]).is_file():
                continue
            try:
                if path.stat().st_size == 0:
                    continue
            except OSError:
                continue
            out.append(Entry(path, relative))
    return out


class Ctx:
    """Where things are for this run: the brain, the knowledge folder, the private words."""

    def __init__(self, args):
        self.brain = resolve(args.brain)
        self.knowledge = resolve(args.knowledge)
        try:
            self.label = self.knowledge.resolve().relative_to(PROJECT).as_posix()
        except (ValueError, OSError):
            self.label = self.knowledge.name
        self.ears = self.brain / "2-ears"
        self.sources = self.ears / "sources"
        self.page = self.ears / "library.md"
        self.state = self.ears / "library" / "state.json"
        self.seen = self.ears / "library" / "seen.json"
        self.private = Private(read_private_words(self.brain, getattr(args, "private_word", None)))
        self.today = now_local().strftime("%Y-%m-%d")
        self.cache: dict = {}

    def show(self, relative: str) -> str:
        """A path of the knowledge folder as it is written in the brain: private words masked."""
        return f"{self.label}/{self.private.mask(relative)}"

    def need_brain(self) -> None:
        if not (self.brain / "BRAIN.md").exists():
            sys.exit(f"No brain in {rel(self.brain)}: BRAIN.md is missing. Start with /build-self, then /build-ears.")

    def need_files(self, verb: str) -> list[Entry]:
        entries = walk(self.knowledge)
        if not entries:
            sys.exit(nothing_there(self, verb))
        return entries


def nothing_there(ctx: Ctx, verb: str) -> str:
    where = f"{ctx.label}/"
    what = "what you know (courses, a book, slides, notebooks, notes), in any folders"
    if not ctx.knowledge.is_dir():
        return f"Nothing to {verb}: there is no folder {where} yet. Create it next to brain/ and put there {what}."
    return f"Nothing to {verb}: {where} is empty. Put there {what}, then run this again."


def inspect(ctx: Ctx, entry: Entry) -> dict:
    """One file, read once per run: readable or not, why, its fingerprint, its text, private words or not."""
    if entry.rel in ctx.cache:
        return ctx.cache[entry.rel]
    info = {"readable": False, "why": why_not(entry.path.suffix.lower()), "sha": "", "doc": None, "hit": False}
    if not info["why"]:
        try:
            data = entry.path.read_bytes()
        except OSError as exc:
            info["why"] = f"could not be opened ({exc.strerror or type(exc).__name__})"
        else:
            info["sha"] = hashlib.sha256(data).hexdigest()
            try:
                doc = convert(entry.path.name, data)
            except NotReadable as exc:
                info["why"] = str(exc)
            else:
                doc.title = doc.title or clean_name(entry.path.stem)
                info.update(readable=True, doc=doc, hit=ctx.private.found(entry.rel) or ctx.private.found(doc.text))
    ctx.cache[entry.rel] = info
    return info


def load_seen(ctx: Ctx) -> dict:
    """What the library did before: the documents filed (by the fingerprint of the original), the
    folders decided and the files left out. A filed document whose source file is gone is forgotten."""
    data = read_json(ctx.seen, {})
    data = data if isinstance(data, dict) else {}
    left = data.get("left_out") if isinstance(data.get("left_out"), dict) else {}
    seen = {"items": data.get("items") if isinstance(data.get("items"), dict) else {},
            "folders": left.get("folders") if isinstance(left.get("folders"), dict) else {},
            "files": left.get("files") if isinstance(left.get("files"), dict) else {}}
    for sha, item in list(seen["items"].items()):
        if not isinstance(item, dict) or not (ctx.sources / f"{item.get('slug')}.md").is_file():
            del seen["items"][sha]
    return seen


def save_seen(ctx: Ctx, seen: dict) -> None:
    write_json(ctx.seen, {"written_by": WRITTEN_BY, "items": seen["items"],
                          "left_out": {"folders": seen["folders"], "files": seen["files"]}})


def folder_left_out(seen: dict, folder: str) -> bool:
    return (seen["folders"].get(pid(folder)) or {}).get("decided") == "left out"


def row_order(folder: str) -> tuple:
    return (folder != TOP, folder.lower())


def match_folders(ctx: Ctx, wanted: list[str], present: list[str]) -> list[str]:
    """The rows named by the owner: a row itself, or a parent of rows ("Training" means all its rows)."""
    chosen: list[str] = []
    for raw in wanted:
        text = raw.strip().strip("\"'").replace("\\", "/").strip("/")
        if text.lower().startswith(ctx.label.lower() + "/"):
            text = text[len(ctx.label) + 1:]
        if text.lower() in ("top", TOP, "."):
            text = TOP
        low = text.lower()
        hits = [row for row in present
                if any(name == low or name.startswith(low + "/") for name in (row.lower(), ctx.private.mask(row).lower()))]
        if not hits:
            names = ", ".join(ctx.private.mask(row) for row in present)
            sys.exit(f'No folder "{ctx.private.mask(raw)}" in {ctx.label}/. The folders of the table: {names}.')
        chosen += [row for row in hits if row not in chosen]
    return sorted(chosen, key=row_order)


# ---------- the count: the page and its data ----------

def survey(ctx: Ctx, seen: dict, entries: list[Entry]) -> tuple[dict, list]:
    """Every file in one place: not readable, filed, left out, duplicate or waiting."""
    by_path = {item.get("path_id") for item in seen["items"].values()}
    rows: dict = {}
    not_readable = []
    owner: dict = {}  # fingerprint -> the waiting file that owns this content in this count
    for entry in sorted(entries, key=lambda e: (e.depth, e.rel)):  # the file nearest to the top owns a content
        info = inspect(ctx, entry)
        row = rows.setdefault(entry.folder, dict.fromkeys(
            ("files", "readable", "not_readable", "duplicates", "private", "words", "filed", "waiting",
             "left_out", "changed"), 0))
        row.setdefault("last", "")
        row["files"] += 1
        if not info["readable"]:
            row["not_readable"] += 1
            not_readable.append({"path": ctx.show(entry.rel), "why": info["why"]})
            continue
        row["readable"] += 1
        item = seen["items"].get(info["sha"])
        if item and item.get("path_id") == entry.pid:
            place = "filed"
            row["last"] = max(row["last"], str(item.get("updated") or item.get("filed") or ""))
        elif entry.pid in seen["files"] or folder_left_out(seen, entry.folder):
            place = "left_out"
        elif item or info["sha"] in owner:
            place = "duplicates"
        else:
            place = "waiting"
            owner[info["sha"]] = entry.rel
            row["changed"] += entry.pid in by_path
            row["private"] += bool(info["hit"])
        row[place] += 1
        if place != "duplicates":
            row["words"] += info["doc"].words
    not_readable.sort(key=lambda x: x["path"].lower())
    return rows, not_readable


def row_status(row: dict, left_out: bool) -> str:
    if left_out:
        return "left out by you"
    if row["waiting"]:
        return "partly filed" if row["filed"] else "not filed"
    if row["filed"]:
        return f"filed {row['last']}".strip()
    return "left out by you" if row["left_out"] else "nothing to file"


def documents_of(seen: dict) -> list[dict]:
    docs = [{"slug": item.get("slug"), "from": item.get("from"), "folder": item.get("folder"),
             "title": item.get("title"), "words": item.get("words", 0), "filed": item.get("filed"),
             "origin": item.get("origin", "mine")} for item in seen["items"].values()]
    return sorted(docs, key=lambda d: (str(d["filed"]), str(d["slug"])), reverse=True)


def make_state(ctx: Ctx, seen: dict, entries: list[Entry], last_run) -> dict:
    rows, not_readable = survey(ctx, seen, entries)
    folders = []
    for name in sorted(rows, key=row_order):
        row = rows[name]
        record = seen["folders"].get(pid(name)) or {}
        decided = record.get("decided")
        if decided == "file" and record.get("private"):
            decided = f"file, private words: {record['private']}"
        folders.append({"folder": ctx.private.mask(name), "files": row["files"], "readable": row["readable"],
                        "not_readable": row["not_readable"], "duplicates": row["duplicates"],
                        "private": row["private"], "words": row["words"], "filed": row["filed"],
                        "status": row_status(row, decided == "left out"), "decided": decided,
                        "waiting": row["waiting"], "left_out": row["left_out"], "changed": row["changed"]})
    totals = {key: sum(f[key] for f in folders) for key in
              ("files", "readable", "not_readable", "duplicates", "private", "filed", "left_out", "waiting", "words")}
    totals = {"folders": len(folders), **totals}
    return {"written_by": WRITTEN_BY, "updated": stamp(), "knowledge_dir": ctx.label,
            "pdf_reader": pdf_reader()[0], "last_run": last_run, "totals": totals, "folders": folders,
            "not_readable": not_readable, "documents": documents_of(seen)}


def empty_state(ctx: Ctx) -> dict:
    totals = dict.fromkeys(("folders", "files", "readable", "not_readable", "duplicates", "private", "filed",
                            "left_out", "waiting", "words"), 0)
    return {"written_by": WRITTEN_BY, "updated": stamp(), "knowledge_dir": ctx.label, "pdf_reader": pdf_reader()[0],
            "last_run": None, "totals": totals, "folders": [], "not_readable": [], "documents": []}


def render_page(state: dict) -> str:
    last = state.get("last_run") or {}
    totals = state["totals"]
    lines = ["# Library: your own knowledge", "",
             f"Written only by `{WRITTEN_BY}`. Do not edit by hand.", ""]
    if last.get("line"):
        lines += [str(last["line"]) + ("" if last.get("status") == "done" else " (failed)"), ""]
    if state["folders"]:
        lines += ["| Folder | Files | Readable | Duplicates | Private words | Words | Status |",
                  "|---|---|---|---|---|---|---|"]
        for f in state["folders"]:
            lines.append(f"| {f['folder']} | {f['files']} | {f['readable']} | {f['duplicates']} | {f['private']} "
                         f"| {f['words']} | {f['status']} |")
        lines += [f"| **Total** | {totals['files']} | {totals['readable']} | {totals['duplicates']} "
                  f"| {totals['private']} | {totals['words']} | {totals['filed']} filed, {totals['waiting']} waiting, "
                  f"{totals['left_out']} left out |", ""]
    else:
        lines += [f"Nothing was read from `{state.get('knowledge_dir', 'my-knowledge')}/` yet.", ""]
    outside = sum(1 for d in state["documents"] if d.get("origin") == "external")
    if outside:
        lines += [f"Brought from outside on your word, and filed: {outside} document(s).", ""]
    if state["not_readable"]:
        lines += [f"## Not readable ({len(state['not_readable'])})", ""]
        lines += [f"- `{item['path']}`: {item['why']}" for item in state["not_readable"]]
        lines.append("")
    lines += ["Filed is not known yet: Condense turns a filed document into a knowledge card.", ""]
    return "\n".join(lines)


def write_state(ctx: Ctx, state: dict) -> list[str]:
    write_json(ctx.state, state)
    write_text(ctx.page, render_page(state))
    return [rel(ctx.page), rel(ctx.state)]


def print_table(state: dict, limit: int = 30) -> None:
    rows = state["folders"]
    totals = state["totals"]
    width = max([len("Folder")] + [len(f["folder"]) for f in rows])
    form = f"{{:<{width}}}  {{:>5}}  {{:>8}}  {{:>10}}  {{:>7}}  {{:>8}}  {{}}"
    print(form.format("Folder", "Files", "Readable", "Duplicates", "Private", "Words", "Status"))
    for f in rows:
        print(form.format(f["folder"], f["files"], f["readable"], f["duplicates"], f["private"], f["words"], f["status"]))
    print(form.format("Total", totals["files"], totals["readable"], totals["duplicates"], totals["private"],
                      totals["words"], f"{totals['filed']} filed, {totals['waiting']} waiting, "
                                       f"{totals['left_out']} left out"))
    bad = state["not_readable"]
    if bad:
        print(f"\nNot readable ({len(bad)}):")
        for item in bad[:limit]:
            print(f"  {item['path']}: {item['why']}")
        if len(bad) > limit:
            print(f"  ... and {len(bad) - limit} more, in the page.")


# ---------- the commands ----------

def last_run_of(what: str, started: str, line: str, status: str = "done") -> dict:
    return {"what": what, "started": started, "ended": stamp(), "status": status, "line": line}


def run_logged(ctx: Ctx, what: str, start_summary: str, job) -> int:
    """A run, between its start line and its stop line in the run log."""
    started = stamp()
    log_run("start", "running", start_summary)
    try:
        code, run_line, outputs = job(started)
    except BaseException as exc:  # no brain file to write, a crash, Ctrl+C: the stop line says so
        if isinstance(exc, SystemExit) and not isinstance(exc.code, (int, type(None))):
            reason = " ".join(str(exc.code).split())
        else:
            reason = reason_of(exc)
        line = f"Library stopped: {reason[:240]}"
        log_run("stop", "failed", line)
        try:  # the screen reads state.json: it must not keep saying that the last run went well
            state = read_json(ctx.state)
            if isinstance(state, dict) and isinstance(state.get("totals"), dict):
                state["last_run"] = last_run_of(what, started, line, "failed")
                state["updated"] = stamp()
                write_state(ctx, state)
        except Exception:
            pass
        raise
    log_run("stop", "failed" if code else "done", run_line, outputs)
    return code


def do_scan(ctx: Ctx, entries: list[Entry], started: str) -> tuple[int, str, list[str]]:
    clock = time.monotonic()
    print(f"Reading {len(entries)} file(s) of {ctx.label}/ ...")
    seen = load_seen(ctx)
    state = make_state(ctx, seen, entries, None)
    totals = state["totals"]
    line = (f"Scan of {started[11:16]}: {totals['files']} file(s) in {totals['folders']} folder(s), "
            f"{totals['readable']} readable, {totals['duplicates']} duplicate(s), {totals['private']} with private words")
    state["last_run"] = last_run_of("scan", started, line)
    outputs = write_state(ctx, state)
    print(f"{line}\n")
    print_table(state)
    changed = sum(f["changed"] for f in state["folders"])
    if changed:
        print(f"\n{changed} document(s) changed since they were filed: file their folder again to update them.")
    if any(Path(e.rel).suffix.lower() == ".pdf" for e in entries) and not state["pdf_reader"]:
        print("\nNo PDF reader on this computer: install Git for Windows (it brings pdftotext), then scan again.")
    if totals["private"]:
        print(f"\n{totals['private']} waiting document(s) hold private words. At filing time you choose: "
              "--private keep, mask or skip.")
    print(f"\nNothing was filed ({time.monotonic() - clock:.0f} s). {totals['waiting']} document(s) wait."
          f"\nTo file a folder:  python ops/tools/library.py file \"FOLDER\"    (every folder: --all)"
          f"\nPage: {outputs[0]}")
    return 0, line, outputs


def except_words(groups) -> list[list[str]]:
    out = []
    for group in groups or []:
        for text in group:
            tokens = [t for t in re.split(r"[^a-z0-9]+", text.lower()) if t]
            if tokens:
                out.append(tokens)
    return out


def excepted(relative: str, words: list[list[str]]) -> str:
    """The --except text that names a part of this path, or "". A part is split on what is not a
    letter or a digit: "old" names old_memory_x and Old, not threshold."""
    for part in relative.split("/"):
        tokens = [t for t in re.split(r"[^a-z0-9]+", part.lower()) if t]
        for word in words:
            size = len(word)
            if any(tokens[i:i + size] == word for i in range(len(tokens) - size + 1)):
                return " ".join(word)
    return ""


def free_slug(ctx: Ctx, base: str, taken: set) -> str:
    """A slug that no file of sources/ has: base, then base-2, base-3..."""
    slug, n = base, 1
    while slug in taken or (ctx.sources / f"{slug}.md").exists():
        n += 1
        end = f"-{n}"
        slug = base[:SLUG_MAX - len(end)].rstrip("-") + end
    taken.add(slug)
    return slug


def source_text(title: str, url: str, fetched: str, how: str, origin: str, body: str, updated: str | None) -> str:
    head = [f"# {title}", f"- url: {url}", f"- fetched: {fetched}", f"- how: {how}", f"- origin: {origin}"]
    if updated:
        head.append(f"- updated: {updated}")
    return "\n".join(head) + "\n\n" + body.strip("\n") + "\n"


def do_file(ctx: Ctx, args, entries: list[Entry], started: str) -> tuple[int, str, list[str]]:
    seen = load_seen(ctx)
    present = sorted({e.folder for e in entries}, key=row_order)
    kept_out: list[str] = []
    if args.all:
        selected = [row for row in present if not folder_left_out(seen, row)]
        kept_out = [row for row in present if folder_left_out(seen, row)]
    else:
        selected = match_folders(ctx, args.folders, present)
        for row in selected:  # naming a folder takes it back, with every file of it that was left out
            row_id = pid(row)
            if folder_left_out(seen, row):
                del seen["folders"][row_id]
            for key in [k for k, v in seen["files"].items() if v.get("folder_id") == row_id]:
                del seen["files"][key]
    words = except_words(args.excepted)
    mode = args.private
    by_path = {item.get("path_id"): sha for sha, item in seen["items"].items()}
    batch: set = set()   # the contents filed in this run
    taken: set = set()
    total = dict.fromkeys(("new", "updated", "dup", "bad", "left"), 0)
    report, blocked, folders_filed = [], [], 0
    try:
        for row in selected:
            shown = ctx.private.mask(row)
            count = dict.fromkeys(total, 0)
            candidates = []
            for entry in sorted((e for e in entries if e.folder == row), key=lambda e: (e.depth, e.rel)):
                word = excepted(entry.rel, words)
                if word and entry.pid not in by_path:
                    if entry.pid not in seen["files"] and not why_not(entry.path.suffix.lower()):
                        seen["files"][entry.pid] = {"from": ctx.show(entry.rel), "folder": shown, "folder_id": pid(row),
                                                    "why": f"left out by you (--except {word})", "date": ctx.today}
                        count["left"] += 1
                    continue
                if entry.pid in seen["files"]:
                    continue  # left out before, and this run does not take it back
                info = inspect(ctx, entry)
                if not info["readable"]:
                    count["bad"] += 1
                    continue
                item = seen["items"].get(info["sha"])
                if item and item.get("path_id") == entry.pid:
                    continue  # filed, and not changed since
                if item or info["sha"] in batch:
                    count["dup"] += 1
                    continue
                batch.add(info["sha"])
                candidates.append((entry, info))
            hits = sum(1 for _, info in candidates if info["hit"])
            if hits and not mode:
                batch -= {info["sha"] for _, info in candidates}
                blocked.append(shown)
                report.append(f"  {shown}: WAITS for your choice, {hits} document(s) hold private words. "
                              "Nothing was filed from this folder.")
                continue
            for entry, info in candidates:
                doc = info["doc"]
                if info["hit"] and mode == "skip":
                    seen["files"][entry.pid] = {"from": ctx.show(entry.rel), "folder": shown, "folder_id": pid(row),
                                                "why": "left out: private words (--private skip)", "date": ctx.today}
                    batch.discard(info["sha"])
                    count["left"] += 1
                    continue
                fix = ctx.private.mask if info["hit"] and mode == "mask" else (lambda text: text)
                title, text, shown_path = fix(doc.title), fix(doc.text), fix(entry.rel)
                old_sha = by_path.get(entry.pid)
                old = seen["items"].pop(old_sha, None) if old_sha else None
                if old:  # filed before, changed since: the same source file is written again
                    slug, first, updated = old["slug"], old.get("filed") or ctx.today, ctx.today
                else:
                    name = Path(shown_path)
                    base = f"{name.parent.name} {name.stem}" if name.parent.name else name.stem
                    slug, first, updated = free_slug(ctx, slugify(base), taken), ctx.today, None
                how = f"converted by library.py from {ctx.label}/{shown_path} ({doc.kept})"
                write_text(ctx.sources / f"{slug}.md", source_text(title, "none", first, how, "mine", text, updated))
                record = {"slug": slug, "from": ctx.show(entry.rel), "folder": shown, "filed": first,
                          "path_id": entry.pid, "title": title, "words": len(text.split()), "origin": "mine"}
                if updated:
                    record["updated"] = updated
                if info["hit"]:
                    record["private"] = mode
                seen["items"][info["sha"]] = record
                by_path[entry.pid] = info["sha"]
                count["updated" if old else "new"] += 1
            if count["new"] or count["updated"] or count["left"]:
                before = seen["folders"].get(pid(row)) or {}
                seen["folders"][pid(row)] = {"folder": shown, "decided": "file",
                                             "private": mode if hits else before.get("private"), "date": ctx.today}
            folders_filed += bool(count["new"] or count["updated"])
            for key in total:
                total[key] += count[key]
            bits = [f"{count['new']} filed"] if count["new"] else []
            bits += [f"{count[key]} {label}" for key, label in (("updated", "updated"), ("dup", "duplicate(s) skipped"),
                                                                 ("left", "left out"), ("bad", "not readable"))
                     if count[key]]
            report.append(f"  {shown}: " + (", ".join(bits) if bits else "nothing new"))
    finally:
        save_seen(ctx, seen)   # what is written in sources/ is always recorded, even when the run breaks
    line = (f"Filed at {started[11:16]}: {total['new']} document(s) from {folders_filed} folder(s), "
            f"{total['updated']} updated, {total['dup']} duplicate(s) skipped, {total['bad']} not readable")
    if blocked:
        line += f", {len(blocked)} folder(s) wait for your choice on private words"
    state = make_state(ctx, seen, entries, None)
    state["last_run"] = last_run_of("file", started, line)
    outputs = write_state(ctx, state)
    print(line)
    print("\n".join(report))
    if kept_out:
        print("Left out by you, not touched: " + ", ".join(ctx.private.mask(row) for row in kept_out)
              + '. Name a folder to take it back: file "FOLDER".')
    if blocked:
        print("Private words: say what to do, then file again with one of\n"
              "  --private keep   file these documents as they are\n"
              "  --private mask   each private word becomes [private] in the text, the title and the file name\n"
              "  --private skip   file only the documents that hold none")
    if not (total["new"] or total["updated"]):
        print("Nothing new to file." if not blocked else "Nothing was filed.")
    else:
        print(f"Sources: {rel(ctx.sources)}/   Page: {outputs[0]}\n"
              "Filed is not known yet: Condense turns a filed document into a knowledge card.")
    return 0, line, outputs


def do_leave_out(ctx: Ctx, wanted: list[str]) -> int:
    old = read_json(ctx.state)
    if not isinstance(old, dict):
        sys.exit("Scan first, so that you see what you leave out: python ops/tools/library.py scan")
    entries = ctx.need_files("leave out")
    seen = load_seen(ctx)
    selected = match_folders(ctx, wanted, sorted({e.folder for e in entries}, key=row_order))
    for row in selected:
        seen["folders"][pid(row)] = {"folder": ctx.private.mask(row), "decided": "left out", "private": None,
                                     "date": ctx.today}
    save_seen(ctx, seen)
    state = make_state(ctx, seen, entries, old.get("last_run"))
    write_state(ctx, state)
    names = ", ".join(ctx.private.mask(row) for row in selected)
    filed = sum(f["filed"] for f in state["folders"] if f["folder"] in {ctx.private.mask(r) for r in selected})
    print(f"Left out by you: {names}. The scan stops proposing " + ("it." if len(selected) == 1 else "them."))
    if filed:
        print(f"{filed} document(s) filed from there before stay in {rel(ctx.sources)}/.")
    print('To take a folder back:  python ops/tools/library.py file "FOLDER"')
    return 0


def download(url: str) -> tuple[bytes, str]:
    request = urllib.request.Request(url, headers={"User-Agent": USER_AGENT,
                                                   "Accept": "application/pdf,text/html;q=0.9,*/*;q=0.5"})
    last: Exception | None = None
    for attempt in range(2):
        try:
            with urllib.request.urlopen(request, timeout=60) as answer:
                kind = (answer.headers.get("Content-Type") or "").lower()
                data = answer.read(MAX_DOWNLOAD + 1)
            if len(data) > MAX_DOWNLOAD:
                raise ValueError(f"larger than {MAX_DOWNLOAD // 1_000_000} MB")
            if data[:2] == b"\x1f\x8b":
                data = gzip.decompress(data)
            return data, kind
        except urllib.error.HTTPError as exc:
            last = exc
            if exc.code != 429 and exc.code < 500:
                raise
        except (urllib.error.URLError, TimeoutError, ConnectionError) as exc:
            last = exc
        if attempt == 0:
            time.sleep(5)
    raise last  # type: ignore[misc]


def arxiv_title(paper: str) -> str:
    """The title of an arXiv paper, asked to arXiv itself. "" when it does not answer."""
    atom = "{http://www.w3.org/2005/Atom}"
    try:
        data, _ = download("https://export.arxiv.org/api/query?id_list=" + urllib.parse.quote(paper))
        for entry in ET.fromstring(data).iter(atom + "entry"):
            title = one_line(entry.findtext(atom + "title") or "")
            return "" if title.lower() == "error" else title
    except Exception:
        pass
    return ""


def do_fetch(ctx: Ctx, args, started: str) -> tuple[int, str, list[str]]:
    url = args.url.strip()
    paper = re.match(r"^https?://(?:www\.)?arxiv\.org/(?:abs|pdf)/([^?#\s]+?)(?:\.pdf)?/?(?:[?#].*)?$", url, re.I)
    if paper:
        url = f"https://arxiv.org/pdf/{paper.group(1)}"
    print(f"Downloading {url} ...")
    try:
        data, kind = download(url)
    except Exception as exc:
        hint = ""
        if "CERTIFICATE_VERIFY_FAILED" in str(exc):  # Windows learns the certificate of a site when a browser opens it
            hint = " This computer does not know the certificate of that site: open the link once in your browser, then try again."
        sys.exit(f"Could not download {url} ({type(exc).__name__}: {exc}).{hint} Nothing was filed.")
    path = urllib.parse.urlparse(url).path.lower()
    is_pdf = b"%PDF" in data[:1024]
    if not is_pdf and ("pdf" in kind or path.endswith(".pdf") or "arxiv.org/pdf/" in url.lower()):
        sys.exit("The link did not give a PDF: the answer does not start with %PDF (a login page or an error "
                 "page?). Nothing was filed.")
    looks_html = "html" in kind or bool(re.search(rb"<(!doctype|html|head|body)\b", data[:2048], re.I))
    if is_pdf:
        name, what = "document.pdf", "PDF"
    elif looks_html:
        name, what = "page.html", "web page"
    elif kind.startswith("text/"):
        name, what = "text.txt", "text"
    else:
        sys.exit(f"The link gave neither a PDF nor a web page ({kind or 'type not said'}). Nothing was filed.")
    try:
        doc = convert(name, data)
    except NotReadable as exc:
        sys.exit(f"Downloaded, but not readable: {exc}. Nothing was filed.")
    given = one_line(args.title or "")
    title = given or doc.title or (arxiv_title(paper.group(1)) if paper else "")
    guessed = False
    if not title:  # a PDF has no heading: its first real line is often the title, not always
        title = next((one_line(line) for line in doc.text.split("\n")[:40]
                      if len(line.strip()) >= 8 and re.search(r"[A-Za-z]{3}", line)
                      and not re.match(r"(?i)\s*arxiv:", line)), "")
        guessed = bool(title)
    title = (title or clean_name(Path(path).stem or "document"))[:150]
    seen = load_seen(ctx)
    sha = hashlib.sha256(data).hexdigest()
    state = read_json(ctx.state)
    if not isinstance(state, dict) or not isinstance(state.get("totals"), dict):
        state = empty_state(ctx)
    known = seen["items"].get(sha)
    if known:
        slug = known.get("slug")
        line = f"Fetched at {started[11:16]}: nothing new, already filed as {slug}"
        if given and given != known.get("title"):  # the same document, with the title the owner gives now
            source = ctx.sources / f"{slug}.md"
            lines = source.read_text(encoding="utf-8").split("\n")
            if lines and lines[0].startswith("# "):
                lines[0] = f"# {given}"
                write_text(source, "\n".join(lines))
                known["title"] = given
                save_seen(ctx, seen)
                line += ", title changed"
    else:
        slug = free_slug(ctx, slugify(title), set())
        how = f"downloaded and converted by library.py ({what}, may be rough)"
        write_text(ctx.sources / f"{slug}.md", source_text(title, url, ctx.today, how, "external", doc.text, None))
        seen["items"][sha] = {"slug": slug, "from": url, "folder": FETCHED, "filed": ctx.today, "path_id": pid(url),
                              "title": title, "words": doc.words, "origin": "external"}
        save_seen(ctx, seen)
        line = f"Fetched at {started[11:16]}: {title[:120]} ({doc.words} words)"
    state.update(updated=stamp(), pdf_reader=pdf_reader()[0], documents=documents_of(seen),
                 last_run=last_run_of("fetch", started, line))
    outputs = [rel(ctx.sources / f"{slug}.md")] + write_state(ctx, state)
    print(f"{line}\nSource: {outputs[0]} ({doc.kept})")
    if not known:
        if guessed:
            print('The title is the first line of the document. Wrong? Run the same command again with --title "...".')
        print("Filed is not known yet: Condense turns a filed document into a knowledge card.")
    return 0, line, outputs


def do_convert(target: str, out: str | None) -> int:
    """A file, or the files of one folder and of its sub folders, as .txt next to them. Nothing in 2-ears, no run log."""
    path = Path(target)
    if not path.is_absolute():
        path = Path.cwd() / path if (Path.cwd() / path).exists() else PROJECT / path
    if not path.exists():
        print(f"Nothing at {target}: give a file or a folder.")
        return 1
    one = path.is_file()
    files = [path] if one else sorted(p for p in path.rglob("*") if p.is_file()
                                      and not any(part.startswith(".") for part in p.relative_to(path).parts[:-1]))
    out_dir = None
    if out:
        out_dir = Path(out) if Path(out).is_absolute() else Path.cwd() / out
        out_dir.mkdir(parents=True, exist_ok=True)
    done = skipped = bad = 0
    for file in files:
        ext = file.suffix.lower()
        if ext in TEXT_TYPES or ext in CODE_TYPES:
            if one:
                print(f"{file.name} is already text: nothing to convert.")
                return 0
            continue
        if not one and file.name.startswith((".", "_")):
            continue
        dest = (out_dir or file.parent) / (file.name + ".txt")
        shown = file.name if one else file.relative_to(path).as_posix()
        if dest.exists():
            skipped += 1
            print(f"  there  {shown}: {dest.name} exists, left as it is")
            continue
        try:
            doc = convert(file.name, file.read_bytes())
        except NotReadable as exc:
            bad += 1
            print(f"  no     {shown}: {exc}")
            continue
        except OSError as exc:
            bad += 1
            print(f"  no     {shown}: could not be opened ({exc.strerror or type(exc).__name__})")
            continue
        write_text(dest, f"[Converted by library.py from {file.name}: {doc.kept}. The original is not changed.]\n\n"
                         f"{doc.text}\n")
        done += 1
        print(f"  ok     {shown} -> {dest.name} ({doc.words} words, {doc.kept})")
    print(f"Converted {done} file(s), {skipped} already there, {bad} not readable. The originals are not changed.")
    return 1 if one and bad else 0


def do_status(ctx: Ctx) -> int:
    """One or two lines for Alfred: is it running, the last run, the totals."""
    latest = None
    today = datetime.now().date()
    for back in (1, 0):
        path = PROJECT / "ops" / "runs" / f"{(today - timedelta(days=back)).isoformat()}.jsonl"
        try:
            lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
        except OSError:
            continue
        for text in lines:
            try:
                record = json.loads(text)
            except ValueError:
                continue
            if isinstance(record, dict) and record.get("agent") == "library":
                latest = record
    running = ""
    if latest and latest.get("event") == "start":
        try:
            age = (datetime.now() - datetime.fromisoformat(str(latest.get("ts")))).total_seconds() / 60
        except ValueError:
            age = 0
        since = str(latest.get("ts", ""))[11:16]
        running = (f"running since {since}" if age <= STUCK_AFTER
                   else f"not running (a run started at {since} never ended: it was cut)")
    state = read_json(ctx.state)
    if not isinstance(state, dict) or not isinstance(state.get("totals"), dict):
        print(f"Library: {running or 'not running'}. Nothing was scanned yet. Put your files in {ctx.label}/ "
              'and say "scan my knowledge".')
        return 0
    last = state.get("last_run") or {}
    when = str(last.get("ended") or "")[:16].replace("T", " ")
    print(f"Library: {running or 'not running'}. Last run: {last.get('line', 'none')} "
          f"({last.get('status', 'no status')}, {when}).")
    t = state["totals"]
    print(f"Totals: {t['files']} file(s) in {t['folders']} folder(s): {t['filed']} filed, {t['waiting']} waiting, "
          f"{t['left_out']} left out, {t['duplicates']} duplicate(s), {t['not_readable']} not readable. "
          f"{len(state.get('documents') or [])} document(s) in sources/ come from the library.")
    return 0


# ---------- the command line ----------

def build_parser() -> argparse.ArgumentParser:
    def options(parser, brain, knowledge, words, debug) -> None:
        """The same four options before or after the command. After it, one that is not given changes nothing."""
        parser.add_argument("--brain", default=brain, metavar="DIR", help="the brain folder (default: brain, the active one)")
        parser.add_argument("--knowledge", default=knowledge, metavar="DIR",
                            help="the folder of your own knowledge (default: my-knowledge)")
        parser.add_argument("--private-word", action="append", default=words, metavar="W",
                            help="one more private word for this run (for tests)")
        parser.add_argument("--debug", action="store_true", default=debug, help="show where an error comes from")

    shared = argparse.ArgumentParser(add_help=False)
    options(shared, *[argparse.SUPPRESS] * 4)
    ap = argparse.ArgumentParser(
        prog="library.py",
        description="The library: your own knowledge (my-knowledge/) turned into text and filed in "
                    "brain/2-ears/sources/, folder by folder, on your word. No AI inside. Originals are never touched.",
        epilog='Example: python ops/tools/library.py scan, then python ops/tools/library.py file "Training/Module-2"')
    options(ap, "brain", "my-knowledge", None, False)
    sub = ap.add_subparsers(dest="command", metavar="scan | file | leave-out | fetch | convert | status")

    sub.add_parser("scan", parents=[shared],
                   help="read the knowledge folder, count words and private words, write the page. Files nothing")

    file = sub.add_parser("file", parents=[shared],
                          help="convert and file the folders named (or all) in brain/2-ears/sources/",
                          epilog='Put the folders first: file "Training/Module-2" Book --except old --private mask')
    file.add_argument("folders", nargs="*", metavar="FOLDER",
                      help='a folder of the table, or a parent of several ("Training"). Naming a folder decides '
                           "again for it: the folder and its files that were left out are taken back, unless "
                           "this command leaves them out again")
    file.add_argument("--all", action="store_true",
                      help="every folder that you did not leave out. What was left out before stays out")
    file.add_argument("--except", dest="excepted", action="append", nargs="+", metavar="TEXT",
                      help='leave out every file that has TEXT as a word of its path: "old" names old/ and '
                           "old_notes.md, not threshold")
    file.add_argument("--private", choices=("keep", "mask", "skip"),
                      help="what to do with a document that holds private words: keep it as it is, mask the "
                           "words as [private], or skip the document. Not given: such a folder is not filed")

    leave = sub.add_parser("leave-out", parents=[shared],
                           help="record folders as left out by you, so the scan stops proposing them")
    leave.add_argument("folders", nargs="+", metavar="FOLDER", help="a folder of the table, or a parent of several")

    fetch = sub.add_parser("fetch", parents=[shared],
                           help="download one outside document (a PDF or a web page) and file it. The one "
                                "command that uses the network")
    fetch.add_argument("url", metavar="URL", help="the link. An arxiv.org/abs link is read as its PDF")
    fetch.add_argument("--title", default=None, metavar="T", help="the title, when the document does not say it well")

    conv = sub.add_parser("convert", parents=[shared],
                          help="turn one file, or the files of one folder, into .txt next to them. For the "
                               "documents of the Self step. Writes nothing in 2-ears")
    conv.add_argument("path", metavar="PATH", help="a file, or a folder (its files, and those of its sub folders)")
    conv.add_argument("--out", default=None, metavar="DIR", help="where to write the .txt files (default: next to each file)")

    sub.add_parser("status", parents=[shared], help="is it running, the last run, the totals")
    return ap


def main() -> int:
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass
    ap = build_parser()
    args = ap.parse_args()
    if not args.command:
        ap.print_help()
        return 2
    try:
        if args.command == "convert":
            return do_convert(args.path, args.out)
        ctx = Ctx(args)
        if args.command == "status":
            if not (ctx.brain / "BRAIN.md").exists():
                print(f"Library: no brain in {rel(ctx.brain)} yet. Start with /build-self.")
                return 0
            return do_status(ctx)
        ctx.need_brain()
        if args.command == "fetch":
            if not re.match(r"^https?://\S+$", args.url.strip(), re.I):
                sys.exit("fetch needs one full link, starting with http:// or https://.")
            return run_logged(ctx, "fetch", f"Library: fetching {args.url.strip()}", lambda started: do_fetch(ctx, args, started))
        if args.command == "scan":
            entries = walk(ctx.knowledge)
            if not entries:
                print(nothing_there(ctx, "scan"))
                return 0
            return run_logged(ctx, "scan", f"Library: scanning {len(entries)} file(s) of {ctx.label}/",
                              lambda started: do_scan(ctx, entries, started))
        if args.command == "leave-out":
            return do_leave_out(ctx, args.folders)
        if not args.folders and not args.all:
            sys.exit('Say what to file: one or more folders of the table (file "Training/Module-2"), or --all.')
        if args.folders and args.all:
            sys.exit("Give folders or --all, not both.")
        entries = ctx.need_files("file")
        what = "every folder" if args.all else ", ".join(ctx.private.mask(f) for f in args.folders)
        return run_logged(ctx, "file", f"Library: filing {what} from {ctx.label}/",
                          lambda started: do_file(ctx, args, entries, started))
    except KeyboardInterrupt:
        print("Stopped by you. What was filed before the stop is recorded.", file=sys.stderr)
        return 130
    except Exception as exc:
        if getattr(args, "debug", False):
            raise
        print(f"library.py stopped: {reason_of(exc)}. Run it again with --debug to see where.", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
