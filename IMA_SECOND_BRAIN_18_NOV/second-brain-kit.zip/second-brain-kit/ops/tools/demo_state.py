#!/usr/bin/env python3
"""Demo state: save the state of the demo before a rehearsal, and put it back after.

Commands (run from the project root):

  python ops/tools/demo_state.py save NAME       copy the state into demo/snapshots/NAME/
  python ops/tools/demo_state.py restore NAME    put that state back
  python ops/tools/demo_state.py list            the saved states

The state is: brain/, brains/, ops/runs/, ops/queue.json and ops/waiting-for-you.md.
Agents, skills, tools and settings are not part of it.

  save     refuses to replace a snapshot that exists, unless --force is given.
  restore  first saves the current state under demo/snapshots/_before-restore/ (the previous one is
           replaced), then puts the snapshot back. What was absent in the snapshot is absent after the
           restore. Each folder is prepared next to the live one and swapped in at the end, so a failure
           leaves the live state as it was.

Standard library only.
"""
from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import sys
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SNAPSHOTS = ROOT / "demo" / "snapshots"
ITEMS = ["brain", "brains", "ops/runs", "ops/queue.json", "ops/waiting-for-you.md"]
BEFORE_RESTORE = "_before-restore"
VALID_NAME = re.compile(r"[A-Za-z0-9][A-Za-z0-9._-]*")


class Stop(Exception):
    """An expected problem: one clear line for the user, no stack trace."""


def explain(error: OSError) -> str:
    """A system error in a few words, with a path from the project root, never a full one."""
    name = ""
    if error.filename:
        try:
            name = Path(str(error.filename)).resolve().relative_to(ROOT).as_posix()
        except (ValueError, OSError):
            name = Path(str(error.filename)).name
    reason = error.strerror or type(error).__name__
    return f"{reason}: {name}" if name else reason


def live(item: str) -> Path:
    return ROOT.joinpath(*item.split("/"))


def remove(path: Path) -> None:
    if path.is_dir() and not path.is_symlink():
        shutil.rmtree(path)
    elif path.exists() or path.is_symlink():
        path.unlink()


def copy(source: Path, target: Path) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    if source.is_dir():
        shutil.copytree(source, target)
    else:
        shutil.copy2(source, target)


def active_id() -> str:
    path = ROOT / "brain" / "BRAIN.md"
    if path.is_file():
        for line in path.read_text(encoding="utf-8-sig", errors="replace").splitlines():
            match = re.match(r"^\s*[-*]\s*id\s*:\s*(\S+)", line)
            if match:
                return match.group(1)
    return ""


def count_files(folder: Path) -> int:
    return sum(1 for path in folder.rglob("*") if path.is_file())


def write_snapshot(name: str) -> Path:
    """Copy the live state into demo/snapshots/<name>/, replacing it only once the copy is complete."""
    target = SNAPSHOTS / name
    building = SNAPSHOTS / f"{name}.saving"
    remove(building)
    present = [item for item in ITEMS if live(item).exists()]
    if not present:
        raise Stop("Nothing to save: no brain/, no brains/, no run log and no queue in this project.")
    try:
        for item in present:
            copy(live(item), building.joinpath(*item.split("/")))
        manifest = {"name": name, "saved": datetime.now().replace(microsecond=0).isoformat(),
                    "active_brain": active_id(), "present": present,
                    "absent": [item for item in ITEMS if item not in present]}
        with open(building / "snapshot.json", "w", encoding="utf-8", newline="\n") as handle:
            handle.write(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n")
        remove(target)
        os.rename(building, target)
    except OSError as error:
        raise Stop(f"Could not save the state ({explain(error)}). The live state did not change. "
                   f"A partial copy may remain in demo/snapshots/{name}.saving/.")
    return target


def read_manifest(folder: Path) -> dict:
    try:
        manifest = json.loads((folder / "snapshot.json").read_text(encoding="utf-8-sig"))
        if isinstance(manifest, dict):
            return manifest
    except (OSError, ValueError):
        pass
    present = [item for item in ITEMS if folder.joinpath(*item.split("/")).exists()]
    return {"name": folder.name, "saved": "", "active_brain": "", "present": present,
            "absent": [item for item in ITEMS if item not in present]}


def check_name(name: str, reserved_ok: bool = False) -> str:
    name = name.strip()
    if name == BEFORE_RESTORE and reserved_ok:
        return name
    if not VALID_NAME.fullmatch(name) or name.endswith((".saving", ".restoring", ".old")):
        raise Stop(f'"{name}" is not a valid snapshot name. Use letters, digits and dashes, for example stage.')
    return name


def cmd_save(name: str, force: bool) -> None:
    name = check_name(name)
    if (SNAPSHOTS / name).exists() and not force:
        raise Stop(f"The snapshot {name} already exists. Choose another name, or add --force to replace it.")
    target = write_snapshot(name)
    manifest = read_manifest(target)
    print(f"Saved: demo/snapshots/{name}/ ({count_files(target) - 1} files, active brain: "
          f'{manifest["active_brain"] or "none"})')
    if manifest["absent"]:
        print("Absent at this moment, so absent after a restore: " + ", ".join(manifest["absent"]))


def cmd_restore(name: str) -> None:
    name = check_name(name, reserved_ok=True)
    source = SNAPSHOTS / name
    if not source.is_dir():
        known = ", ".join(sorted(path.name for path in SNAPSHOTS.iterdir() if path.is_dir())) if SNAPSHOTS.is_dir() else ""
        raise Stop(f"No snapshot {name} in demo/snapshots/. Saved states: {known or 'none'}.")
    manifest = read_manifest(source)
    if not manifest["present"]:
        raise Stop(f"The snapshot {name} is empty. Nothing was restored.")
    if name != BEFORE_RESTORE and any(live(item).exists() for item in ITEMS):
        write_snapshot(BEFORE_RESTORE)

    # 1. Prepare every copy next to the live item. Nothing live is touched yet.
    staged: list[tuple[Path, Path | None]] = []
    try:
        for item in ITEMS:
            target = live(item)
            saved = source.joinpath(*item.split("/"))
            staging = None
            if saved.exists():
                staging = target.with_name(target.name + ".restoring")
                remove(staging)
                copy(saved, staging)
            staged.append((target, staging))
    except OSError as error:
        for _, staging in staged:
            if staging is not None:
                remove(staging)
        raise Stop(f"Could not prepare the restore ({explain(error)}). The live state did not change.")

    # 2. Swap: live goes aside, the copy takes its place. On a failure, everything is put back.
    swapped: list[tuple[Path, Path | None, bool]] = []
    try:
        for target, staging in staged:
            aside = target.with_name(target.name + ".old")
            remove(aside)
            had_live = target.exists()
            if had_live:
                os.rename(target, aside)
            swapped.append((target, aside if had_live else None, False))
            if staging is not None:
                os.rename(staging, target)
                swapped[-1] = (target, aside if had_live else None, True)
    except OSError as error:
        for target, aside, placed in reversed(swapped):
            try:
                if placed:
                    remove(target)
                if aside is not None and aside.exists():
                    os.rename(aside, target)
            except OSError:
                pass
        for _, staging in staged:
            if staging is not None and staging.exists():
                remove(staging)
        hint = " A file of the live state is open in a program or a terminal: close it and try again." \
            if isinstance(error, PermissionError) else ""
        raise Stop(f"Could not restore ({explain(error)}).{hint} The live state was put back as it was.")

    # 3. Clean what was set aside. Its content is in demo/snapshots/_before-restore/.
    left = []
    for _, aside, _ in swapped:
        if aside is not None:
            try:
                remove(aside)
            except OSError:
                left.append(aside.relative_to(ROOT).as_posix())
    print(f'Restored: {name} (saved {str(manifest["saved"])[:16].replace("T", " ") or "at an unknown time"}, active brain: '
          f'{manifest["active_brain"] or active_id() or "none"})')
    if name != BEFORE_RESTORE:
        print(f"The state from before is in demo/snapshots/{BEFORE_RESTORE}/. Undo with: demo_state.py restore {BEFORE_RESTORE}")
    if left:
        print("Could not remove these leftovers, delete them by hand: " + ", ".join(left))


def cmd_list() -> None:
    folders = sorted(path for path in SNAPSHOTS.iterdir() if path.is_dir()) if SNAPSHOTS.is_dir() else []
    folders = [path for path in folders if not path.name.endswith((".saving", ".restoring", ".old"))]
    if not folders:
        print("No saved state yet in demo/snapshots/. Save one with: demo_state.py save NAME")
        return
    print("Saved states (demo/snapshots/):")
    for folder in folders:
        manifest = read_manifest(folder)
        saved = str(manifest.get("saved") or "unknown time")[:16].replace("T", " ")
        print(f'  {folder.name}  saved {saved}  active brain: {manifest.get("active_brain") or "none"}  '
              f"{max(count_files(folder) - 1, 0)} files")


def main() -> None:
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass
    parser = argparse.ArgumentParser(
        prog="demo_state.py",
        description="Demo state: save and restore brain/, brains/, ops/runs/, ops/queue.json and "
                    "ops/waiting-for-you.md, in demo/snapshots/NAME/.",
        epilog="Example: python ops/tools/demo_state.py save stage, then after a rehearsal: "
               "python ops/tools/demo_state.py restore stage",
    )
    sub = parser.add_subparsers(dest="command", metavar="save NAME | restore NAME | list")
    save = sub.add_parser("save", help="copy the current state into demo/snapshots/NAME/")
    save.add_argument("name", metavar="NAME")
    save.add_argument("--force", action="store_true", help="replace the snapshot when it exists")
    restore = sub.add_parser("restore", help="put a saved state back (the current one is kept in _before-restore)")
    restore.add_argument("name", metavar="NAME")
    sub.add_parser("list", help="show the saved states")
    args = parser.parse_args()
    try:
        if args.command == "save":
            cmd_save(args.name, args.force)
        elif args.command == "restore":
            cmd_restore(args.name)
        elif args.command == "list":
            cmd_list()
        else:
            parser.print_help()
            sys.exit(2)
    except Stop as problem:
        print(f"demo_state: {problem}", file=sys.stderr)
        sys.exit(1)
    except OSError as error:
        print(f"demo_state: {explain(error)}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
