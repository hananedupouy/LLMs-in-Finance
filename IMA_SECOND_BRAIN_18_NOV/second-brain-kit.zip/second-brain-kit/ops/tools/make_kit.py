#!/usr/bin/env python3
"""Make kit: export the starter kit, the folder a participant takes home.

Commands (run from the project root):

  python ops/tools/make_kit.py                 write demo/kit/second-brain-kit.zip
  python ops/tools/make_kit.py --out DIR       write the kit as a folder, in DIR (DIR must be new or empty)
  python ops/tools/make_kit.py --list          show what would go in and what would be left out, write nothing

In the kit:
  CLAUDE.md, README.md, docs/STEP-BY-STEP.md, docs/START-YOUR-OWN.md, docs/build-guide.html
  my-documents/README.md                                      where the reader drops their CV and writing
  my-knowledge/README.md                                      where the reader drops what they know
  Start my brain.bat, Start my brain.command                  the double-click that starts the screen and Alfred
  .claude/agents/, .claude/skills/, .claude/settings.json     the team and the know-how
  ops/tools/, ops/method.json, ops/routines.json              the small scripts
  brains/_template/                                           the empty brain
  brains/<id>/ for each brain whose BRAIN.md says "kind: fictional"   the example brains

The pages of the method are not in this kit: they are handed out on their own.

Never in the kit:
  a brain whose BRAIN.md does not say "kind: fictional" (a real brain stays with its owner),
  demo/ (the saved states hold copies of the brains), ops/runs/, the queue, the stage script and
  the build contract (they are about the demo, not about the kit), local settings and caches.

The kit has no active brain. A participant starts with /build-self, or looks around first with
`python ops/tools/switch_brain.py use <id of an example brain>`.

Standard library only.
"""
from __future__ import annotations

import argparse
import json
import re
import shutil
import sys
import tempfile
import zipfile
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
KIT_NAME = "second-brain-kit"
DEFAULT_ZIP = ROOT / "demo" / "kit" / f"{KIT_NAME}.zip"
MARKER = "kit.json"

FILES = ["CLAUDE.md", "README.md", "docs/STEP-BY-STEP.md", "docs/START-YOUR-OWN.md", "docs/build-guide.html",
         "my-documents/README.md", "my-knowledge/README.md", "Start my brain.bat", "Start my brain.command",
         ".claude/settings.json", "ops/method.json", "ops/routines.json"]
FOLDERS = [".claude/agents", ".claude/skills", "ops/tools", "brains/_template"]
SKIP_NAMES = {"__pycache__", ".DS_Store", "Thumbs.db", "settings.local.json"}
SKIP_SUFFIXES = (".pyc", ".pyo", ".saving", ".restoring", ".old")


class Stop(Exception):
    """An expected problem: one clear line for the user, no stack trace."""


def explain(error: OSError) -> str:
    """A system error in a few words, with a path from the project root, never a full one."""
    name = ""
    if error.filename:
        try:
            name = Path(str(error.filename)).resolve().relative_to(ROOT).as_posix()
        except (ValueError, OSError):
            name = Path(str(error.filename)).name
    reason = error.strerror or type(error).__name__
    return f"{reason}: {name}" if name else reason


def read_card(folder: Path) -> dict:
    """The "- key: value" lines of BRAIN.md."""
    card = {"id": "", "kind": ""}
    path = folder / "BRAIN.md"
    if not path.is_file():
        return card
    for line in path.read_text(encoding="utf-8-sig", errors="replace").splitlines():
        match = re.match(r"^\s*[-*]\s*([A-Za-z_]+)\s*:\s*(.*)$", line)
        if match and not card.get(match.group(1).lower()):
            card[match.group(1).lower()] = match.group(2).strip().strip('"')
    return card


def skipped(path: Path) -> bool:
    return path.name in SKIP_NAMES or path.name.endswith(SKIP_SUFFIXES)


def ignore(_folder: str, names: list[str]) -> list[str]:
    return [name for name in names if name in SKIP_NAMES or name.endswith(SKIP_SUFFIXES)]


def find_brains() -> tuple[list[tuple[Path, str]], list[str]]:
    """The brains to export (folder, id) and one line for each brain that is left out."""
    taken: list[tuple[Path, str]] = []
    left: list[str] = []
    candidates = [ROOT / "brain"] if (ROOT / "brain").is_dir() else []
    shelf = ROOT / "brains"
    if shelf.is_dir():
        candidates += sorted(path for path in shelf.iterdir() if path.is_dir() and not path.name.startswith("_"))
    for folder in candidates:
        card = read_card(folder)
        where = folder.relative_to(ROOT).as_posix() + "/"
        brain_id = card["id"] if re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]*", card["id"]) else ""
        if card["kind"].lower() == "fictional" and brain_id:
            taken.append((folder, brain_id))
        elif card["kind"].lower() == "fictional":
            left.append(f'{where} (fictional, but its BRAIN.md has no "- id:" line)')
        else:
            kind = card["kind"] or "no kind line"
            left.append(f"{where} ({brain_id or 'no id'}, kind: {kind}): it stays with its owner")
    return taken, left


def plan() -> tuple[list[str], list[tuple[Path, str]], list[str], list[str]]:
    """What goes in (files and folders), the brains, what is missing, what is left out."""
    going = [item for item in FILES + FOLDERS if ROOT.joinpath(*item.split("/")).exists()]
    missing = [item for item in FILES + FOLDERS if item not in going]
    brains, left = find_brains()
    for item in ("demo/", "ops/runs/", "ops/queue.json", "ops/waiting-for-you.md", "docs/DEMO-SCRIPT.md",
                 "docs/BUILD-CONTRACT.md"):
        if ROOT.joinpath(*item.strip("/").split("/")).exists():
            left.append(item)
    return going, brains, missing, left


def build(target: Path) -> dict:
    """Copy the kit into the empty folder `target`. Returns the manifest."""
    going, brains, missing, left = plan()
    if "CLAUDE.md" in missing or ".claude/agents" in missing or ".claude/skills" in missing:
        raise Stop("This folder has no CLAUDE.md, no .claude/agents/ or no .claude/skills/: there is no kit to make.")
    target.mkdir(parents=True, exist_ok=True)
    for item in going:
        source = ROOT.joinpath(*item.split("/"))
        copy_to = target.joinpath(*item.split("/"))
        copy_to.parent.mkdir(parents=True, exist_ok=True)
        if source.is_dir():
            shutil.copytree(source, copy_to, ignore=ignore)
        elif not skipped(source):
            shutil.copy2(source, copy_to)
    for folder, brain_id in brains:
        shutil.copytree(folder, target / "brains" / brain_id, ignore=ignore)

    # The safety check: no brain in the kit may be anything else than a template or a fictional brain.
    for card_path in target.rglob("BRAIN.md"):
        inside = card_path.parent.relative_to(target).as_posix()
        if inside == "brains/_template" or inside.startswith(".claude/"):
            continue
        if read_card(card_path.parent)["kind"].lower() != "fictional":
            raise Stop(f"Safety check failed: {inside}/ is not a fictional brain. The kit was not written.")
    if (target / "brain").exists() or (target / "demo").exists() or (target / "framework").exists():
        raise Stop("Safety check failed: the kit holds brain/, demo/ or framework/. The kit was not written.")

    files = sum(1 for path in target.rglob("*") if path.is_file()) + 1        # + the kit.json written below
    manifest = {"kit": KIT_NAME, "made": datetime.now().replace(microsecond=0).isoformat(), "files": files,
                "example_brains": [brain_id for _, brain_id in brains], "active_brain": None}
    with open(target / MARKER, "w", encoding="utf-8", newline="\n") as handle:        # what the kit says of itself
        handle.write(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n")
    # What was left out is told to the person who makes the kit, not written in the kit.
    return dict(manifest, left_out=left, missing=missing)


def report(manifest: dict, where: str) -> None:
    print(f'Kit written: {where} ({manifest["files"]} files)')
    names = ", ".join(manifest["example_brains"]) or "none"
    print(f"Example brains in the kit: {names}. Empty brain: brains/_template/. No active brain.")
    for line in manifest["left_out"]:
        print(f"Left out: {line}")
    for item in manifest["missing"]:
        print(f"Not found here, so not in the kit: {item}")


def cmd_list() -> None:
    going, brains, missing, left = plan()
    print("Would go in the kit:")
    for item in going:
        print(f"  {item}{'/' if ROOT.joinpath(*item.split('/')).is_dir() else ''}")
    for folder, brain_id in brains:
        print(f"  brains/{brain_id}/  (from {folder.relative_to(ROOT).as_posix()}/, kind: fictional)")
    print("Would be left out:")
    for line in left:
        print(f"  {line}")
    for item in missing:
        print(f"Not found here: {item}")
    print("Nothing was written.")


def cmd_folder(out: str) -> None:
    target = Path(out).expanduser()
    if not target.is_absolute():
        target = Path.cwd() / target
    target = target.resolve()
    if target == ROOT or ROOT in target.parents:
        raise Stop("Choose a folder outside this project: a kit inside it would show its agents and skills twice. "
                   "Without --out, the kit is written as one zip file in demo/kit/.")
    if target.exists() and (not target.is_dir() or any(target.iterdir())):
        raise Stop(f"{target} exists and is not empty. Choose a new folder. Nothing was written.")
    try:
        manifest = build(target)
    except Stop:
        shutil.rmtree(target, ignore_errors=True)
        raise
    report(manifest, str(target))


RUNNABLE = (".command", ".sh")        # a Mac refuses to run a double-clicked file that lost this mark


def write_zip(folder: Path, target: Path) -> None:
    """Zip `folder` (named KIT_NAME inside the zip). Each entry says it comes from a Unix system and
    carries its rights, so that the Mac launcher can still be run after the zip is opened on a Mac."""
    with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(folder.rglob("*")):
            name = (Path(KIT_NAME) / path.relative_to(folder)).as_posix()
            if path.is_dir():
                info = zipfile.ZipInfo(name + "/")
                info.create_system = 3
                info.external_attr = (0o40755 << 16) | 0x10
                archive.writestr(info, b"")
                continue
            info = zipfile.ZipInfo.from_file(path, name)
            info.create_system = 3
            rights = 0o755 if path.name.endswith(RUNNABLE) else 0o644
            info.external_attr = (0o100000 | rights) << 16
            info.compress_type = zipfile.ZIP_DEFLATED
            with open(path, "rb") as handle:
                archive.writestr(info, handle.read())


def cmd_zip() -> None:
    DEFAULT_ZIP.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="second-brain-kit-") as temp:
        manifest = build(Path(temp) / KIT_NAME)
        made = Path(temp) / f"{KIT_NAME}.zip"
        write_zip(Path(temp) / KIT_NAME, made)
        if DEFAULT_ZIP.exists():
            DEFAULT_ZIP.unlink()
        shutil.move(str(made), DEFAULT_ZIP)
    report(manifest, DEFAULT_ZIP.relative_to(ROOT).as_posix())
    print("Unzip it anywhere outside this project, double-click \"Start my brain\" in it, or read README.md.")


def main() -> None:
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass
    parser = argparse.ArgumentParser(
        prog="make_kit.py",
        description="Make kit: export the team, the skills, the tools, the empty brain and the fictional example "
                    "brains. A real brain is never exported.",
        epilog="Example: python ops/tools/make_kit.py   (writes demo/kit/second-brain-kit.zip)",
    )
    parser.add_argument("--out", metavar="DIR", help="write the kit as a folder in DIR, outside this project")
    parser.add_argument("--list", action="store_true", help="show what would go in and what would be left out")
    args = parser.parse_args()
    try:
        if args.list:
            cmd_list()
        elif args.out:
            cmd_folder(args.out)
        else:
            cmd_zip()
    except Stop as problem:
        print(f"make_kit: {problem}", file=sys.stderr)
        sys.exit(1)
    except OSError as error:
        print(f"make_kit: {explain(error)}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
