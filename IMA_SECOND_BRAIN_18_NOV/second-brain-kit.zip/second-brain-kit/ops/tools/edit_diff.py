#!/usr/bin/env python3
"""Edit diff: what the owner changed between the draft and what really went out.

Command (run from the project root):

  python ops/tools/edit_diff.py --all | --slug S [--brain DIR]        (default brain: brain)

Reads   <brain>/6-debrief/metrics/posts.json     each piece names its "draft" and its "posted" file
        the draft        when not named: <brain>/5-narrate/drafts/<slug>/piece.md
        the posted text  when not named: <brain>/5-narrate/posted/<date>-<slug>.md
Writes  <brain>/6-debrief/metrics/edits/<slug>.md    one report per piece
        <brain>/6-debrief/metrics/edits.json         the counts of all pieces, for the screen

--all compares every piece that has both files and rewrites edits.json.
--slug S compares one piece and updates its entry in edits.json. The slug does not have to be in posts.json.

Which text is compared, in the draft and in the posted file alike:
  1. when the file has a line "## Text", the text is everything after that line;
  2. else the whole file, without a starting header: front matter between "---" lines, and a block of
     "- key: value" lines (together with the "# title" just above that block, when there is one).
Blank lines are ignored. A line is compared without the spaces around it.

What is counted:
  added    lines of the posted text that were not in the draft
  removed  lines of the draft that are not in the posted text
  changed  lines that were rewritten: shown side by side in the report
  hook     did the first line change?
  length   characters and words, before and after
  kept     the share of the words of the draft that are still in the posted text, in their order

Standard library only.
"""
from __future__ import annotations

import argparse
import difflib
import json
import re
import sys
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
TEXT_HEADING = re.compile(r"^##\s+(the\s+)?(final\s+|posted\s+)?text\s*:?$", re.IGNORECASE)
HEADER_LINE = re.compile(r"^\s*[-*]\s+[A-Za-z][\w \-]{0,30}:(\s|$)")
SAME_LINE = 0.5       # two lines this similar are one line that was rewritten
WINDOW = 8            # "in N of the last 8 pieces"


class Stop(Exception):
    """An expected problem: one clear line for the user, no stack trace."""


# ---------------------------------------------------------------- finding the files

def show(path: Path) -> str:
    try:
        return path.resolve().relative_to(ROOT).as_posix()
    except ValueError:
        return path.as_posix()


def explain(error: OSError) -> str:
    """A system error in a few words, with a path from the project root, never a full one."""
    name = ""
    if error.filename:
        try:
            name = Path(str(error.filename)).resolve().relative_to(ROOT).as_posix()
        except (ValueError, OSError):
            name = Path(str(error.filename)).name
    reason = error.strerror or type(error).__name__
    return f"{reason}: {name}" if name else reason


def resolve_brain(text: str) -> Path:
    path = Path(text)
    for candidate in ([path] if path.is_absolute() else [ROOT / path, Path.cwd() / path]):
        if candidate.is_dir():
            return candidate.resolve()
    raise Stop(f"No brain folder at {text}. Give an existing one with --brain DIR, for example --brain brains/<id>.")


def locate(brain: Path, text) -> Path | None:
    """Find a file named in posts.json, even when the brain moved between brain/ and brains/<id>/."""
    text = str(text or "").strip().replace("\\", "/")
    if not text:
        return None
    path = Path(text)
    if path.is_absolute():
        return path if path.is_file() else None
    candidates = []
    for position, part in enumerate(path.parts):
        if re.match(r"^[1-6]-[a-z]", part):
            candidates.append(brain.joinpath(*path.parts[position:]))
            break
    candidates += [brain / path, ROOT / path, Path.cwd() / path]
    return next((candidate for candidate in candidates if candidate.is_file()), None)


def find_files(brain: Path, post: dict) -> tuple[Path | None, Path | None]:
    slug, day = str(post.get("slug") or ""), str(post.get("date") or "")[:10]
    narrate = brain / "5-narrate"
    draft = locate(brain, post.get("draft")) or locate(brain, f"5-narrate/drafts/{slug}/piece.md")
    posted = locate(brain, post.get("posted")) or locate(brain, f"5-narrate/posted/{day}-{slug}.md")
    if posted is None and (narrate / "posted").is_dir():
        found = sorted(path for path in (narrate / "posted").glob(f"*{slug}.md")
                       if path.stem == slug or path.stem.endswith(f"-{slug}") or path.stem.endswith(f"_{slug}"))
        posted = found[-1] if found else None
    return draft, posted


def load_posts(brain: Path, needed: bool) -> list[dict]:
    path = brain / "6-debrief" / "metrics" / "posts.json"
    if not path.is_file():
        if needed:
            raise Stop(f"No results yet: {show(path)} is missing. Nothing to compare.")
        return []
    try:
        data = json.loads(path.read_text(encoding="utf-8-sig"))
    except ValueError as error:
        raise Stop(f"{show(path)} is not valid JSON ({error}). Repair it, then run again.")
    posts = data.get("posts") if isinstance(data, dict) else data
    if not isinstance(posts, list):
        raise Stop(f'{show(path)} must look like {{"sample_data": true, "posts": [...]}}.')
    return [post for post in posts if isinstance(post, dict) and str(post.get("slug") or "").strip()]


# ---------------------------------------------------------------- comparing two texts

def extract_text(raw: str) -> str:
    lines = raw.lstrip(chr(0xFEFF)).splitlines()
    for position, line in enumerate(lines):
        if TEXT_HEADING.match(line.strip()):
            return "\n".join(lines[position + 1:]).strip()
    total = len(lines)

    def skip_blank(position: int) -> int:
        while position < total and not lines[position].strip():
            position += 1
        return position

    start = skip_blank(0)
    if start < total and lines[start].strip() == "---":  # front matter
        end = start + 1
        while end < total and lines[end].strip() != "---":
            end += 1
        if end < total:
            start = skip_blank(end + 1)
    block = start
    if block < total and re.match(r"^#\s+\S", lines[block]):  # a title, kept unless a header block follows
        block = skip_blank(block + 1)
    end = block
    while end < total and HEADER_LINE.match(lines[end]):
        end += 1
    if end > block:
        start = end
    return "\n".join(lines[start:]).strip()


def content_lines(text: str) -> list[str]:
    return [line.strip() for line in text.splitlines() if line.strip()]


def compare(draft_text: str, posted_text: str) -> dict:
    draft, posted = content_lines(draft_text), content_lines(posted_text)
    added: list[str] = []
    removed: list[str] = []
    changed: list[tuple[str, str]] = []
    unchanged = 0
    matcher = difflib.SequenceMatcher(None, draft, posted, autojunk=False)
    for tag, d1, d2, p1, p2 in matcher.get_opcodes():
        if tag == "equal":
            unchanged += d2 - d1
        elif tag == "delete":
            removed += draft[d1:d2]
        elif tag == "insert":
            added += posted[p1:p2]
        else:  # a block was replaced: pair the lines that look alike, the rest is removed or added
            left = posted[p1:p2]
            taken: set[int] = set()
            pairs: dict[int, str] = {}
            for old in draft[d1:d2]:
                best, best_ratio = None, SAME_LINE
                for position, new in enumerate(left):
                    if position in taken:
                        continue
                    ratio = difflib.SequenceMatcher(None, old, new, autojunk=False).ratio()
                    if ratio >= best_ratio:
                        best, best_ratio = position, ratio
                if best is None:
                    removed.append(old)
                else:
                    taken.add(best)
                    pairs[best] = old
            for position, new in enumerate(left):
                if position in pairs:
                    changed.append((pairs[position], new))
                else:
                    added.append(new)
    draft_words, posted_words = draft_text.split(), posted_text.split()
    blocks = difflib.SequenceMatcher(None, draft_words, posted_words, autojunk=False).get_matching_blocks()
    kept = sum(block.size for block in blocks) / len(draft_words) if draft_words else 0.0
    hook_before, hook_after = (draft[0] if draft else ""), (posted[0] if posted else "")
    return {
        "hook_changed": hook_before != hook_after,
        "hook_before": hook_before, "hook_after": hook_after,
        "added": len(added), "removed": len(removed), "changed": len(changed), "unchanged": unchanged,
        "lines_before": len(draft), "lines_after": len(posted),
        "chars_before": len(draft_text), "chars_after": len(posted_text),
        "words_before": len(draft_words), "words_after": len(posted_words),
        "kept": round(kept, 3),
        "_added": added, "_removed": removed, "_changed": changed,
    }


# ---------------------------------------------------------------- writing the files

def cell(text: str) -> str:
    text = re.sub(r"\s*" + chr(0x2014) + r"\s*", ", ", str(text)).replace(chr(0x2013), "-")
    return " ".join(text.split()).replace("|", "\\|")


def signed(value: int) -> str:
    return f"+{value:,}" if value > 0 else f"{value:,}"


def render(entry: dict, result: dict) -> str:
    lines = [
        f'# Edits: {entry["slug"]}',
        "",
        "What the owner changed between the draft and the text that went out.",
        "",
        f'- draft: `{entry["draft"]}`',
        f'- posted: `{entry["posted"]}`',
        f'- compared on: {entry["compared"][:10]}',
        f'- hook (first line): {"changed" if result["hook_changed"] else "kept"}',
        f'- lines: {result["added"]} added, {result["removed"]} removed, {result["changed"]} changed, '
        f'{result["unchanged"]} kept as they were',
        f'- length: {result["chars_before"]:,} characters before, {result["chars_after"]:,} after '
        f'({signed(result["chars_after"] - result["chars_before"])}). '
        f'{result["words_before"]:,} words before, {result["words_after"]:,} after',
        f'- kept: {result["kept"] * 100:.0f} % of the words of the draft',
        "",
        "## The hook",
        "",
        "| draft | posted |",
        "|---|---|",
        f'| {cell(result["hook_before"])} | {cell(result["hook_after"])} |',
        "",
        "## Changed lines",
        "",
    ]
    if result["_changed"]:
        lines += ["| draft | posted |", "|---|---|"]
        lines += [f"| {cell(old)} | {cell(new)} |" for old, new in result["_changed"]]
    else:
        lines.append("None.")
    lines += ["", "## Removed lines", ""]
    lines += [f"- {cell(line)}" for line in result["_removed"]] or ["None."]
    lines += ["", "## Added lines", ""]
    lines += [f"- {cell(line)}" for line in result["_added"]] or ["None."]
    lines += ["", "_Written by `ops/tools/edit_diff.py`. Blank lines are ignored. Do not edit by hand._"]
    return "\n".join(lines) + "\n"


def write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="\n") as handle:
        handle.write(text)


def compare_piece(brain: Path, post: dict) -> tuple[dict | None, str]:
    """Compare one piece. Returns (entry, "") or (None, why it was skipped)."""
    slug = str(post.get("slug")).strip()
    draft, posted = find_files(brain, post)
    if draft is None and posted is None:
        return None, "no draft and no posted text found"
    if draft is None:
        return None, "no draft found"
    if posted is None:
        return None, "no posted text yet"
    try:
        draft_text = extract_text(draft.read_text(encoding="utf-8-sig", errors="replace"))
        posted_text = extract_text(posted.read_text(encoding="utf-8-sig", errors="replace"))
    except OSError as error:
        return None, f"cannot read the files ({explain(error)})"
    if not draft_text or not posted_text:
        return None, "the draft is empty" if not draft_text else "the posted text is empty"
    result = compare(draft_text, posted_text)
    report = brain / "6-debrief" / "metrics" / "edits" / f"{slug}.md"
    entry = {"slug": slug, "date": str(post.get("date") or "")[:10], "title": str(post.get("title") or ""),
             "draft": show(draft), "posted": show(posted), "report": show(report),
             "compared": datetime.now().replace(microsecond=0).isoformat()}
    write_text(report, render(entry, result))
    entry.update({key: value for key, value in result.items() if not key.startswith("_")})
    return entry, ""


def summarize(pieces: list[dict]) -> dict:
    newest = sorted(pieces, key=lambda piece: (piece.get("date", ""), piece.get("slug", "")), reverse=True)[:WINDOW]
    return {
        "pieces": len(pieces),
        "hook_changed": sum(1 for piece in pieces if piece.get("hook_changed")),
        "window": len(newest),
        "hook_changed_in_window": sum(1 for piece in newest if piece.get("hook_changed")),
        "average_kept": round(sum(piece.get("kept", 0) for piece in pieces) / len(pieces), 3) if pieces else None,
    }


def run(brain: Path, slug: str | None) -> None:
    metrics = brain / "6-debrief" / "metrics"
    posts = load_posts(brain, needed=slug is None)
    if slug is not None:
        posts = [post for post in posts if str(post.get("slug")).strip() == slug] or [{"slug": slug}]
    if not posts:
        raise Stop(f'No piece in {show(metrics / "posts.json")} yet. Nothing to compare.')
    done: list[dict] = []
    skipped: list[dict] = []
    for post in posts:
        entry, why = compare_piece(brain, post)
        if entry:
            done.append(entry)
        else:
            skipped.append({"slug": str(post.get("slug")).strip(), "reason": why})
    if not done:
        if slug is not None:
            raise Stop(f'Nothing to compare for "{slug}": {skipped[0]["reason"]}. '
                       f"Expected {show(brain)}/5-narrate/drafts/{slug}/piece.md and a file in {show(brain)}/5-narrate/posted/.")
        raise Stop("No piece has both a draft and a posted text yet. Nothing to compare.")

    edits_path = metrics / "edits.json"
    pieces, old_skipped = done, []
    if slug is not None and edits_path.is_file():  # keep the other pieces, replace this one
        try:
            old = json.loads(edits_path.read_text(encoding="utf-8-sig"))
            pieces = [piece for piece in old.get("pieces", []) if isinstance(piece, dict) and piece.get("slug") != slug] + done
            old_skipped = [item for item in old.get("skipped", []) if isinstance(item, dict) and item.get("slug") != slug]
        except (ValueError, AttributeError):
            pieces = done
    pieces.sort(key=lambda piece: (piece.get("date", ""), piece.get("slug", "")), reverse=True)
    summary = summarize(pieces)
    write_text(edits_path, json.dumps({
        "generated": datetime.now().replace(microsecond=0).isoformat(),
        "brain": show(brain),
        "summary": summary,
        "pieces": pieces,
        "skipped": old_skipped + skipped,
    }, ensure_ascii=False, indent=2) + "\n")

    print(f'Compared {len(done)} piece{"s" if len(done) != 1 else ""}: reports in {show(metrics / "edits")}/, counts in {show(edits_path)}')
    for entry in done:
        print(f'- {entry["slug"]}: hook {"changed" if entry["hook_changed"] else "kept"}, {entry["added"]} added, '
              f'{entry["removed"]} removed, {entry["changed"]} changed, {entry["kept"] * 100:.0f} % of the draft kept')
    for item in skipped:
        print(f'- skipped {item["slug"]}: {item["reason"]}')
    print(f'The first line was rewritten in {summary["hook_changed_in_window"]} of the last {summary["window"]} compared pieces.')


def main() -> None:
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass
    parser = argparse.ArgumentParser(
        prog="edit_diff.py",
        description="Edit diff: what the owner changed between the draft and the posted text of each piece. "
                    "Writes <brain>/6-debrief/metrics/edits/<slug>.md and edits.json.",
        epilog="How the text is found in each file, and what is counted, is written at the top of this file.",
    )
    which = parser.add_mutually_exclusive_group(required=True)
    which.add_argument("--all", action="store_true", help="every piece of posts.json that has a draft and a posted text")
    which.add_argument("--slug", metavar="S", help="one piece")
    parser.add_argument("--brain", default="brain", metavar="DIR", help="the brain to work on (default: brain)")
    args = parser.parse_args()
    try:
        slug = None
        if not args.all:
            slug = args.slug.strip()
            if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]*", slug):
                raise Stop(f'"{args.slug}" is not a valid slug. Use letters, digits and dashes.')
        run(resolve_brain(args.brain), slug)
    except Stop as problem:
        print(f"edit_diff: {problem}", file=sys.stderr)
        sys.exit(1)
    except OSError as error:
        print(f"edit_diff: cannot read or write the files ({explain(error)}).", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
