#!/usr/bin/env python3
"""Scorecards: each piece against a fixed baseline, then the pillars, then the triggers.

Command (run from the project root):

  python ops/tools/scorecard.py [--brain DIR]        (default: brain)

Reads   <brain>/6-debrief/metrics/posts.json and baseline.json
        <brain>/1-self/pillars.md                    (the names of the pillars, from its headings)
        <brain>/6-debrief/metrics/edits.json         (when it exists: written by edit_diff.py)
Writes  <brain>/6-debrief/metrics/scorecards.md      (for people)
        <brain>/6-debrief/metrics/scorecards.json    (the same data, for the screen)

THE RULES. Numbers only, no opinion.

Readings. A piece is read at 24 h, 72 h and 7 days. A reading with no views figure, or with nothing but
zeros, counts as "not measured yet". Each reading is compared with the baseline: its views against
views_7d_median, its reaction rate (reactions divided by views) against reaction_rate_median, its comment
rate (comments divided by views) against comment_rate_median.

Verdict, on the 7-day reading:
  reach problem       the 7-day views are under 70 percent of the baseline median
  conversion problem  else, the reaction rate is under 70 percent of the baseline rate
  ok                  else
  pending             no 7-day reading yet. The piece stays out of the pillar figures and of the triggers

Score out of 100, on the 7-day reading:
  each ratio "piece divided by baseline" is capped at 2, then turned into points: ratio / 2 x 100
  score = 50 % of the views points + 30 % of the reaction rate points + 20 % of the comment rate points
  (a rate with no baseline is left out, and its weight goes to the others)
  So 50 means "your usual result" and 100 means "twice your usual result, or more".

Triggers. They open a proposal in the feedback loop. They decide nothing.
  pillar-under     the last 4 measured pieces of a pillar are all under the baseline (7-day views)
  pillar-above     the last 4 measured pieces of a pillar are all above the baseline
  outside-pillars  2 or more measured pieces with no pillar (empty or "none") are above the baseline
  pillar-silent    a pillar named in 1-self/pillars.md has no piece in the last 28 days of data. The 28
                   days end on the date of the newest piece. The names are the "##" headings of
                   pillars.md. When they cannot be read, this trigger is skipped and the scorecard says so
  writing-opening  the owner rewrote the first line in 3 or more of the last 8 compared pieces
                   (checked only when edits.json exists)

Standard library only.
"""
from __future__ import annotations

import argparse
import json
import re
import statistics
import sys
from datetime import date, datetime, timedelta
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
READINGS = (("24h", "24 h"), ("72h", "72 h"), ("7d", "7 d"))
REACH_THRESHOLD = 0.70
CONVERSION_THRESHOLD = 0.70
WEIGHTS = (("views_vs_baseline", 0.5), ("reaction_rate_vs_baseline", 0.3), ("comment_rate_vs_baseline", 0.2))
RUN_LENGTH = 4          # pieces in a row, under or above the baseline
OUTSIDE_COUNT = 2       # pieces with no pillar, above the baseline
SILENT_DAYS = 28        # days of data with no piece on a pillar
EDIT_WINDOW, EDIT_COUNT = 8, 3
NO_PILLAR = "(none)"
# Headings of pillars.md that are not pillars.
NOT_A_PILLAR = {
    "pillars", "mypillars", "thepillars", "rhythm", "myrhythm", "therhythm", "mix", "themix", "rules", "notes",
    "note", "changes", "history", "retired", "retiredpillars", "candidates", "candidatepillars", "notapillar",
    "whatisnotapillar", "outsidethepillars", "overview", "summary", "howtousethisfile", "howtoreadthisfile",
    "howthisfileisused", "sources", "evidence", "goals", "audience", "review", "reviewdate", "cadence",
    "calendar", "schedule", "slots",
}


class Stop(Exception):
    """An expected problem: one clear line for the user, no stack trace."""


# ---------------------------------------------------------------- reading the data

def show(path: Path) -> str:
    try:
        return path.resolve().relative_to(ROOT).as_posix()
    except ValueError:
        return path.as_posix()


def explain(error: OSError) -> str:
    """A system error in a few words, with a path from the project root, never a full one."""
    name = ""
    if error.filename:
        try:
            name = Path(str(error.filename)).resolve().relative_to(ROOT).as_posix()
        except (ValueError, OSError):
            name = Path(str(error.filename)).name
    reason = error.strerror or type(error).__name__
    return f"{reason}: {name}" if name else reason


def resolve_brain(text: str) -> Path:
    path = Path(text)
    for candidate in ([path] if path.is_absolute() else [ROOT / path, Path.cwd() / path]):
        if candidate.is_dir():
            return candidate.resolve()
    raise Stop(f"No brain folder at {text}. Give an existing one with --brain DIR, for example --brain brains/<id>.")


def load_json(path: Path, what: str):
    if not path.is_file():
        raise Stop(f"No {what} yet: {show(path)} is missing. Nothing to score.")
    try:
        return json.loads(path.read_text(encoding="utf-8-sig"))
    except ValueError as error:
        raise Stop(f"{show(path)} is not valid JSON ({error}). Repair it, then run again.")


def number(value) -> float | None:
    if value is None or isinstance(value, bool):
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def clean(text) -> str:
    """One table cell: one line, no pipe, no long dashes."""
    text = "" if text is None else str(text)
    text = re.sub(r"\s*" + chr(0x2014) + r"\s*", ", ", text).replace(chr(0x2013), "-")
    return " ".join(text.split()).replace("|", "/")


def parse_date(value) -> date | None:
    try:
        return date.fromisoformat(str(value)[:10])
    except ValueError:
        return None


def pillar_name(value) -> str:
    name = clean(value)
    return "" if name.casefold() in ("", "none", "null", "-", "n/a", "no pillar", NO_PILLAR) else name


def norm(text: str) -> str:
    return re.sub(r"[^a-z0-9]+", "", text.casefold())


def same_pillar(one: str, other: str) -> bool:
    a, b = norm(one), norm(other)
    if not a or not b:
        return False
    return a == b or (min(len(a), len(b)) >= 4 and (a in b or b in a))


def read_pillar_names(path: Path) -> tuple[list[str] | None, str]:
    """The pillar names: the "##" headings of pillars.md. Returns (names, reason when there are none)."""
    if not path.is_file():
        return None, f"{show(path)} is missing"
    headings: list[tuple[int, str]] = []
    in_code = False
    for line in path.read_text(encoding="utf-8-sig", errors="replace").splitlines():
        if line.strip().startswith("```"):
            in_code = not in_code
            continue
        match = None if in_code else re.match(r"^(#{2,3})\s+(.+?)\s*#*\s*$", line)
        if match:
            headings.append((len(match.group(1)), match.group(2)))
    wanted = 2 if any(level == 2 for level, _ in headings) else 3
    candidates = [text for level, text in headings if level == wanted]
    # A "## Pillars" section that holds the pillars as "###" headings.
    for position, (level, text) in enumerate(headings):
        if level == 2 and norm(text) in ("pillars", "mypillars", "thepillars"):
            inside = []
            for next_level, next_text in headings[position + 1:]:
                if next_level <= 2:
                    break
                inside.append(next_text)
            if inside:
                candidates = inside
            break
    names = []
    for text in candidates:
        text = re.sub(r"[*_`]", "", text)
        text = re.sub(r"^\s*(pillar\s*)?\d+\s*[.:)\-]\s*", "", text, flags=re.IGNORECASE)
        text = re.sub(r"^\s*pillar\s*[:\-]\s*", "", text, flags=re.IGNORECASE)
        text = re.sub(r"\s*\([^)]*\)\s*$", "", text)
        text = re.sub(r"\s*[:,\-]\s*\d+\s*(%|percent).*$", "", text, flags=re.IGNORECASE).strip()
        if text and "<" not in text and norm(text) not in NOT_A_PILLAR and text not in names:
            names.append(clean(text))
    if not names:
        return None, f'no pillar heading ("## name") found in {show(path)}'
    return names, ""


# ---------------------------------------------------------------- the numbers

def read_reading(raw, base: dict) -> dict | None:
    if not isinstance(raw, dict):
        return None
    views = number(raw.get("views"))
    reactions, comments, reposts = (number(raw.get(key)) or 0 for key in ("reactions", "comments", "reposts"))
    if views is None or (views <= 0 and not (reactions or comments or reposts)):
        return None
    rate = reactions / views if views > 0 else None
    comment_rate = comments / views if views > 0 else None

    def against(value, reference):
        return round(value / reference, 3) if value is not None and reference > 0 else None

    return {
        "views": int(views), "reactions": int(reactions), "comments": int(comments), "reposts": int(reposts),
        "reaction_rate": round(rate, 4) if rate is not None else None,
        "comment_rate": round(comment_rate, 4) if comment_rate is not None else None,
        "views_vs_baseline": against(views, base["views"]),
        "reaction_rate_vs_baseline": against(rate, base["reaction_rate"]),
        "comment_rate_vs_baseline": against(comment_rate, base["comment_rate"]),
    }


def judge(reading: dict, base: dict) -> tuple[str, int, str]:
    """Verdict, score out of 100, and position (under, above or at the baseline) from the 7-day reading."""
    reach = reading["views_vs_baseline"]
    conversion = reading["reaction_rate_vs_baseline"]
    if reach < REACH_THRESHOLD:
        verdict = "reach problem"
    elif conversion is not None and conversion < CONVERSION_THRESHOLD:
        verdict = "conversion problem"
    else:
        verdict = "ok"
    parts = [(reading[key], weight) for key, weight in WEIGHTS if reading[key] is not None]
    score = round(sum(min(ratio, 2.0) / 2.0 * 100 * weight for ratio, weight in parts) / sum(w for _, w in parts))
    position = "under" if reading["views"] < base["views"] else "above" if reading["views"] > base["views"] else "at"
    return verdict, score, position


def build_piece(post: dict, base: dict) -> dict:
    readings_raw = post.get("readings") if isinstance(post.get("readings"), dict) else {}
    readings = {key: read_reading(readings_raw.get(key), base) for key, _ in READINGS}
    piece = {
        "slug": clean(post.get("slug")),
        "date": str(post.get("date") or "")[:10],
        "title": clean(post.get("title")),
        "pillar": pillar_name(post.get("pillar")),
        "kind": clean(post.get("kind")),
        "format": clean(post.get("format")),
        "hook_type": clean(post.get("hook_type")),
        "chars": post.get("chars"),
        "readings": readings,
        "verdict": "pending", "score": None, "position": None,
    }
    if readings["7d"]:
        piece["verdict"], piece["score"], piece["position"] = judge(readings["7d"], base)
    return piece


def current_run(measured: list[dict]) -> tuple[str | None, int]:
    """How many of the newest measured pieces sit on the same side of the baseline."""
    if not measured or measured[-1]["position"] not in ("under", "above"):
        return None, 0
    side, length = measured[-1]["position"], 0
    for piece in reversed(measured):
        if piece["position"] != side:
            break
        length += 1
    return side, length


def build_pillars(pieces: list[dict], base: dict) -> list[dict]:
    groups: dict[str, dict] = {}
    for piece in sorted(pieces, key=lambda p: (p["date"], p["slug"])):
        group = groups.setdefault(piece["pillar"].casefold(), {"pillar": piece["pillar"] or NO_PILLAR, "pieces": []})
        group["pieces"].append(piece)
    pillars = []
    for key, group in groups.items():
        measured = [piece for piece in group["pieces"] if piece["verdict"] != "pending"]
        median = statistics.median(piece["readings"]["7d"]["views"] for piece in measured) if measured else None
        ok = sum(1 for piece in measured if piece["verdict"] == "ok")
        side, length = current_run(measured)
        pillars.append({
            "pillar": group["pillar"],
            "is_pillar": bool(key),
            "count": len(group["pieces"]),
            "measured": len(measured),
            "median_views_7d": median,
            "median_vs_baseline": round(median / base["views"], 3) if median is not None else None,
            "ok": ok,
            "ok_share": round(ok / len(measured), 3) if measured else None,
            "run": {"side": side, "length": length},
            "last_date": group["pieces"][-1]["date"],
            "pieces": [piece["slug"] for piece in reversed(group["pieces"])],
        })
    pillars.sort(key=lambda p: (not p["is_pillar"], -p["count"], p["pillar"].casefold()))
    return pillars


def find_triggers(brain: Path, pieces: list[dict], pillars: list[dict],
                  names: list[str] | None, reason: str) -> tuple[list[dict], list[str], list[str]]:
    triggers: list[dict] = []
    not_checked: list[str] = []
    notes: list[str] = []
    by_slug_date = sorted(pieces, key=lambda p: (p["date"], p["slug"]))

    for pillar in pillars:
        side, length = pillar["run"]["side"], pillar["run"]["length"]
        if pillar["is_pillar"] and side and length >= RUN_LENGTH:
            measured = [p for p in by_slug_date
                        if p["pillar"].casefold() == pillar["pillar"].casefold() and p["verdict"] != "pending"]
            slugs = [p["slug"] for p in measured[-length:]]
            triggers.append({
                "type": f"pillar-{side}", "lever": "pillar", "pillar": pillar["pillar"], "pieces": slugs,
                "text": f'Pillar "{pillar["pillar"]}": the last {length} pieces are {side} the baseline '
                        f'({", ".join(slugs)}).',
            })

    outside = [p for p in by_slug_date if not p["pillar"] and p["position"] == "above"]
    if len(outside) >= OUTSIDE_COUNT:
        slugs = [p["slug"] for p in outside]
        triggers.append({
            "type": "outside-pillars", "lever": "pillar", "pillar": None, "pieces": slugs,
            "text": f'Outside every pillar: {len(outside)} pieces are above the baseline ({", ".join(slugs)}).',
        })

    dated = [(parse_date(p["date"]), p) for p in pieces if parse_date(p["date"])]
    if names is None:
        not_checked.append(f"Pillars with no piece for {SILENT_DAYS} days: {reason}.")
    elif not dated:
        not_checked.append(f"Pillars with no piece for {SILENT_DAYS} days: no piece has a date.")
    else:
        newest = max(day for day, _ in dated)
        oldest = min(day for day, _ in dated)
        start = newest - timedelta(days=SILENT_DAYS - 1)
        covered = (newest - oldest).days + 1
        short = f" The data covers only {covered} days." if covered < SILENT_DAYS else ""
        for name in names:
            on_pillar = [day for day, p in dated if same_pillar(p["pillar"], name)]
            if any(day >= start for day in on_pillar):
                continue
            last = f"last piece on {max(on_pillar).isoformat()}" if on_pillar else "no piece at all in the data"
            triggers.append({
                "type": "pillar-silent", "lever": "pillar", "pillar": name, "pieces": [],
                "text": f'Pillar "{name}": no piece in the last {SILENT_DAYS} days of data '
                        f'({start.isoformat()} to {newest.isoformat()}), {last}.{short}',
            })
        unknown = sorted({p["pillar"] for p in pieces if p["pillar"] and not any(same_pillar(p["pillar"], n) for n in names)})
        if unknown:
            notes.append("Pillar names used in posts.json but not found in 1-self/pillars.md: " + ", ".join(unknown) + ".")
        notes.append("Pillars read from 1-self/pillars.md: " + ", ".join(names) + ".")

    edits_path = brain / "6-debrief" / "metrics" / "edits.json"
    if edits_path.is_file():
        try:
            edits = json.loads(edits_path.read_text(encoding="utf-8-sig")).get("pieces", [])
            edits = sorted((e for e in edits if isinstance(e, dict)), key=lambda e: str(e.get("date", "")), reverse=True)
            window = edits[:EDIT_WINDOW]
            changed = [str(e.get("slug")) for e in window if e.get("hook_changed")]
            if len(changed) >= EDIT_COUNT:
                triggers.append({
                    "type": "writing-opening", "lever": "writing", "pillar": None, "pieces": changed,
                    "text": f"Writing: the first line was rewritten by the owner in {len(changed)} of the last "
                            f'{len(window)} compared pieces ({", ".join(changed)}).',
                })
        except (ValueError, AttributeError):
            not_checked.append(f"Rewritten openings: {show(edits_path)} is not readable.")
    else:
        not_checked.append("Rewritten openings: edits.json is missing (run edit_diff.py --all first).")
    return triggers, not_checked, notes


# ---------------------------------------------------------------- writing the files

def n(value) -> str:
    return "" if value is None else f"{int(round(value)):,}"


def pct(ratio, digits: int = 0) -> str:
    return "" if ratio is None else f"{ratio * 100:.{digits}f} %"


def label(piece: dict) -> str:
    title = piece["title"] if len(piece["title"]) <= 70 else piece["title"][:67].rstrip() + "..."
    return f'{title} (`{piece["slug"]}`)' if title else f'`{piece["slug"]}`'


def table(header: list[str], rows: list[list[str]]) -> list[str]:
    lines = ["| " + " | ".join(header) + " |", "|" + "---|" * len(header)]
    lines += ["| " + " | ".join(row) + " |" for row in rows]
    return lines


def render(data: dict) -> str:
    base, pieces, pillars = data["baseline"], data["pieces"], data["pillars"]
    measured = [piece for piece in pieces if piece["verdict"] != "pending"]
    lines = ["# Scorecards", ""]
    if data["sample_data"]:
        lines += ["**Sample numbers.** These results were invented for the demo.", ""]
    rates = f'reaction rate {pct(base["reaction_rate"], 2)}' if base["reaction_rate"] else "no reaction rate"
    if base["comment_rate"]:
        rates += f', comment rate {pct(base["comment_rate"], 2)}'
    lines += [
        f'- written by `ops/tools/scorecard.py` on {data["generated"][:16].replace("T", " ")}. Do not edit by hand.',
        f"- pieces: {len(pieces)}, of which {len(measured)} measured at 7 days",
        f'- baseline, fixed: {n(base["views"])} views at 7 days, {rates}'
        + (f'. Source: {base["source"]}' if base["source"] else ""),
        f'- verdict: "reach problem" when the 7-day views are under {pct(REACH_THRESHOLD)} of the baseline. '
        f'Else "conversion problem" when the reaction rate (reactions divided by views) is under '
        f'{pct(CONVERSION_THRESHOLD)} of the baseline rate. Else "ok".',
        "- score, out of 100: 50 is your usual result, 100 is twice your usual result or more. "
        "Views count for 50 %, the reaction rate for 30 %, the comment rate for 20 %.",
        "- in the views columns, the percentage is the share of the 7-day baseline already reached.",
        "",
        "## Pieces, newest first",
        "",
    ]
    rows = []
    for piece in pieces:
        row = [piece["date"], label(piece), piece["pillar"] or NO_PILLAR]
        for key, _ in READINGS:
            reading = piece["readings"][key]
            row.append(f'{n(reading["views"])} ({pct(reading["views_vs_baseline"])})' if reading else "not yet")
        seven = piece["readings"]["7d"]
        row += [pct(seven["reaction_rate"], 2) if seven else "", pct(seven["reaction_rate_vs_baseline"]) if seven else "",
                piece["verdict"], "" if piece["score"] is None else str(piece["score"])]
        rows.append(row)
    lines += table(["date", "piece", "pillar"] + [f"views {name}" for _, name in READINGS]
                   + ["reaction rate 7 d", "rate vs baseline", "verdict", "score"], rows)

    lines += ["", "## Pillars", ""]
    rows = []
    for pillar in pillars:
        run = pillar["run"]
        rows.append([
            pillar["pillar"], str(pillar["count"]), str(pillar["measured"]), n(pillar["median_views_7d"]),
            pct(pillar["median_vs_baseline"]),
            f'{pillar["ok"]} of {pillar["measured"]} ({pct(pillar["ok_share"])})' if pillar["measured"] else "",
            f'{run["length"]} {run["side"]} the baseline' if run["side"] else "",
        ])
    lines += table(["pillar", "pieces", "measured", "median views 7 d", "median vs baseline", "ok pieces",
                    "newest pieces in a row"], rows)
    by_slug = {piece["slug"]: piece for piece in pieces}
    for pillar in pillars:
        lines += ["", f'### {pillar["pillar"]}', ""]
        rows = []
        for slug in pillar["pieces"]:
            piece = by_slug[slug]
            seven = piece["readings"]["7d"]
            rows.append([piece["date"], label(piece), n(seven["views"]) if seven else "not yet",
                         pct(seven["views_vs_baseline"]) if seven else "", piece["verdict"],
                         "" if piece["score"] is None else str(piece["score"])])
        lines += table(["date", "piece", "views 7 d", "vs baseline", "verdict", "score"], rows)

    lines += ["", "## Triggers", ""]
    lines += [f'- {trigger["text"]}' for trigger in data["triggers"]] or ["- None found."]
    if data["not_checked"]:
        lines += ["", "### Not checked", ""] + [f"- {text}" for text in data["not_checked"]]
    if data["notes"]:
        lines += ["", "## Notes", ""] + [f"- {text}" for text in data["notes"]]
    return "\n".join(lines) + "\n"


def write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="\n") as handle:
        handle.write(text)


def run(brain: Path) -> None:
    metrics = brain / "6-debrief" / "metrics"
    results = load_json(metrics / "posts.json", "results")
    posts = results.get("posts") if isinstance(results, dict) else results
    if not isinstance(posts, list):
        raise Stop(f'{show(metrics / "posts.json")} must look like {{"sample_data": true, "posts": [...]}}.')
    posts = [post for post in posts if isinstance(post, dict) and str(post.get("slug") or "").strip()]
    if not posts:
        raise Stop(f'No piece in {show(metrics / "posts.json")} yet. Nothing to score.')
    raw_base = load_json(metrics / "baseline.json", "baseline")
    if not isinstance(raw_base, dict):
        raise Stop(f'{show(metrics / "baseline.json")} must look like {{"views_7d_median": 0, "reaction_rate_median": 0.0}}.')
    notes: list[str] = []
    base = {"views": number(raw_base.get("views_7d_median")) or 0,
            "reaction_rate": number(raw_base.get("reaction_rate_median")) or 0,
            "comment_rate": number(raw_base.get("comment_rate_median")) or 0,
            "source": clean(raw_base.get("source"))}
    if base["views"] <= 0:
        raise Stop(f'The baseline is empty: views_7d_median is 0 in {show(metrics / "baseline.json")}. '
                   "Set it once, from your history.")
    for key in ("reaction_rate", "comment_rate"):
        if base[key] > 1:  # written as a percentage
            base[key] = base[key] / 100
            notes.append(f"The baseline {key.replace('_', ' ')} was above 1: read as a percentage.")
    if base["reaction_rate"] <= 0:
        notes.append('No reaction rate in the baseline: "conversion problem" cannot be detected.')

    pieces = [build_piece(post, base) for post in posts]
    pieces.sort(key=lambda piece: (piece["date"], piece["slug"]), reverse=True)
    names, reason = read_pillar_names(brain / "1-self" / "pillars.md")
    for piece in pieces:  # one spelling per pillar: the one of pillars.md
        piece["pillar"] = next((name for name in names or [] if same_pillar(piece["pillar"], name)), piece["pillar"])
    pillars = build_pillars(pieces, base)
    triggers, not_checked, more_notes = find_triggers(brain, pieces, pillars, names, reason)
    undated = [piece["slug"] for piece in pieces if not parse_date(piece["date"])]
    if undated:
        notes.append("Pieces with no valid date (YYYY-MM-DD): " + ", ".join(undated) + ".")
    data = {
        "generated": datetime.now().replace(microsecond=0).isoformat(),
        "brain": show(brain),
        "sample_data": bool(results.get("sample_data")) if isinstance(results, dict) else False,
        "baseline": base,
        "rules": {"reach_threshold": REACH_THRESHOLD, "conversion_threshold": CONVERSION_THRESHOLD,
                  "score_weights": dict(WEIGHTS), "run_length": RUN_LENGTH, "outside_count": OUTSIDE_COUNT,
                  "silent_days": SILENT_DAYS},
        "pieces": pieces,
        "pillars": pillars,
        "triggers": triggers,
        "not_checked": not_checked,
        "notes": notes + more_notes,
    }
    write_text(metrics / "scorecards.md", render(data))
    write_text(metrics / "scorecards.json", json.dumps(data, ensure_ascii=False, indent=2) + "\n")

    measured = [piece for piece in pieces if piece["verdict"] != "pending"]
    counts = {verdict: sum(1 for piece in pieces if piece["verdict"] == verdict)
              for verdict in ("ok", "reach problem", "conversion problem", "pending")}
    print(f'Scorecards written: {show(metrics / "scorecards.md")} and scorecards.json')
    if data["sample_data"]:
        print("Sample numbers: these results were invented for the demo.")
    print(f"{len(pieces)} pieces, {len(measured)} measured at 7 days: "
          + ", ".join(f"{count} {verdict}" for verdict, count in counts.items() if count))
    print(f"Triggers found: {len(triggers)}")
    for trigger in triggers:
        print(f'- {trigger["text"]}')
    for text in not_checked:
        print(f"- Not checked: {text}")


def main() -> None:
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass
    parser = argparse.ArgumentParser(
        prog="scorecard.py",
        description="Scorecards: each piece at 24 h, 72 h and 7 days against a fixed baseline, a verdict, "
                    "a score out of 100, the pillars, and the triggers of the feedback loop. "
                    "Reads <brain>/6-debrief/metrics/posts.json and baseline.json. "
                    "Writes scorecards.md and scorecards.json next to them.",
        epilog="The verdict and score rules are written at the top of this file.",
    )
    parser.add_argument("--brain", default="brain", metavar="DIR", help="the brain to work on (default: brain)")
    args = parser.parse_args()
    try:
        run(resolve_brain(args.brain))
    except Stop as problem:
        print(f"scorecard: {problem}", file=sys.stderr)
        sys.exit(1)
    except OSError as error:
        print(f"scorecard: cannot read or write the metrics ({explain(error)}).", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
