#!/usr/bin/env python3
"""The ledger of changes: what changed in the brain, who decided, and did it work.

Commands (run from the project root):

  python ops/tools/ledger.py add --id ID --lever L --file F --summary "..." --decision accepted|trial|rejected [--review-date D]
  python ops/tools/ledger.py set --id ID --status applied|kept|rolled-back [--note "..."]

Both commands accept --brain DIR (default: brain), to work on a brain of the shelf (brains/<id>).

The ledger is a markdown table in <brain>/6-debrief/changes/ledger.md. This script is its only writer.
Columns: date | id | lever | file | summary | decision | status | review date | note

  add  one line per decision of the owner on a proposed change. ID is the id of the proposal, for example
       2026-11-writing-01. The lever is lesson, pillar or writing. The status starts as the decision itself
       (accepted, trial or rejected). For "accepted" and "trial", the review date is today plus 28 days
       when --review-date is not given. On an id that already exists, the line is updated and its date kept.
  set  moves the line along its life: applied when the file was changed, then kept or rolled-back at the
       review date. --note says why, in a few words.

Standard library only.
"""
from __future__ import annotations

import argparse
import re
import sys
from datetime import date, timedelta
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
COLUMNS = ["date", "id", "lever", "file", "summary", "decision", "status", "review date", "note"]
LEVERS = ["lesson", "pillar", "writing"]
DECISIONS = ["accepted", "trial", "rejected"]
STATUSES = ["applied", "kept", "rolled-back"]
REVIEW_AFTER_DAYS = 28
HEADER = [
    "# Ledger of changes",
    "",
    "One line per decision the owner took on a proposed change. Oldest first.",
    "Written only by `ops/tools/ledger.py`. Do not edit by hand.",
    "Status: accepted, trial or rejected, then applied, then kept or rolled-back.",
    "",
]


class Stop(Exception):
    """An expected problem: one clear line for the user, no stack trace."""


def show(path: Path) -> str:
    try:
        return path.resolve().relative_to(ROOT).as_posix()
    except ValueError:
        return path.as_posix()


def explain(error: OSError) -> str:
    """A system error in a few words, with a path from the project root, never a full one."""
    name = ""
    if error.filename:
        try:
            name = Path(str(error.filename)).resolve().relative_to(ROOT).as_posix()
        except (ValueError, OSError):
            name = Path(str(error.filename)).name
    reason = error.strerror or type(error).__name__
    return f"{reason}: {name}" if name else reason


def resolve_brain(text: str) -> Path:
    path = Path(text)
    for candidate in ([path] if path.is_absolute() else [ROOT / path, Path.cwd() / path]):
        if candidate.is_dir():
            return candidate.resolve()
    raise Stop(f"No brain folder at {text}. Give an existing one with --brain DIR, for example --brain brains/<id>.")


def clean(text) -> str:
    """One table cell: one line, no pipe, no long dashes."""
    text = "" if text is None else str(text)
    text = re.sub(r"\s*" + chr(0x2014) + r"\s*", ", ", text).replace(chr(0x2013), "-")
    return " ".join(text.split()).replace("|", "/")


def read_rows(path: Path) -> list[dict]:
    rows: list[dict] = []
    header: list[str] | None = None
    for line in path.read_text(encoding="utf-8-sig").splitlines():
        line = line.strip()
        if not line.startswith("|"):
            continue
        cells = [cell.strip() for cell in line.strip("|").split("|")]
        if header is None:
            header = [cell.lower() for cell in cells]
            continue
        if all(set(cell) <= set("-: ") for cell in cells):
            continue
        row = {column: "" for column in COLUMNS}
        for name, cell in zip(header, cells):
            if name in row:
                row[name] = cell
        if row["id"]:
            rows.append(row)
    return rows


def write_rows(path: Path, rows: list[dict]) -> None:
    rows = sorted(rows, key=lambda row: row["date"])
    lines = HEADER + ["| " + " | ".join(COLUMNS) + " |", "|" + "---|" * len(COLUMNS)]
    lines += ["| " + " | ".join(clean(row[column]) for column in COLUMNS) + " |" for row in rows]
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="\n") as handle:
        handle.write("\n".join(lines) + "\n")


def change_id(text: str) -> str:
    value = clean(text)
    if not value or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]*", value):
        raise Stop(f'"{text}" is not a valid id. Use the id of the proposal, for example 2026-11-writing-01.')
    return value


def line_of(row: dict) -> str:
    return " | ".join(row[column] for column in COLUMNS)


def cmd_add(brain: Path, ledger: Path, args) -> None:
    ident = change_id(args.id)
    summary = clean(args.summary)
    if not summary:
        raise Stop('--summary is empty. Say the change in one line, for example --summary "Openings: one line, at most 12 words".')
    lever = args.lever.lower().rstrip("s") if args.lever.lower() in ("lessons", "pillars") else args.lever.lower()
    if lever not in LEVERS:
        raise Stop(f'unknown lever "{args.lever}". Use one of: {", ".join(LEVERS)}.')
    review = clean(args.review_date)
    if review:
        try:
            date.fromisoformat(review)
        except ValueError:
            raise Stop(f'"{args.review_date}" is not a date. Write it as YYYY-MM-DD.')
    elif args.decision != "rejected":
        review = (date.today() + timedelta(days=REVIEW_AFTER_DAYS)).isoformat()
    rows = read_rows(ledger) if ledger.is_file() else []
    row = next((row for row in rows if row["id"] == ident), None)
    if row is None:
        row = {column: "" for column in COLUMNS}
        row.update({"date": date.today().isoformat(), "id": ident})
        rows.append(row)
        action = "added"
    else:
        action = "updated"
    row.update({"lever": lever, "file": clean(args.file).replace("\\", "/"), "summary": summary,
                "decision": args.decision, "status": args.decision, "review date": review})
    row["note"] = clean(args.note)  # a new decision starts with a fresh note
    write_rows(ledger, rows)
    print(f"{action} in {show(ledger)}: {line_of(row)}")


def cmd_set(brain: Path, ledger: Path, args) -> None:
    ident = change_id(args.id)
    if not ledger.is_file():
        raise Stop(f"No ledger yet at {show(ledger)}. Record the decision first with: ledger.py add ...")
    rows = read_rows(ledger)
    row = next((row for row in rows if row["id"] == ident), None)
    if row is None:
        known = ", ".join(row["id"] for row in rows) or "none"
        raise Stop(f'No change "{ident}" in {show(ledger)}. Known ids: {known}.')
    if row["decision"] == "rejected":
        raise Stop(f'{ident} was rejected by the owner: it cannot be "{args.status}". Record a new decision with: ledger.py add ...')
    before = row["status"] or "none"
    row["status"] = args.status
    if args.note is not None:
        row["note"] = clean(args.note)
    write_rows(ledger, rows)
    print(f"{ident}: {before} -> {args.status} in {show(ledger)}: {line_of(row)}")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="ledger.py",
        description="The ledger of changes of a brain: <brain>/6-debrief/changes/ledger.md, one line per decision.",
        epilog='Example: python ops/tools/ledger.py add --id 2026-11-writing-01 --lever writing '
               '--file brain/1-self/writing/post.md --summary "Openings: one line, at most 12 words" --decision trial',
    )
    parser.add_argument("--brain", default="brain", metavar="DIR", help="the brain to work on (default: brain)")
    brain = argparse.ArgumentParser(add_help=False)  # the same option, accepted after the command too
    brain.add_argument("--brain", default=argparse.SUPPRESS, metavar="DIR", help="the brain to work on (default: brain)")
    sub = parser.add_subparsers(dest="command", metavar="add | set")

    add = sub.add_parser("add", parents=[brain], help="record the decision of the owner on a proposed change")
    add.add_argument("--id", required=True, help="the id of the proposal, for example 2026-11-writing-01")
    add.add_argument("--lever", required=True, help="lesson, pillar or writing")
    add.add_argument("--file", required=True, help="the file the change applies to")
    add.add_argument("--summary", required=True, help="the change in one line")
    add.add_argument("--decision", required=True, choices=DECISIONS, help="what the owner decided")
    add.add_argument("--review-date", default="", metavar="D",
                     help=f"YYYY-MM-DD (default: today plus {REVIEW_AFTER_DAYS} days, nothing when rejected)")
    add.add_argument("--note", default=None, help="an optional note")

    change = sub.add_parser("set", parents=[brain], help="move a change along its life")
    change.add_argument("--id", required=True, help="the id of the change")
    change.add_argument("--status", required=True, choices=STATUSES, help="the new status")
    change.add_argument("--note", default=None, help="why, in a few words")
    return parser


def main() -> None:
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass
    parser = build_parser()
    args = parser.parse_args()
    if not args.command:
        parser.print_help()
        sys.exit(2)
    try:
        brain = resolve_brain(args.brain)
        ledger = brain / "6-debrief" / "changes" / "ledger.md"
        {"add": cmd_add, "set": cmd_set}[args.command](brain, ledger, args)
    except Stop as problem:
        print(f"ledger: {problem}", file=sys.stderr)
        sys.exit(1)
    except OSError as error:
        print(f"ledger: cannot read or write the ledger ({explain(error)}).", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
