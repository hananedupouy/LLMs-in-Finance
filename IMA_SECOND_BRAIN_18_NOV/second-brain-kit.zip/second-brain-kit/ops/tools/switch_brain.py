#!/usr/bin/env python3
"""Switch brain: put another brain in use. The agents stay the same.

Commands (run from the project root):

  python ops/tools/switch_brain.py list       the active brain and the brains on the shelf
  python ops/tools/switch_brain.py use ID     brain/ goes to brains/<its id>/, brains/<ID>/ becomes brain/
  python ops/tools/switch_brain.py new ID --owner NAME --produces "..." [--kinds post,article] [--name "..."]
                                              a new brain from brains/_template/, put in use, with the
                                              files of my-documents/ copied into brain/1-self/_raw/
  python ops/tools/switch_brain.py documents  copy the files of my-documents/ that are not yet in
                                              brain/1-self/_raw/. Copies only: never moves, never overwrites

The active brain is always the folder brain/. The others wait in brains/<id>/. The id of a brain is the
line "- id: ..." of its BRAIN.md.

`use` only moves folders. It never deletes and never overwrites. It refuses, and changes nothing, when:
  - brains/<ID>/ does not exist, or has no BRAIN.md, or is a template (its name starts with "_");
  - the active brain has no id in brain/BRAIN.md (there would be no name to shelve it under);
  - brains/<active id>/ already exists.
When the second move fails, the first one is undone.

Standard library only.
"""
from __future__ import annotations

import argparse
import os
import re
import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
ACTIVE = ROOT / "brain"
SHELF = ROOT / "brains"
TEMPLATE = SHELF / "_template"
DOCUMENTS = ROOT / "my-documents"
VALID_ID = re.compile(r"[A-Za-z0-9][A-Za-z0-9._-]*")


class Stop(Exception):
    """An expected problem: one clear line for the user, no stack trace."""


def explain(error: OSError) -> str:
    """A system error in a few words, with a path from the project root, never a full one."""
    name = ""
    if error.filename:
        try:
            name = Path(str(error.filename)).resolve().relative_to(ROOT).as_posix()
        except (ValueError, OSError):
            name = Path(str(error.filename)).name
    reason = error.strerror or type(error).__name__
    return f"{reason}: {name}" if name else reason


def read_card(folder: Path) -> dict:
    """The "- key: value" lines of BRAIN.md, and its title."""
    card = {"title": "", "id": ""}
    path = folder / "BRAIN.md"
    if not path.is_file():
        return card
    for line in path.read_text(encoding="utf-8-sig", errors="replace").splitlines():
        if line.startswith("# ") and not card["title"]:
            card["title"] = line[2:].strip()
        match = re.match(r"^\s*[-*]\s*([A-Za-z_]+)\s*:\s*(.*)$", line)
        if match and not card.get(match.group(1).lower()):
            card[match.group(1).lower()] = match.group(2).strip().strip('"')
    if not VALID_ID.fullmatch(card.get("id", "")):
        card["id"] = ""  # empty, or a placeholder left to fill
    return card


def describe(card: dict) -> str:
    parts = [f'"{card["title"]}"' if card.get("title") else "", f'kind: {card["kind"]}' if card.get("kind") else "",
             f'produces: {card["produces"]}' if card.get("produces") else "",
             "sample numbers" if card.get("sample_data", "").lower() in ("yes", "true") else ""]
    return "  ".join(part for part in parts if part)


def shelf_folders() -> list[Path]:
    if not SHELF.is_dir():
        return []
    return sorted(path for path in SHELF.iterdir() if path.is_dir())


def cmd_list() -> None:
    if ACTIVE.is_dir():
        card = read_card(ACTIVE)
        name = card["id"] or "(no id: add a line \"- id: ...\" to brain/BRAIN.md)"
        print(f"Active brain (brain/): {name}  {describe(card)}".rstrip())
    else:
        print("Active brain (brain/): none. Put one in use with: switch_brain.py use ID")
    folders = shelf_folders()
    print("On the shelf (brains/):" if folders else "On the shelf (brains/): nothing")
    for folder in folders:
        card = read_card(folder)
        if folder.name.startswith("_"):
            print(f"  {folder.name}  (a template: copy it to brains/<your-id>/ to start a new brain)")
        elif not (folder / "BRAIN.md").is_file():
            print(f"  {folder.name}  (no BRAIN.md: not a brain yet)")
        else:
            other = f'  (its BRAIN.md says id: {card["id"]})' if card["id"] and card["id"] != folder.name else ""
            print(f"  {folder.name}  {describe(card)}{other}".rstrip())


def move(source: Path, target: Path) -> None:
    try:
        os.rename(source, target)
    except PermissionError:
        raise Stop(f"Cannot move {source.name}/: it is in use. A file of this folder is open in a program or in a "
                   "terminal. Close it and try again.")
    except OSError as error:
        raise Stop(f"Cannot move {source.name}/ to {target.relative_to(ROOT).as_posix()}/ ({explain(error)}).")


def cmd_use(wanted: str) -> None:
    wanted = wanted.strip().strip("/\\")
    if not VALID_ID.fullmatch(wanted) and not wanted.startswith("_"):
        raise Stop(f'"{wanted}" is not a brain id. See the ids with: switch_brain.py list')
    active_card = read_card(ACTIVE) if ACTIVE.is_dir() else None
    if active_card and active_card["id"] == wanted:
        print(f"{wanted} is already the active brain. Nothing changed.")
        return
    target = SHELF / wanted
    if not target.is_dir():  # the folder may have another name than the id
        target = next((folder for folder in shelf_folders() if read_card(folder)["id"] == wanted), target)
    if not target.is_dir():
        known = ", ".join(folder.name for folder in shelf_folders() if not folder.name.startswith("_")) or "none"
        raise Stop(f"No brain {wanted} on the shelf (brains/{wanted}/ does not exist). On the shelf: {known}. Nothing changed.")
    if target.name.startswith("_"):
        raise Stop(f"brains/{target.name}/ is a template, not a brain. Copy it to brains/<your-id>/, fill its BRAIN.md, "
                   "then use that id. Nothing changed.")
    if not (target / "BRAIN.md").is_file():
        raise Stop(f"brains/{target.name}/ has no BRAIN.md: it is not a brain. Nothing changed.")

    if active_card is None:  # nothing in use: only one move
        move(target, ACTIVE)
        print(f"Active brain is now: {wanted} (brain/). There was no active brain before.")
        return
    if not active_card["id"]:
        raise Stop('The active brain has no id: add a line "- id: <short-name>" to brain/BRAIN.md, then switch. '
                   "Nothing changed.")
    shelved = SHELF / active_card["id"]
    if shelved.exists():
        raise Stop(f'brains/{active_card["id"]}/ already exists: the active brain cannot be shelved there. '
                   "Rename or move that folder, then switch. Nothing changed.")
    SHELF.mkdir(exist_ok=True)
    try:
        move(ACTIVE, shelved)
    except Stop as problem:
        raise Stop(f"{problem} Nothing changed.")
    try:
        move(target, ACTIVE)
    except Stop as problem:
        os.rename(shelved, ACTIVE)  # undo the first move
        raise Stop(f"{problem} Nothing changed.")
    print(f'Active brain is now: {wanted} (brain/). Shelved: {active_card["id"]} (brains/{active_card["id"]}/).')
    print("The agents and the skills did not change. Reload Mission Control to see the new brain.")


def one_line(text: str) -> str:
    return " ".join(str(text).split())


def cmd_documents(quiet_when_empty: bool = False) -> None:
    """Copy what the owner dropped in my-documents/ into the Self of the active brain. Copies only."""
    if not (ACTIVE / "BRAIN.md").is_file():
        raise Stop("No active brain (brain/BRAIN.md is missing). Start one with: switch_brain.py new ID ...")
    found = []
    if DOCUMENTS.is_dir():
        found = sorted(path for path in DOCUMENTS.rglob("*")
                       if path.is_file() and not path.name.startswith((".", "_"))
                       and path.relative_to(DOCUMENTS).as_posix().lower() != "readme.md")
    if not found:
        if not quiet_when_empty:
            print("my-documents/ holds no document yet. Drop your CV, a bio and a few pieces you wrote there, "
                  "then run this again. Nothing was copied.")
        return
    raw = ACTIVE / "1-self" / "_raw"
    copied, kept = [], []
    for path in found:
        inside = path.relative_to(DOCUMENTS)
        target = raw / inside
        if target.exists():
            kept.append(inside.as_posix())
            continue
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, target)
        copied.append(inside.as_posix())
    print(f"Copied {len(copied)} document(s) from my-documents/ into brain/1-self/_raw/. "
          f"Already there: {len(kept)}. Your originals did not move.")
    for name in copied:
        print(f"  {name}")
    other = [name for name in copied if not name.lower().endswith((".md", ".txt", ".markdown"))]
    if other:
        print(f"{len(other)} of them are not plain text. Make their text copies with: "
              "python ops/tools/library.py convert brain/1-self/_raw")


def cmd_new(wanted: str, owner: str, produces: str, kinds: str, name: str) -> None:
    wanted = wanted.strip().strip("/").lower()
    if not re.fullmatch(r"[a-z0-9][a-z0-9-]*", wanted):
        raise Stop(f'"{wanted}" cannot be a brain id. Use lower case letters, digits and dashes, for example my-brand.')
    if not (TEMPLATE / "BRAIN.md").is_file():
        raise Stop("brains/_template/ is missing: there is no empty brain to copy. Nothing changed.")
    active_card = read_card(ACTIVE) if ACTIVE.is_dir() else None
    if (SHELF / wanted).exists() or (active_card and active_card["id"] == wanted):
        raise Stop(f"A brain {wanted} already exists. Put it in use with: switch_brain.py use {wanted}. Nothing changed.")
    if active_card and not active_card["id"]:
        raise Stop('The active brain has no id: add a line "- id: <short-name>" to brain/BRAIN.md first. Nothing changed.')
    if active_card and (SHELF / active_card["id"]).exists():
        raise Stop(f'brains/{active_card["id"]}/ already exists: the active brain cannot be shelved there. '
                   "Rename or move that folder first. Nothing changed.")
    kind_list = [re.sub(r"[^a-z0-9-]+", "-", kind.strip().lower()).strip("-") for kind in kinds.split(",")]
    kind_list = [kind for kind in kind_list if kind] or ["piece"]
    title = one_line(name) or wanted
    target = SHELF / wanted
    shutil.copytree(TEMPLATE, target)
    card = (f"# {title}\n- id: {wanted}\n- owner: {one_line(owner)}\n- kind: real\n"
            f"- produces: {one_line(produces)}\n- piece_kinds: {', '.join(kind_list)}\n- sample_data: no\n\n"
            "Each of the six folders has a short README: what goes there, and who writes it.\n"
            "Each kind of piece has its writing rules in `1-self/writing/<kind>.md`.\n")
    with open(target / "BRAIN.md", "w", encoding="utf-8", newline="\n") as handle:
        handle.write(card)
    model = target / "1-self" / "writing" / "piece.md"
    if model.is_file():
        for kind in kind_list:
            if kind != "piece" and not (model.parent / f"{kind}.md").exists():
                shutil.copy2(model, model.parent / f"{kind}.md")
        if "piece" not in kind_list:
            model.unlink()
    print(f"New brain: {wanted} (brains/{wanted}/), from the empty template. Kinds of pieces: {', '.join(kind_list)}.")
    cmd_use(wanted)
    cmd_documents(quiet_when_empty=True)


def main() -> None:
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass
    parser = argparse.ArgumentParser(
        prog="switch_brain.py",
        description="Switch brain: brain/ is the active brain, brains/<id>/ is the shelf. "
                    "`use ID` swaps the two folders. Nothing is ever deleted.",
        epilog="Example: python ops/tools/switch_brain.py use project-manager",
    )
    sub = parser.add_subparsers(dest="command", metavar="list | use ID | new ID | documents")
    sub.add_parser("list", help="show the active brain and the shelf")
    use = sub.add_parser("use", help="put the brain ID in use, and shelve the active one")
    use.add_argument("id", metavar="ID", help='the id of a brain on the shelf (the "- id:" line of its BRAIN.md)')
    new = sub.add_parser("new", help="start a new brain from the empty template, put it in use, copy my-documents/")
    new.add_argument("id", metavar="ID", help="a short name, lower case with dashes, for example my-brand")
    new.add_argument("--owner", required=True, metavar="NAME", help="the first name of the owner of the brain")
    new.add_argument("--produces", required=True, metavar="TEXT", help="one line: what this brain helps to produce")
    new.add_argument("--kinds", default="piece", metavar="A,B", help="the kinds of pieces, for example post (default: piece)")
    new.add_argument("--name", default="", metavar="TEXT", help="the title of the brain (default: its id)")
    sub.add_parser("documents", help="copy the new files of my-documents/ into brain/1-self/_raw/")
    args = parser.parse_args()
    try:
        if args.command == "list":
            cmd_list()
        elif args.command == "use":
            cmd_use(args.id)
        elif args.command == "new":
            cmd_new(args.id, args.owner, args.produces, args.kinds, args.name)
        elif args.command == "documents":
            cmd_documents()
        else:
            parser.print_help()
            sys.exit(2)
    except Stop as problem:
        print(f"switch_brain: {problem}", file=sys.stderr)
        sys.exit(1)
    except OSError as error:
        print(f"switch_brain: {explain(error)}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
