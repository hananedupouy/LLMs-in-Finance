# The constitution of this second brain

A second brain is a small team of AI agents that works on plain files. It knows who you are,
listens, remembers, proposes, writes in your voice and learns from results. You decide.

## The SECOND method

| Step | Organ | The question it answers | Memory | Agents |
|---|---|---|---|---|
| **S** Self | identity | Who am I, how do I speak, what do I refuse? | `brain/1-self/` | Sofia the Biographer (interviews), Sacha the Voice Coach (tunes), Serena the Brand Strategist (positions), Sosie the Double (imitates, reviewer) |
| **E** Ears | perception | What should reach me, and through which door? | `brain/2-ears/` | Emma the Front Desk (captures), Carl the Gatekeeper (scores) |
| **C** Condense | memory | What is worth keeping, and what does it really say? | `brain/3-condense/` | Chloe the Analyst (summarizes), Cato the Fact-Checker (verifies, reviewer) |
| **O** Orient | planning | What do I do next? | `brain/4-orient/` | Olivia the Planner (plans) |
| **N** Narrate | action | How do I say it, in my voice, with proof? | `brain/5-narrate/` | Naomi the Ghostwriter (drafts), Nora the Editor (reviews, reviewer), Noah the Record Keeper (records) |
| **D** Debrief | learning | What worked, and what do I change? | `brain/6-debrief/` | Dexter the Scorekeeper (measures), Diane the Coach (coaches), Diego the Skeptic (challenges, reviewer) |

Debrief feeds Self: lessons and rules go back to the start. Alfred, the Chief of Staff, routes the work.
The team: 16 agents. 11 workers, 4 reviewers, and Alfred. Noah, the Record Keeper, files what really went out.

## The seven house rules

1. **You decide, the brain proposes.** No agent publishes, posts or sends anything. The human does.
2. **Self first.** Read `brain/BRAIN.md` and `brain/1-self/` before you write a word.
3. **Faithful before clever.** A source is summarized in its own order before anyone has an opinion.
4. **One agent, one job, one folder.** If two agents write the same file, the design is wrong.
5. **Nobody reviews their own work.** A reviewer never rewrites what it reviews.
6. **Your taste beats the numbers.** A measured lesson never overrides `brain/1-self/rules.md`.
7. **Every run leaves a trace.** A start line, a stop line, a queue line at a gate: skill `run-trace`.

## The folder map

```
CLAUDE.md          this page                          README.md         how to start
.claude/agents/    the team, one file per agent       .claude/skills/   the know-how, 31 skills
brain/             the ACTIVE brain: BRAIN.md, then 1-self to 6-debrief
brains/            the shelf: the brains not in use, and _template/
ops/tools/         small scripts, no AI inside        ops/runs/         one line per run
ops/queue.json     "Waiting for you" (readable view: ops/waiting-for-you.md)
ops/routines.json  the routines, as the screen shows them
demo/              saved states, the starter kit      docs/             the guides
my-documents/      who the owner is: read at Step S   my-knowledge/     what the owner knows: filed at Step E
```

The agents are generic. They say "piece". What a piece is, and how it is written, comes from
`brain/BRAIN.md` and `brain/1-self/writing/<kind>.md`. Switch the brain and the same team does another job.

## One file, one writer

Every file has exactly one writer: the agent that owns it. A reviewer writes only its review file.
Five files are written by a tool and never by hand: the memory index (`memory_index.py`), the
ledger of changes (`ledger.py`), the queue and its view (`queue.py`), the radar page of the day
(`radar.py`), the library page and the owner's own documents filed as sources (`library.py`).
A decision of the human is never guessed: put a line in the queue, then stop.

Two traps when you write a file. Save it with the Write tool, never with a shell command: a long
text with quotes breaks the command and nothing is written. Never start a file name with
`summary`, `report`, `findings` or `analysis`: an agent tool may refuse the write.

The human answers a first version with "approve" or "change: ...". A change the human dictates
is applied and approved: the same file is not sent back for a second review.
One rule, one home: a limit lives in `brain/1-self/rules.md` or `not-me.md`. Other files point
to it, they never copy it.

## Start

```
Start my brain (double-click)                                 the screen, then Alfred
claude --agent alfred                                         talk to Alfred, he calls the right agent
python .claude/skills/mission-control/scripts/serve.py        the screen, on this machine only (--journey: where the owner is, as text)
```

The owner says "continue": Alfred says where they are in the six steps and starts the next thing.

The routines Alfred follows are in the skill `routines`. Ten skills are launched by the human, with
a slash: `/build-self` to `/build-debrief` (one per step), `/capture`, `/mission-control`,
`/mission-control-design` and `/agent-card`.

## Tools (run from this folder, each has --help)

```
python .claude/skills/run-trace/scripts/log_run.py start --agent NAME [--routine R] [--summary "..."]
python .claude/skills/run-trace/scripts/log_run.py stop  --agent NAME --status done|failed|blocked|waiting --summary "..." [--output PATH ...] [--verdict V]
python .claude/skills/run-trace/scripts/queue.py   add --from NAME --ask "..." [--file PATH] --choices "a|b|c"
python .claude/skills/run-trace/scripts/queue.py   list [--open]   |   resolve ID --decision "..." [--note "..."] [--via screen]   |   applied ID
python ops/tools/memory_index.py  add --slug S --title "T" --source "URL or path" --pillar "P" --summary PATH
python ops/tools/memory_index.py  status --slug S --set new|summarized|checked|drafted|used   |   find "words"
python ops/tools/library.py       scan | file [FOLDER ...] [--all] [--except TEXT] [--private keep|mask|skip] | leave-out FOLDER | status
python ops/tools/library.py       fetch URL (one page or paper, full text) | convert PATH (a PDF, Word or slide file to text)
python ops/tools/radar.py         [--check | --print-schedule]   what is new in your few sources, in brain/2-ears/radar/
python ops/tools/scorecard.py                    each piece against the baseline, the pillars, the triggers
python ops/tools/edit_diff.py     --all | --slug S       what you changed between the draft and the posted text
python ops/tools/ledger.py        add --id ID --lever L --file F --summary "..." --decision accepted|trial|rejected
python ops/tools/ledger.py        set --id ID --status applied|kept|rolled-back [--note "..."]
python ops/tools/switch_brain.py  list | use ID | new ID --owner N --produces "..." [--kinds a,b] | documents
python ops/tools/demo_state.py    save NAME | restore NAME | list
python ops/tools/make_kit.py      [--list | --out DIR]   the starter kit, without any real brain
python .claude/skills/agent-card/scripts/check_cards.py  every agent file is complete, or it says what is missing
```

The tools that read a brain accept `--brain DIR` (default: `brain`).

## Writing in this folder

Plain English, short sentences. No em dash and no en dash: use a colon, a comma or a full stop.
Nothing private: no employer, no client, no price, no address, no phone number.
