---
name: record-published
description: How to file what really went out after the owner says a piece is published, sent or delivered. The record format, the facts to keep, and what must never be inferred. Used by Noah, the Record Keeper.
user-invocable: false
---

# Record what was published

## When to use
Only after the owner said, in their own words, that a piece went out: "published", "sent",
"delivered", "it is out". Never because a draft is ready or a review said PASS.

## Inputs
- The slug of the piece: `brain/5-narrate/drafts/<slug>/`.
- The owner's word, quoted in your task.
- The final text: pasted by the owner, or "as the draft" (then the last `piece.md`).
- The date it went out. If it is not given, ask. Do not assume today.

## Steps
1. Read `brain/BRAIN.md` for the kind of piece, and the draft folder for the pillar and the
   title.
2. Build the record file `brain/5-narrate/posted/<date>-<slug>.md` in the format below.
3. Copy the final text exactly under `## Text`. Keep line breaks. Change nothing.
4. Set the memory status of the source item to `used`:
   `python ops/tools/memory_index.py status --slug S --set used`
   If the piece came from an idea and not from an index line, skip this step and say so.
5. Leave the draft folder untouched.

## Output format
```
# <Title of the piece>
- date: 2026-11-18
- slug: <slug>
- kind: <kind of piece, from BRAIN.md>
- pillar: <pillar>
- format: <text, document, image, other>
- hook_type: <the kind of opening, in two or three words>
- chars: <length of the final text>
- draft: brain/5-narrate/drafts/<slug>/piece.md
- recorded_on: <date of today>
- said_by_owner: "<the owner's words>"

## Text
<the final text, exactly as it went out>
```

## Check before you finish
- The owner's word is quoted in the record.
- The text under `## Text` is identical to what the owner gave, character for character.
- The date is the date it went out, not the date of the draft.
- No number of views or reactions is in the file.
- The draft still exists.

## Common mistakes
- Recording a piece because it was approved. Approved is not published.
- Using the draft when the owner changed the text on the way out. Their edits are the most
  valuable signal of the feedback loop: record what they sent.
- Tidying the text. A typo that went out stays in the record.
- Inventing the hour or the date.
