---
name: radar
description: The daily radar of a brain. A small script with no AI inside reads up to three sources (an arXiv search, or any blog with an RSS or Atom feed) and writes one page per day, brain/2-ears/radar/<date>.md, with every item new since the last run, each with the same detail (title, link, date, authors, abstract or first paragraph). Nothing is judged, ranked or cut and nothing goes in the inbox by itself. Then Carl, the Gatekeeper, scores the day and keeps 20 at most. The owner keeps an item with /capture and its link. Use it when the owner asks "what is new today?" or "run the radar", to set the radar up or change its sources, and to schedule it every morning at 07:00.
user-invocable: false
---

# Radar: what is new in my few sources, every morning

## When to use
- The owner asks "what is new today?", "run the radar", "anything new on arXiv?".
- `/build-ears` reaches its radar option, or the owner wants to add, change or remove a source.
- The owner wants it to run by itself every morning.
- Not to capture by hand (`capture`). Not to summarize a paper (`summarize-source`, after a capture).

The Front Desk waits for you. The radar goes and looks, once a day, in the few places you trust.
It is a list, not a judgment: you read it with your coffee and keep one or two items.

## How it works
```
brain/2-ears/radar.json            your sources (you, or /build-ears, write it)
        |
python ops/tools/radar.py          no AI inside: reads each source, keeps what is new
        |
brain/2-ears/radar/<date>.md       the page of the day, for you: newest first, a /capture line per item
brain/2-ears/radar/<date>.json     the same items as data, for the agent that will score them
brain/2-ears/radar/seen.json       what was already listed: nothing comes twice
        |
Carl, the Gatekeeper               scores every item against your rubric (skill gatekeeper)
brain/2-ears/shortlist/<date>.md   0.7 or more, 20 at most, best first, and what was skipped
        |
you: /capture <link>               Emma files a card. Then Condense: Chloe, Cato
```

One file, one writer: `radar.json` is the owner's. The files of `radar/` are written only by
`radar.py`. The inbox stays Emma's: the radar never writes a card.

## Every item, the same detail
The radar does not pick. Every new item gets the same fields: title, link, date, the first three
authors, and its text. For an arXiv paper the text is the whole abstract, the authors' own
summary. For a blog post it is the first paragraph of the feed. The papers themselves are never
downloaded: they stay on arXiv until the owner captures one.

Why equal: right after the radar, Carl, the Gatekeeper, scores every item against the owner's
rubric and keeps 20 at most (skill `gatekeeper`). An item he could judge only by its title would
lose against one with an abstract, whatever its value. The radar gives him a fair input.

## The sources
Three is a good start. Each source is one entry of `radar.json`:

| kind | What it reads | What it needs |
|---|---|---|
| `arxiv` | a search of the arXiv API, newest first | `query`, in the arXiv syntax: `cat:` a category, `abs:` a word of the abstract, `ti:` a word of the title, `AND`, `OR`, quotes for a phrase |
| `rss` | any RSS or Atom feed | `feed`, the URL of the feed, not of the page |

Two settings for all sources: `max_per_source` (default 50, a safety limit: above it, the page
says how many were not listed) and `lookback_days` (default 3: an item older than that is never
listed, even on a first run). A source can have its own `max`.

The arXiv categories that matter most for AI: `cs.AI`, `cs.CL` (language), `cs.LG` (learning),
`cs.MA` (multi-agent). For finance: `q-fin.CP`, `q-fin.TR`, `q-fin.PM`, `q-fin.RM`, `q-fin.ST`,
`q-fin.GN`. Feeds that work today: OpenAI News, `https://openai.com/news/rss.xml`, and the LangChain blog,
`https://www.langchain.com/blog/rss.xml`. Some sites (the LlamaIndex blog, for one)
have no feed at all: they cannot be on the radar. Capture them by hand.

## Steps
### A. Run it, and read it with the owner
0. Read its status first (part D). Running: wait for its stop line. Already done today (the 07:00
   run): do not run it again unless the owner asks for a new run, read that page.
1. `python ops/tools/radar.py`. It prints one line per source: read, new, listed.
2. Open `brain/2-ears/radar/<today>.md`. Give the owner the count per source and the titles.
   Do not rank them, do not summarize them: the abstract is in the page.
3. Then Carl scores the day (skill `gatekeeper`) and writes `brain/2-ears/shortlist/<date>.md`.
   The owner reads the shortlist, not the whole page. No approved rubric yet: the owner skims
   the page. The owner keeps an item: `/capture <its link>` (or hand it to Emma). One capture
   per item.
4. A source says "could not be read": say so. It is tried again at the next run. Never invent
   what it would have said.

### B. Set it up, or change a source
1. No `brain/2-ears/radar.json`: copy `brains/_template/2-ears/radar.json`. Never overwrite one.
2. Ask the owner for up to three sources: for each, what to watch and why they trust it.
   Write them in `radar.json`, the owner's words in `name`.
3. `python ops/tools/radar.py --check`. It reads each source once and writes nothing. A FAIL:
   fix the query or the feed URL, or drop the source.
4. Run it once (A). A source that goes over its limit of 50 most days is too wide: narrow the
   query with the owner.

### C. Every morning at 07:00
1. `python ops/tools/radar.py --print-schedule`. It prints the exact lines for this computer and
   this folder: four lines of PowerShell on Windows, one cron line on Mac or Linux.
2. Give them to the owner. **The owner registers the schedule, never you**: it is their computer.
3. The computer must be on. On Windows the task also runs when the computer wakes up, if it was
   off at 07:00. On Mac or Linux, cron does not catch up a missed run.
4. To check the next morning: the page of the day exists, and its first line says the run time.
5. The schedule runs the radar only. Carl runs when you say "what is new today" or "score today's radar" to Alfred.
   Say it to the owner, so they remember it.

### D. Is it running, did it run?
Each run of `radar.py` writes two lines in the run log `ops/runs/<date>.jsonl`, like every agent
(house rule 7): a start (`"agent":"radar","event":"start","status":"running"`) and a stop
(`"event":"stop"`, status `done` or `failed`, the run line as summary, the page and the data as
outputs). The 07:00 run writes them too, with no session open. `--check` writes none.
1. Read the lines of `"agent":"radar"` in today's run log. The last one decides:
   - a start with no stop after it: the radar is running. Started more than 45 minutes ago: the run
     was cut (the computer slept, the window closed). Run it again.
   - a stop `done`: finished, at its time, with its summary ("Run of 07:00: 12 new item(s) from 3
     source(s)."). A stop `failed`: say its summary, word for word.
   - no line today: it did not run today. The schedule is missing, or the computer was off.
2. Done today and no `brain/2-ears/shortlist/<today>.md`: Carl has not scored it yet. Offer it.
3. Never write a radar line by hand, and never run it twice to "check": a second run lists nothing
   new and adds a run of its own.
The screen reads the same lines: the page E · Ears and the home page say running, ran today,
failed or not today.

## Output format
Your message after a run:

    Radar of <date>, run at <hh:mm>
    <name of source 1>: <n> new  (<m> more above the limit)
    <name of source 2>: nothing new
    <name of source 3>: could not be read, tried again tomorrow
    Page: brain/2-ears/radar/<date>.md
    Next: Carl scores it, then keep one with /capture <link>

## Check before you finish
- [ ] Every item in your message is in the page of the day, with its link.
- [ ] Nothing was captured, summarized or ranked without the owner asking.
- [ ] A source that failed is said, not hidden.
- [ ] No scheduled task was created by you.

## Common mistakes
| Mistake | What happens | Do this instead |
|---|---|---|
| Ten sources on day one | A page nobody reads | Three. One more when you miss something |
| A wide arXiv search | More than 50 new papers a day, the rest not listed | Add `abs:` words, or one category less |
| Ranking or cutting the list in the radar | Some items reach the scorer with less detail and lose | The radar lists all, equally. Scoring is Carl's job, right after |
| A page URL in `feed` | The source fails every day | The URL of the RSS or Atom feed |
| Capturing everything the radar lists | The inbox drowns | Keep one or two a day |
| Writing the page or `seen.json` by hand | The next run lists old items again, or skips new ones | Only `radar.py` writes them |
| Creating the scheduled task for the owner | Something runs on their computer they did not set | Print the lines, the owner pastes them |
