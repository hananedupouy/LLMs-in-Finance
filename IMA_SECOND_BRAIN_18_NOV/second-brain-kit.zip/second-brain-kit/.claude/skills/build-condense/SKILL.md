---
name: build-condense
description: Build Step C, Condense (what is worth keeping), of your own brain. Launch it with /build-condense. It checks what exists in brain/3-condense/, asks which source or which folder of your own knowledge to start with, calls Chloe for a faithful summary (or one knowledge card per document of yours) and Cato for the fact-check, shows the lines in the memory index, and ends on the "Done when" checklist of the step, ticked honestly. Use it after /build-ears, once a source or your own material is filed.
user-invocable: true
---

# Build Step C: Condense

## When to use
- At least one source is filed in `brain/2-ears/sources/` and you want the brain to remember it.
- You want to see the memory work: a faithful summary, a fact-check, a line in the index.
- Not to write a piece from the summary (`/build-narrate`). Not to give an opinion on a source.

Memory is not storage. It is what is left after a source was read faithfully, checked, and
given a status: new, summarized, checked, drafted, used.

You are the session the reader talks to. You check, you ask, you call Chloe then Cato, you tick.

## Inputs
- `brain/BRAIN.md`, `brain/1-self/pillars.md` (Chloe names the pillar of each source).
- `brain/2-ears/sources/`: the sources filed so far. `brain/3-condense/`: what exists.
- The agents of the step: `.claude/agents/chloe.md`, `cato.md`. The tool
  `ops/tools/memory_index.py`.

## Steps
1. **Check the brain.** No `brain/BRAIN.md`, or not the reader's: stop, `/build-self` first.
2. **Check the kit.** `chloe.md`, `cato.md` and `ops/tools/memory_index.py` exist. One is
   missing: name it. Without Cato, a summary can be written but no line can be ticked for it.
3. **Show what exists.** Three counts:
   - the sources of `brain/2-ears/sources/` that have no summary yet;
   - the summaries of `brain/3-condense/summaries/` that have no `fact-check.md`, or one that
     does not say PASS;
   - the lines of `brain/3-condense/index.md`, per status;
   - the reader's own knowledge: `python ops/tools/library.py status`, then the folders of
     `brain/2-ears/library.md` that are filed, with how many of their documents have no index
     line yet. Filed and not digested is the normal state after Step E.
4. **Create what is missing.** Nothing by hand: the index is created by `memory_index.py` at
   the first summary, and each summary folder by Chloe. Never write `index.md` yourself.
5. **Ask, in one message:**
   - "Which do I start with: one source, or one folder of your own knowledge?" (list the
     outside sources with no summary, then the reader's filed folders with their counts).
     Nothing filed at all: "Put a document in `my-knowledge/` and say: file my new documents.
     Or paste a text here", then call Emma with "file this source".
   - "Do you want the planted-error test at the end? It takes two minutes."
6. **Call the agents, in this order.**
   1. Chloe: the summary of that source. She adds the index line, status `summarized`.
   2. Cato: the fact-check. PASS: the status becomes `checked`. FIX: Chloe revises once, then
      Cato again, loop 2. BLOCK, or a FIX at loop 2: stop, the reader decides in the queue.
   **A folder of the reader's own knowledge.** The same two agents, in batches.
   1. Take from `brain/2-ears/library/state.json` the slugs of that folder that have no index
      line. More than 24: take the first 24, say how many are left for the next time.
   2. Chloe, eight slugs at most per call, three calls at most at a time: one knowledge card
      per document, each registered with a source that starts with `my-knowledge/`.
   3. Cato, the same batches: one fact-check per card. FIX: Chloe revises those cards once,
      then Cato again. BLOCK, or FIX at loop 2: the card stays out of the memory's checked
      lines, and you list it.
   4. One question for the whole folder, in the queue. The reader reads two cards, not all:
      `python .claude/skills/run-trace/scripts/queue.py add --from alfred --ask "Folder <name>: <n> knowledge cards, <p> checked. Read two: is it what you teach?" --file brain/3-condense/summaries/<slug>/condensed.md --choices "approve|change"`
      "change: ..." goes back to Chloe for the cards the reader names, then Cato.
7. **Show the memory.** Run `python ops/tools/memory_index.py find "<two words of the title>"`
   and show the line: date, slug, title, source, pillar, status, summary. Then open the summary
   next to the source and let the reader compare two headings.
8. **The planted-error test, if the reader wants it.** The reader copies `condensed.md` to
   `condensed-test.md` in the same folder and changes one figure by hand. Call Cato on that file.
   He must answer BLOCK in `fact-check-condensed-test.md` and quote the line. He does not: say so
   plainly. A reviewer that missed is not presented as one that passed.
9. **Finish on the checklist.** Tick only what you verified, with the evidence.

## Output format
Your last message to the reader:

    Step C, Condense
    Summary:  brain/3-condense/summaries/<slug>/condensed.md, fact-check <verdict> at loop <n>
    Yours:    folder <name>: <n> knowledge cards, <p> checked, <q> not passed, <r> left for next time
    Planted error: caught (BLOCK, line quoted) | not run | NOT caught

    Done when
    [x] Your own knowledge is in the memory, and marked as yours
        proof: index.md, 12 lines whose source starts with my-knowledge/, 11 checked
    [x] You can filter the inventory by "never used"
        proof: brain/3-condense/index.md, 3 lines, each with a status
    [x] Every summary has the source's own headings
        proof: fact-check.md, 6 headings compared, no finding
    [x] Every summary you build on has a fact-check that says PASS
        proof: 2 summaries, 2 fact-checks at PASS

    Next: /build-orient

The list is the "Done when" of Step C. The filter comes before it: Carl, the Gatekeeper,
scores what the radar brings in Step E (`/build-ears`), so Condense only works on what you
picked. In this kit the inventory is `brain/3-condense/index.md`.

## Check before you finish
- [ ] The summary was written by Chloe and checked by Cato. You wrote neither file.
- [ ] No tick for "headings" or "PASS" without a `fact-check.md` that says it.
- [ ] The index line exists and was written by the tool.
- [ ] A summary that is FIX or BLOCK is reported as such, with the queue id.
- [ ] A folder of the reader got one question, not one per document, and no card was written by you.

## Common mistakes
| Mistake | What happens | Do this instead |
|---|---|---|
| Skipping Cato "because the summary looks fine" | "Faithful" is promised, not verified | The fact-check, every time |
| Summarizing yourself | No independent check is possible | Call Chloe |
| Editing `index.md` by hand | The tool and the file disagree | `memory_index.py` only |
| Changing the figure in `condensed.md` for the test | The real summary is now false | Change a copy, `condensed-test.md` |
| Setting the status `used` | The brain guesses what went out | Only on the owner's word "published" |
| Hiding a missed planted error | The reader trusts a reviewer that failed | Say it, and run it again |
| One approval per document of a folder | Forty questions, the reader gives up | One question per folder, two cards read |
| A whole library in one run | Hours, and nobody reads the cards | One folder at a time, 24 documents at most |
