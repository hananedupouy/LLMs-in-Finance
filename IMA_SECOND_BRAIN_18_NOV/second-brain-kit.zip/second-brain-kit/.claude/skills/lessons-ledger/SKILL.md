---
name: lessons-ledger
description: How Diane, the Coach, keeps lessons.md. At most 10 lessons, each with evidence from at least 2 pieces, status new, confirmed or retired, written as a rule one can apply. A new or changed lesson is first a proposal file (lever lesson) that Diego challenges and the owner accepts. Only then lessons.md is edited and ledger.py is called. Use it to propose a lesson after the weekly review, and to apply, keep or roll back a lesson once the owner has decided.
user-invocable: false
---

# The lessons

## When to use
- The weekly review named a lesson candidate, or a lesson must change (wording, status).
- The owner decided on one of your proposals: apply it.
- The review date of a lesson came and the owner chose keep, extend or roll back.

**Where this sits in the feedback loop.** Seven stages. One agent and its skill at each stage.
This skill is the lesson lever of stage 3 and of stage 6.

| Stage | Who | Skill | Output |
|---|---|---|---|
| 1. Measure | Dexter | `scorecard` (tools `scorecard.py`, `edit_diff.py`) | numbers at 24 h, 72 h, 7 days against a fixed baseline, and what the owner changed between the draft and the posted text |
| 2. Review each piece | Diane | `post-debrief` | one card per piece: numbers, verdict, the owner's edits, what the Editor had flagged, one hypothesis |
| 3. Propose | Diane (lesson), Serena (pillar), Sacha (writing) | `lessons-ledger`, `pillar-review`, `writing-tune-up` | one proposal file per change |
| 4. Challenge | Diego | `change-challenge` | ACCEPT, NEEDS MORE EVIDENCE or REJECT, per proposal |
| 5. Decide | the human | (queue) | accept, trial for 4 weeks, reject, or reword |
| 6. Apply | the owner of the file: Diane `lessons.md`, Serena `pillars.md`, Sacha `voice.md` and `writing/<kind>.md` | same skills | the file changed, one line in the ledger |
| 7. Verify | Sosie now (Double test must not drop), Dexter and Diane at the review date | `double-test`, `scorecard` | kept, extended or rolled back |

Three levers: **lessons** (weekly, at most 10, each with evidence from 2 pieces), **pillars**
(monthly, one move at a time), **writing rules** (monthly, the smallest edit, with a before and
after example). A lesson confirmed for 4 weeks is promoted into the writing rules: name it in
the weekly review, Sacha proposes the edit. The owner's taste beats the numbers: a proposal
that contradicts `rules.md` is dropped by Diego.

## Inputs
- `brain/6-debrief/lessons.md`, retired lessons included.
- The cards in `brain/6-debrief/reviews/posts/` and the last weekly review.
- `brain/1-self/rules.md` and `not-me.md`.
- `brain/6-debrief/changes/`: your proposals, Diego's challenges, `ledger.md`.

## Steps

### A. Propose (stage 3)
1. **Bring your open proposals up to date.** You are the only writer of your proposal files,
   so their `status:` line is yours to keep true: `challenged` after NEEDS MORE EVIDENCE (add
   the evidence once, or wait for more pieces), `rejected` after REJECT (it stops there),
   `waiting` after ACCEPT while the queue line is open, then the owner's decision and part B.
2. **Test the candidate.** It rests on at least 2 pieces, named. You list the pieces that go
   against it too. The owner never dropped it. It does not contradict `rules.md` or
   `not-me.md`. It is about what can be measured (opening, length, structure, format, timing),
   never about the owner's taste.
3. **Write it as a rule one can apply.** "Open on the name the reader trusts", not "names seem
   to help". The test: Naomi can obey it and Nora can check it without asking a question.
4. **Set the status.** `new` at first. `confirmed` after a second week of evidence. `retired`
   when the numbers contradict it, when the owner drops it, or when it is promoted into the
   writing rules. Each of these moves is a change, so each one is a proposal.
5. **Count.** Already 10 lessons that are not retired: the same proposal names the one that
   goes out, the weakest by its evidence.
6. **Write the proposal file**, one per change. The id is `<yyyy-mm>-lesson-<nn>`, with the
   next free number. Then stop: Diego is next. You add no queue line.

### B. Apply (stage 6), only with the owner's decision
Read the decision in your task, or with `python .claude/skills/run-trace/scripts/queue.py list`.

| The owner said | Ledger decision | You |
|---|---|---|
| accept | accepted | make the change |
| trial 4 weeks | trial | make the change, marked "trial until <date>" |
| reject | rejected | change nothing, and never propose it again |
| reword | accepted | put the owner's wording in "Proposed", then make the change |

1. `python ops/tools/ledger.py add --id <id> --lever lesson --file brain/6-debrief/lessons.md --summary "<one line>" --decision accepted|trial|rejected --review-date <YYYY-MM-DD>`
2. Edit `lessons.md`: exactly the text of "Proposed", nothing else.
3. `python ops/tools/ledger.py set --id <id> --status applied`
4. Set `status: applied` in the proposal file. On a reject: step 1 only, then `status: rejected`.

### C. Verify (stage 7)
A lesson is not a Self file, so there is no Double test. At the review date the weekly review
compares before and after, and the owner chooses.
- Keep: `python ops/tools/ledger.py set --id <id> --status kept`
- Roll back: restore the text of "Today it says", then
  `python ops/tools/ledger.py set --id <id> --status rolled-back --note "<why>"`
- Extend: run the `ledger.py add` line again with `--decision trial` and the new
  `--review-date`, then `ledger.py set --id <id> --status applied --note "extended"`.

## Output format
`brain/6-debrief/changes/<id>-proposal.md`:

    # Change 2026-11-lesson-01: <one line>
    - id: 2026-11-lesson-01
    - lever: lesson
    - proposed_by: diane
    - file: brain/6-debrief/lessons.md
    - status: proposed

    ## Today it says        (the exact text that would change, or "nothing: a new lesson")
    ## Proposed             (the exact text to put in lessons.md)
    ## Evidence             (each piece: its card path and what happened. Then what goes against)
    ## Expected effect      (what should move, on which reading)
    ## Review date          (a date, 4 weeks after the change)
    ## What could be lost   (what the lesson might cost)

`brain/6-debrief/lessons.md`: a first line saying that the owner's rules win, then one block
per lesson, the retired ones under `## Retired`:

    ### L03: <the rule, in a few words>
    - Status: new | confirmed | retired (numbers | owner | promoted to the writing rules)
    - Since: <date>
    - Rule: <an order one can apply and check>
    - Evidence: <slug> (<what happened>), <slug> (<what happened>). Against: <slug>, or none
    - Change: <id of the proposal>

## Check before you finish
- [ ] Each lesson, old or proposed, names at least 2 pieces. At most 10 are not retired.
- [ ] Each lesson is an order one can apply and check, not an observation.
- [ ] No lesson contradicts `rules.md` or `not-me.md`. None was dropped by the owner before.
- [ ] `lessons.md` changed only after a decision of the owner, and the ledger has its line.
- [ ] "Today it says" holds the exact old text, so that a roll-back is possible.

## Common mistakes
| Mistake | What happens | Do this instead |
|---|---|---|
| A lesson from one success | The brain copies its own luck | Two pieces, or it stays a hypothesis |
| "Shorter pieces seem to do better" | Nobody can apply it | "Stay under <n> characters" |
| An eleventh lesson | Nobody applies eleven rules | Name the one that goes out |
| Writing `lessons.md` first, the proposal after | The challenge is a formality | Proposal, Diego, the owner, then the file |
| A lesson about tone or subjects | The numbers start to rule the taste | That belongs to the owner's rules |
| Deleting a retired lesson | It gets proposed again | Keep it under "Retired" with the reason |
