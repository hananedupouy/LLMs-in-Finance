---
name: plan-next
description: How Olivia, the Planner, proposes what to produce in the next two weeks. She reads the memory index, the captured ideas, the pillars and their rhythm, the lessons and what already went out, then writes brain/4-orient/plan.md with two proposals per slot, each tied to an index line or to a captured idea. Already used and rejected items are left out, the pillar mix is respected. Rules over data, no invention. Use it for any request to plan what comes next, and to record the owner's choices.
user-invocable: false
---

# Plan what comes next

## When to use
- The owner asks "what next?", or the Weekly Council reaches its planning step.
- The owner chose in the queue: record the choices and the rejections in the plan.
- Not to write a piece, not to find new subjects on the web, not to change the pillars or the
  rhythm (that is Serena, and the owner).

A good plan is a short list of options that somebody else prepared, so that the owner's energy
goes into choosing. It is rules over data: the same inputs give the same plan twice.

## Inputs
| What | Where | You take from it |
|---|---|---|
| What the brain knows | `brain/3-condense/index.md` | one candidate per line: slug, title, source, pillar, status. A source that starts with `my-knowledge/` is the owner's own material |
| What the owner captured | `brain/2-ears/inbox/*.md` with `type: idea` | one candidate per card |
| Who the owner is | `brain/1-self/pillars.md` | the pillars, their share of the mix, the rhythm (the slots) |
| The limits | `brain/1-self/rules.md`, `not-me.md` | what can never be proposed |
| What was learned | `brain/6-debrief/lessons.md` | the active lessons about subjects, days, kinds |
| What went out | `brain/5-narrate/posted/` | what is used, and the mix of the last 4 weeks |
| What is ready | `brain/5-narrate/drafts/<slug>/review.md` | drafts whose review says PASS |
| The last plan | `brain/4-orient/plan.md` | its "Rejected" list |

A file is missing: go on without it and say so in the plan. The index and the inbox are both
empty: stop, there is nothing to plan from.

## Steps
1. **Slots.** Take the rhythm from `pillars.md`: which kind of piece, on which days, the rest
   days. List the slots of the 14 days that start tomorrow. No rhythm written: use two slots a
   week, Tuesday and Thursday, and write `rhythm: default, not written in pillars.md`.
2. **Candidates.** Index lines with the status `checked`, `summarized` or `new`, and idea cards.
3. **Remove**, and keep the reason for the section "Left out":
   - the status `used`, and anything whose slug or title is in `brain/5-narrate/posted/`;
   - every line of "Rejected" in the last plan;
   - anything `rules.md` or `not-me.md` forbids (quote the line);
   - a `drafted` line whose draft is not reviewed yet: it is in progress, not a new proposal.
4. **Ready first.** A draft whose review says PASS takes the first free slot of its kind, as
   the only option of that slot, marked "ready".
5. **Mix.** Count the pieces per pillar in what went out in the last 4 weeks. Compare with the
   share each pillar should have. The pillar that is furthest under its share gets the next slot.
6. **Fill each slot with two proposals, A and B.** Two different items. A is the best
   candidate of the slot's pillar. B comes from the next pillar under its share, so that the
   owner has a real choice. One item appears once in the whole plan.
7. **Order the candidates** inside a pillar by these rules, in this order: `checked` before
   `summarized` before `new` before an idea. Then the owner's own material (a source that
   starts with `my-knowledge/`) before an outside source: a piece that rests on what the owner
   taught or built can only be theirs. Then the oldest date first. No other preference.
8. **Apply the lessons.** For each active lesson that names a pillar, a day or a kind: apply
   it, and quote it in the column "Why". A lesson never beats `rules.md` or `not-me.md`.
9. **Say what the item still needs** before it can be written: nothing (`checked`), a
   fact-check (`summarized`), a summary (`new`), a source (an idea). And say where it comes
   from, in the column "Why": `yours` (the source starts with `my-knowledge/`) or `outside`.
10. **Not enough material.** One proposal only, or none: leave the place empty and write it
    under "Could not fill", with the pillar that lacks material. Never invent a subject.
11. **Write the plan**, add the queue line, stop with `--status waiting`.
12. **Record the choices**, when you are called with them: write the option kept in each slot,
    move each refused proposal to "Rejected" with the date and the owner's words, set
    `status: approved`. "New proposals" for one slot rebuilds that slot only.

## Output format
`brain/4-orient/plan.md`:

    # Plan: 2026-11-14 to 2026-11-27
    - built: 2026-11-13
    - status: proposed | approved
    - rhythm: <the line of pillars.md, quoted> | default, not written in pillars.md
    - mix, last 4 weeks: <pillar> 3, <pillar> 1, <pillar> 0
    - missing inputs: none | <file>

    ## Tuesday 2026-11-17, <kind of piece>
    | Option | Subject | From | Pillar | State | Still needs | Why |
    |---|---|---|---|---|---|---|
    | A | <title of the index line> | index: <slug> | <pillar> | checked | nothing | <pillar> is under its share |
    | B | <first words of the idea> | inbox: <file name> | <pillar> | idea | a source | lesson: "<quoted>" |
    - chosen: (empty until the owner chooses)

    ## Could not fill
    - <slot>: <why>

    ## Left out
    - <slug or card>: used | rejected | forbidden by "<line>" | draft in progress

    ## Rejected
    - 2026-11-13, index: <slug>, "<the owner's words, if any>"

"Subject" is the title of the index line or the first words of the card, never a title you
made up. Queue line:

    python .claude/skills/run-trace/scripts/queue.py add --from olivia --ask "Plan 2026-11-14 to 2026-11-27: choose for each slot" --file brain/4-orient/plan.md --choices "approve|swap a slot|new proposals"

## Check before you finish
- [ ] Every proposal names an index slug or an inbox file that exists.
- [ ] No item is proposed twice. No `used` item, no rejected item, nothing forbidden.
- [ ] Each slot has two proposals, or its reason under "Could not fill".
- [ ] The mix line is a count, and each "Why" points to the mix, a lesson or the rhythm.
- [ ] The "Rejected" list of the last plan is carried over, whole.
- [ ] `status` is `proposed`. Only the owner's answer makes it `approved`.

## Common mistakes
| Mistake | What happens | Do this instead |
|---|---|---|
| A subject "that would be great" with no source | The writer has nothing to write from | Only the index and the inbox |
| Ten options per slot | Choosing becomes searching again | Two |
| Forgetting the rejections | The same refused idea every week | Carry "Rejected" over, always |
| Proposing a used item with a new title | The owner repeats themselves | The status `used` removes it |
| Filling a hole with a later piece | The spacing breaks | Leave it under "Could not fill" |
| A different plan at each run | Nobody trusts it | The rules of step 7, in order |
