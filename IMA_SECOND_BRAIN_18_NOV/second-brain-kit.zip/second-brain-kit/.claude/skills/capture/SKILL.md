---
name: capture
description: Store anything in two seconds as one card in brain/2-ears/inbox/. A link, an idea, a note, a file path, a correction ("not me"), a fact about the owner. It never asks a question and never fetches the network unless asked. With the word "fetch" and a link, the full text of the page or of the paper is filed by a small script, never a summary of it. The owner launches it with /capture followed by anything. Emma uses it each time Alfred hands her something to keep.
argument-hint: "[a link, an idea, a note, a file path, a correction]"
user-invocable: true
context: fork
agent: emma
---

# Capture: store first, think later

## When to use
- The owner types `/capture` followed by anything.
- Alfred hands over something the owner threw in with no other request.
- The owner asks to file the full text of a source ("fetch it", "file this source").
- Not to summarize, sort, answer or judge what was given. That comes later, with other agents.

One door for everything captured by hand. A capture that asks questions stops being used.

## Inputs
What to capture: $ARGUMENTS

If nothing follows "What to capture:" above, or only a placeholder, the thing to capture is in
the message that called you. Take it whole: the words, the link, the path, and the reason the
owner gave for keeping it, if there is one.

## Steps
1. **Do not ask anything.** Unclear, incomplete, strange: store it as it is.
2. **Pick the type and the suggested route**, from what the thing is.

   | You receive | type | route |
   |---|---|---|
   | A link, a document, a long pasted text | link, or document | chloe (summary, then the fact-check) |
   | A raw idea, one sentence | idea | olivia (a candidate for the plan) |
   | A draft the owner wrote | draft | nora (review, the owner's text is never modified) |
   | "not me", "never", "from now on", a preference | correction | sofia (logs the owner's words) |
   | A new fact about the owner (a talk, a role, a result) | fact about me | sofia |
   | Results or numbers of a piece | result | dexter |
   | A list of outside sources the owner trusts | source list | owner (reads them by hand, captures what matters) |
   | "One card per folder filed", with `brain/2-ears/library.md` | document, one card per folder | chloe (digests the folder at Step C) |
   | A task, or anything you cannot place | task, or other | alfred |

3. **Name the card.** `<date>-<slug>.md`: today's date as YYYY-MM-DD, then two to six words of
   the title or of the first words, lower case, hyphens, no accent, no punctuation. The name
   exists already: add `-2`.
4. **Links and documents only: one duplicate check.**
   `python ops/tools/memory_index.py find "<the URL, or three words of the title>"`
   Found: write `in_memory: yes, <slug> (<status>)` and `route: none`. The tool says there is no
   index: write `in_memory: no`.
5. **Write the card** in `brain/2-ears/inbox/` (format below). The content is copied exactly:
   same words, same spelling, same link.
6. **Only when asked, file the source.** The request says "fetch", "read it now" or "file this
   source", or it hands you a full text or a local file to keep (format below).
   - A pasted text, or a local `.md` or `.txt` file: write `brain/2-ears/sources/<slug>.md`
     yourself. Copy the text, headings untouched. No network.
   - A link: `python ops/tools/library.py fetch "<the link>"`. The script downloads the page or
     the PDF (an arXiv link gives the paper itself), turns it into text and writes the source
     file. Put the path it prints on the card. You never write a source from what a web tool
     told you about a page: that is a summary, not the text.
   - The script says it failed (a login, a refusal, no PDF reader): do not insist. Write what
     it said on the card, and say in your answer: "Save the page or the PDF in my-knowledge/,
     then say: file my new documents."
   - A local file that is not plain text (a PDF, slides, a Word file, a notebook), or a whole
     folder: do not open it. The card says where it is, and your answer says: "Put it in
     my-knowledge/, then say: file my new documents."
   - One card per folder filed: read `brain/2-ears/library.md`. For each folder whose status
     starts with "filed", one card: the folder, the number of documents, `from: my-knowledge/<folder>`.
7. **Answer in one line** and stop. A link you only stored: add "To keep its full text:
   /capture fetch <the link>".

## Output format
The card, `brain/2-ears/inbox/<date>-<slug>.md`:

    # <a title: the title given, or the first eight words>
    - captured: 2026-11-13
    - type: link | document | idea | draft | correction | fact about me | result | source list | task | other
    - from: typed by the owner | <the site of the link> | <the path of the file, from the folder of the brain>
    - route: <agent> (<what it would do, six words at most>)
    - status: new
    - in_memory: no | yes, <slug> (<status>)

    ## Content
    <exactly what was given: the link, or the text word for word>

    ## Why
    <only if the owner said why they kept it. Otherwise leave this section out>

The source, `brain/2-ears/sources/<slug>.md`, only when asked:

    # <the title of the source, copied exactly>
    - url: <the URL, or "none">
    - fetched: 2026-11-13
    - how: pasted by the owner | copied from <path> | downloaded and converted by library.py
    - origin: external | mine

    <the full text, with its own headings>

`origin: mine` only for what the owner wrote: the script writes it for `my-knowledge/`, and you
write it when the owner says a pasted text is theirs. A path is written from the folder of the
brain, or as the file name alone: never the full path of the computer, it can name the owner.

Your answer: `Captured: brain/2-ears/inbox/<date>-<slug>.md (<type>, suggested route: <agent>)`.

## Check before you finish
- [ ] You asked nothing.
- [ ] The card exists and its "Content" is exactly what was given.
- [ ] The card has a type, a route and `status: new`.
- [ ] You touched the network only because the request asked for it.
- [ ] You wrote in `brain/2-ears/` and nowhere else. You routed nothing yourself.

## Common mistakes
| Mistake | What happens | Do this instead |
|---|---|---|
| "Which pillar is this for?" | The owner stops capturing | Store it. The route is a suggestion |
| Tidying the owner's sentence | The idea is no longer theirs | Word for word |
| Fetching every link | Slow, and a page may refuse | Only on "fetch" or "file this source" |
| Filing what a web tool said about a page | A summary stored as the source: every later check passes on a text nobody wrote | `library.py fetch`, or the owner saves the file |
| Opening the owner's PDF or slides to copy them | Half a text, or a refusal | `my-knowledge/`, then "file my new documents" |
| Summarizing the link on the card | That is Chloe's job, and it is unchecked | The link, nothing more |
| Acting on the route (calling the agent) | Two agents on one thing | Write `route:`. Alfred decides |
| One card for three things | Nothing can be routed | One card per thing captured |
