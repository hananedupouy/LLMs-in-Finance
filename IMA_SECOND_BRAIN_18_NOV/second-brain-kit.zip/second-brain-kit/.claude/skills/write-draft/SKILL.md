---
name: write-draft
description: How Naomi, the Ghostwriter, writes the first version of a piece in the owner's voice from a 3-line brief, and how she revises it after a FIX verdict. Read the Self files and the lessons, pick the pillar, try three openings, keep one idea, check every fact against the source, measure the length, keep the earlier versions. Use it for any request to draft or revise a piece of any kind.
user-invocable: false
---

# Write a draft

## When to use
- A brief arrives and a first version of a piece is wanted.
- Nora answered FIX and a revision is wanted: one revision per FIX verdict, two at most.
- Not to review a draft (`edit-review`, by another agent). Not to change the writing rules
  (`writing-tune-up`).

This skill is the process only. The personal writing rules live in the brain, in
`brain/1-self/writing/<kind>.md`, so that they switch with the brain and so that the feedback
loop can tune them.

## Inputs
The brief, three lines. No more: a long brief gives a specification sheet, not a piece.

    Subject:  the single point the piece makes
    Source:   the path of the checked summary, or of the source itself
    Intent:   for whom it is, and what they should keep or do

Optional: the owner's note (the priority instruction), the kind of piece, the slug. For a
revision: `brain/5-narrate/drafts/<slug>/review.md`.
Read in this order: `brain/BRAIN.md`, `brain/1-self/voice.md`, `rules.md`, `not-me.md`,
`pillars.md`, `brain/1-self/writing/<kind>.md`, `brain/6-debrief/lessons.md`, then the source.

## Steps

### A. First version
1. **Check the brief.** Three lines, and a kind that is one of `piece_kinds` in `BRAIN.md`. A
   line is missing: stop and say which one. Do not guess a subject.
2. **Check the source.** A summary needs a `fact-check.md` next to it that says PASS. Missing,
   FIX or BLOCK: stop. A raw source (a note, a transcript) is allowed: write "raw source, no
   fact-check" in the header.
3. **Check it is not a repeat.** Run `python ops/tools/memory_index.py find "<two or three words>"`
   and look in `brain/5-narrate/posted/`. Already used and nothing new to say: stop and say so.
4. **Check the limits.** The subject is not in `not-me.md` and crosses no "never" of `rules.md`.
5. **Pick the pillar** in `pillars.md`. None fits: write "outside every pillar". It is a signal
   for the feedback loop, not an error.
6. **Name the reader** in a few words, from the intent and the audience of the pillar.
7. **List the lessons** of `lessons.md` that are not retired. You apply each one or say why not.
8. **Write three openings** of different types: the types that `writing/<kind>.md` lists, or
   else a fact of the source, a situation the reader knows, the question the reader already
   asks. One opening alone anchors the piece on the first idea that came. Keep the one that
   works with nothing after it: does it give this reader a reason to go on?
9. **Write the body.** One idea. What does not serve it goes to a later piece. Shape, sections,
   length and closing as `writing/<kind>.md` says. Words and tone as `voice.md` says. Facts:
   only what the source says, with its exact figures and names. Personal moments: only what
   `about-me.md`, the brief or the note states.
   **What the owner built, taught or measured** comes from two places only: `about-me.md`, or a
   checked knowledge card of the owner. Look for one on the subject:
   `python ops/tools/memory_index.py find "<two words>"`, a line whose source starts with
   `my-knowledge/` and whose status is `checked`. You use one: name its path in the header, on
   a line `Also from:`, so that the Editor can check it. The piece needs such a fact and you
   find none: write `[missing: ask the owner: <what>]` at that place. Never fill it yourself.
10. **Save** `brain/5-narrate/drafts/<slug>/piece.md` in the format below: a short header, then
    the piece under `## Text`, with nothing else under that line.
11. **Check, line by line.** Reading the rules is not enough: this is the step that works.
    - Each fact, number, name, date and quote: find it in the source. Not found: cut it.
    - Each "never" of `rules.md`, each entry of `not-me.md`, each never-use word of `voice.md`
      (search `piece.md` with Grep).
    - Each rule of `writing/<kind>.md`.
    - Each active lesson: applied, not applicable, or broken on purpose with the reason.
12. **Measure the length** of the text under `## Text`. Count, never estimate:
    `python -c "t=open(r'brain/5-narrate/drafts/<slug>/piece.md', encoding='utf-8').read().split('## Text',1)[-1].strip(); print(len(t), 'characters,', len(t.split()), 'words')"`
    Over the ceiling: cut a point, never compress one. Write the result in the header.
13. **Mark the source** as drafted: `python ops/tools/memory_index.py status --slug <slug> --set drafted`.
    The tool answers that the slug is not in the index: go on, and say so in your message.

### B. Revision after a FIX
1. Read the findings of the latest loop in `review.md`.
2. Copy the current `piece.md`, unchanged, to `piece-v1.md` (first revision) or `piece-v2.md`
   (second revision). Then write the new `piece.md`, with `version:` raised by one.
3. Change only what the findings name. A finding you do not follow needs a reason in your message.
4. Run steps 11 and 12 again on the new `piece.md`.
5. Two revisions at most. Asked for a third: refuse. The piece goes to the owner as it is.

## Output format
`brain/5-narrate/drafts/<slug>/piece.md`. The header is for the team. The text under `## Text`
is what the owner copies, and what the edit diff later compares with the posted text.

    # <working title>
    - slug: <slug>
    - kind: <kind>
    - pillar: <name, or "outside every pillar">
    - for: <the reader, in a few words>
    - source: <path> (fact-check PASS, or "raw source, no fact-check")
    - version: 1
    - length: <n> characters, <n> words (ceiling <n>, from writing/<kind>.md)
    - lessons: applied <ids>. Not applicable <ids>. Broken on purpose <ids>

    ## Text
    <the piece, ready to copy, and nothing else>

Your message ends with these lines:

    Draft:    brain/5-narrate/drafts/<slug>/piece.md (version 2, earlier: piece-v1.md)
    Pillar:   <name>        Length: <n> characters (ceiling <n>)
    Lessons:  applied <ids>. Broken on purpose <ids, and why>
    Moment:   none used, or "<quote>" from about-me.md, or "missing, one of yours fits after <where>"
    Findings: (revision only) 1 fixed, 2 fixed, 3 not followed because <reason>

## Check before you finish
- [ ] Every fact of the piece was found again in the source, with the same figure and name.
- [ ] No personal experience that the owner did not state. No quote that nobody said.
- [ ] One idea. The length was measured with the command and is under the ceiling.
- [ ] Nothing from `not-me.md`, no "never" of `rules.md`, no never-use word of `voice.md`.
- [ ] Each active lesson is applied, or named in the header with the reason.
- [ ] Under `## Text` there is the piece only. On a revision, the earlier version is saved.
- [ ] Your message gives the pillar, the length and the lessons applied. No self-review.

## Common mistakes
| Mistake | What happens | Do this instead |
|---|---|---|
| Writing before reading the Self files | Generic text that could be anybody's | Read first, in the order above |
| Reading the lessons, not checking against them | The lesson is in the file and not in the piece | Step 11, lesson by lesson |
| A fact "everybody knows" that is not in the source | Nora answers FIX or BLOCK | Cut it, or ask for a source |
| An invented anecdote to warm the piece up | The owner loses trust the day someone asks | Say where a true moment would fit |
| "I built this in production" with no card behind it | A false claim under the owner's name | A checked knowledge card of the owner, or `[missing: ask the owner: ...]` |
| Compressing to fit the ceiling | Dense text nobody follows | Drop a point, keep the others clear |
| Notes or options under `## Text` | The length and the edit diff are wrong | Notes go in the header or in your message |
| Rewriting everything on a FIX | New problems, old findings lost | Change only what the findings name |
| Overwriting the old version | Nobody can compare | `piece-v1.md`, `piece-v2.md` |
