---
name: summarize-source
description: How Chloe, the Analyst, turns ONE source of brain/2-ears/sources/ into a faithful summary. Every heading is copied from the source, word for word and in the source's order, every figure is copied exactly with its unit, no opinion and no outside fact, then the summary is registered in the memory index. A document of the owner (origin mine, filed from my-knowledge/) becomes a knowledge card instead, with what it teaches, its labs, its figures and its stories, each line with its place in the source. Use it for any request to summarize, digest or break down a source, an article, a report or meeting notes, to digest a folder of the owner's knowledge, and to revise a summary after a FIX of the fact-check. Not to write a piece.
user-invocable: false
---

# Summarize a source, section by section

## When to use
- A source sits in `brain/2-ears/sources/<slug>.md` and a summary is wanted.
- Cato answered FIX: one revision, and only of the lines he quotes.
- Not to give an opinion on the source, not to write a piece from it (`write-draft`), not to
  mix several sources. One source in, one summary out.

The guarantee is trust: the structure comes from the source, not from the summarizer. An
article keeps its headings, a meeting its agenda, a contract its clauses.

## Inputs
- The slug, or the path `brain/2-ears/sources/<slug>.md`: the full text, with its URL and its
  fetch date at the top.
- `brain/1-self/pillars.md`: only to name the pillar.
- For a revision: `brain/3-condense/summaries/<slug>/fact-check.md`.

The source is not there yet (the owner gave a link or a text): stop and say so. Emma files it.

## Steps
1. **Check it is not already done.** Run `python ops/tools/memory_index.py find "<words of the title>"`
   and look for `brain/3-condense/summaries/<slug>/condensed.md`. It exists and nobody asked for a
   redo: answer "already summarized", give the path, stop.
2. **Read the source in full.** Never from its title, from memory or from the web. The file is
   missing or empty: stop, there is nothing to summarize. Its top says the text may be
   incomplete: go on, and say it in the header line `source_state`.
3. **List the headings of the source, in order.** They are your sections, exactly. The top-level
   sections become `##`, their subsections `###`.
   - No heading at all: follow the source's own order and label each block honestly. Set
     `headings: editorial` in the header.
   - Skip what is not content: a table of contents, a "read also" list, comments, a footer.
     Never skip a real section, even a short one.
4. **Write the summary** (format below). Under each heading, short bullets. A paragraph only
   when a list cannot carry the point.
   - Every sentence traces to the source. Nothing you know from elsewhere.
   - Every figure is copied exactly, with its unit and what it measures. No rounding, no
     conversion, no total the source does not give.
   - Names, versions and dates as the source writes them.
   - Plain words, short sentences, neutral tone. No praise, no doubt, no advice, no opening
     line for a piece.
   - A point that is unclear in the source: say "unclear in the source", do not guess.
   - Save the file with the Write tool, not with a shell command: a long text with quotes
     breaks the command and nothing is written.
5. **Write "In one paragraph" last**: three to five sentences that the sections below fully
   support. What the source is, its main point, the method it brings, its key figures.
6. **Check** with the list below.
7. **Register it in the memory:**

       python ops/tools/memory_index.py add --slug <slug> --title "<title>" --source "<URL or path>" --pillar "<pillar>" --summary brain/3-condense/summaries/<slug>/condensed.md
       python ops/tools/memory_index.py status --slug <slug> --set summarized

   The pillar is the name of one pillar of `pillars.md`, or "none". Never a new one.
8. **Revision after a FIX.** Read the findings. Correct only the lines they quote, from the
   source. Run step 6 again. Do not add the index line again: the status stays `summarized`.

### A document of the owner: the knowledge card
The header of the source says `origin: mine`: the owner wrote it. Slides, a notebook, a chapter,
course notes. A deck has sixty slide titles and a notebook has none: a mirror of its headings
helps nobody. The guarantees stay the same (nothing from outside, every figure exact), the shape
changes. The file is still `condensed.md`, in the format "Knowledge card" below.
1. Read the source in full. Pictures and slides with no text are not in it: say so in
   `source_state`, do not guess what they showed.
2. Fill the five fixed sections, in the order of the document. **Every line ends with its place
   in the source, in brackets**: `(slide 12)`, `(cell 8)`, `(under "2.3 Memory")`. Cato goes
   to that place. A line with no place cannot be checked: cut it.
   - What it teaches: the points the document makes, one per line.
   - Examples, labs and code: each exercise, lab or code example: what it does, what it shows.
   - Figures and names: every figure with its unit and what it measures, every tool, model and
     version, as written.
   - Stories and positions: a lived moment or an opinion of the owner, quoted word for word.
   A section with nothing: one line, `- none in this document`. 60 lines at most per card.
3. Register it. The source is the path under `my-knowledge/` that the source file gives in its
   `how:` line. That path is how the memory knows the material is the owner's own:

       python ops/tools/memory_index.py add --slug <slug> --title "<title>" --source "my-knowledge/<path>" --pillar "<pillar>" --summary brain/3-condense/summaries/<slug>/condensed.md
       python ops/tools/memory_index.py status --slug <slug> --set summarized

4. **A folder at once.** Your task lists up to eight slugs: one card per slug, one after the
   other, each registered. A document too poor to card (a few words, a rough PDF): no card, and
   its slug with the reason in your final message.

## Output format
`brain/3-condense/summaries/<slug>/condensed.md`:
(Not `summary.md`: an agent tool may refuse a subagent that writes a file named summary, report,
findings or analysis. The content is a summary, the file name is `condensed.md`.)

    # Summary of <the title of the source, copied exactly>
    - slug: <slug>
    - source: <the URL written in the source file, or its path>
    - source_file: brain/2-ears/sources/<slug>.md
    - source_state: complete | may be incomplete (<why>)
    - published: <the date the source states, or "not stated">
    - summarized: 2026-11-13
    - pillar: <a pillar of pillars.md, or "none">
    - headings: from the source | editorial
    - sections: 5

    ## In one paragraph
    <three to five sentences>

    ## <First heading of the source, word for word>
    - <one point>
    - <a figure, exactly as written, with its unit>
    ### <A subheading of the source, word for word>
    - <one point>

"In one paragraph" is the first heading and the only one that is not the source's. Every
heading after it exists in the source, with the same words, in the same order.

Knowledge card, for a source that says `origin: mine`. Same file name, `condensed.md`:

    # Knowledge card: <the title of the source, copied exactly>
    - slug: <slug>
    - source: my-knowledge/<path>
    - source_file: brain/2-ears/sources/<slug>.md
    - origin: mine
    - kind: slides | notebook | chapter | notes | code | other
    - source_state: complete | may be incomplete (<why>)
    - summarized: 2026-11-16
    - pillar: <a pillar of pillars.md, or "none">
    - headings: knowledge card
    - sections: 5

    ## In one paragraph
    <three to five sentences: what the document is, for whom, what one learns from it>

    ## What it teaches
    - <one point> (slide 4)

    ## Examples, labs and code
    - <what the lab does, what it shows> (cell 12)

    ## Figures and names
    - <a figure, exactly as written, with its unit> (under "Results")

    ## Stories and positions
    - "<the owner's sentence, word for word>" (slide 2)

## Check before you finish
- [ ] The number of `##` sections after "In one paragraph" equals the number of top-level
      sections of the source, and the header line `sections` says it.
- [ ] Three headings, picked at random, are identical to the source character for character.
- [ ] Every figure of the summary was found again in the source, with the same unit. Search it
      with Grep: do not trust your eyes.
- [ ] No sentence gives your view. No fact comes from outside the source.
- [ ] "In one paragraph" says nothing that the sections do not say.
- [ ] The index has one line for this slug, with the status `summarized`.
- [ ] A knowledge card: every line has its place in brackets, the five headings are the fixed
      ones, and the index source starts with `my-knowledge/`.

## Common mistakes
| Mistake | What happens | Do this instead |
|---|---|---|
| A cleaner structure than the source's | It reads well and nobody can trace it | The source's headings, in its order |
| "About 40 %" for "37 %" | Cato answers FIX, or the wrong figure goes out | Copy the figure and its unit |
| A fact you know that the source does not say | The summary says more than the source | Cut it. Only what is written |
| Pros, cons, "what this means for you" | An opinion shapes the summary | Faithful first. Opinions are not your job |
| Summarizing a page that did not load | A summary of a title | Stop, or say `may be incomplete` |
| Dropping a short section | The mirror is broken | Keep the heading, one bullet is enough |
| Rewriting everything on a FIX | New errors, old findings lost | Only the lines the findings quote |
| Sixty `##` headings for sixty slides | A card longer than the deck | The knowledge card: five sections, each line with its slide |
| A card line with no place in brackets | Cato cannot find it, and the owner cannot either | `(slide 12)`, `(cell 8)`, or cut the line |
