---
name: post-debrief
description: How Diane, the Coach, reviews each piece after it went out. One card per piece in 6-debrief/reviews/posts/ with the numbers and the verdict from the scorecard, what the owner changed between the draft and the posted text, what the Editor had flagged, and ONE hypothesis clearly marked as a hypothesis. Use it right after the scorecard, for every piece with no card or with a new reading. Works without numbers, from the owner's edits and the Editor's findings only.
user-invocable: false
---

# Review each piece

## When to use
- Dexter has run the scorecard and the edit diff, and a piece has no card yet.
- A later reading arrived (72 h, 7 days) for a piece that already has a card: update the card.
- Not for the week as a whole (`weekly-review`) and not to write a lesson (`lessons-ledger`).

**Where this sits in the feedback loop.** Seven stages. One agent and its skill at each stage.
This skill is stage 2.

| Stage | Who | Skill | Output |
|---|---|---|---|
| 1. Measure | Dexter | `scorecard` (tools `scorecard.py`, `edit_diff.py`) | numbers at 24 h, 72 h, 7 days against a fixed baseline, and what the owner changed between the draft and the posted text |
| 2. Review each piece | Diane | `post-debrief` | one card per piece: numbers, verdict, the owner's edits, what the Editor had flagged, one hypothesis |
| 3. Propose | Diane (lesson), Serena (pillar), Sacha (writing) | `lessons-ledger`, `pillar-review`, `writing-tune-up` | one proposal file per change |
| 4. Challenge | Diego | `change-challenge` | ACCEPT, NEEDS MORE EVIDENCE or REJECT, per proposal |
| 5. Decide | the human | (queue) | accept, trial for 4 weeks, reject, or reword |
| 6. Apply | the owner of the file: Diane `lessons.md`, Serena `pillars.md`, Sacha `voice.md` and `writing/<kind>.md` | same skills | the file changed, one line in the ledger |
| 7. Verify | Sosie now (Double test must not drop), Dexter and Diane at the review date | `double-test`, `scorecard` | kept, extended or rolled back |

The card is the evidence that stages 3 and 4 read. A weak card gives weak proposals.

## Inputs
- `brain/6-debrief/metrics/scorecards.md` and `scorecards.json`: the numbers, verdict and score.
- `brain/6-debrief/metrics/edits/<slug>.md`: what the owner changed.
- `brain/5-narrate/drafts/<slug>/review.md`: what Nora had flagged, at each loop.
- `brain/5-narrate/drafts/<slug>/piece.md` (its header names the pillar and the lessons the
  writer applied) and the posted text, to quote from.
- `brain/BRAIN.md` (`sample_data`), `brain/1-self/pillars.md`, `brain/6-debrief/lessons.md`.

No `posts.json` in this brain: there are no numbers. Write the card with "Numbers: none in
this brain" and fill in the other sections. The owner's edits and the Editor's findings are
enough to learn from.

## Steps
1. **List the pieces to do.** Each slug of `scorecards.json` or of `metrics/edits/` that has no
   card in `brain/6-debrief/reviews/posts/`, and each card that lacks a reading the scorecard
   now has.
2. **Copy the numbers.** The three readings against the baseline, the verdict (ok, reach
   problem, conversion problem, or pending while the 7 day reading is missing) and the score,
   exactly as the scorecard gives them. Never recompute. A missing reading is "not yet".
3. **Say what the owner changed.** From the edit diff: the share of the draft that was kept,
   then each changed, removed or added line quoted (draft, then posted text) with one class:
   opening, length, structure, word choice, claim softened, example added, closing. No
   change: write "sent as drafted".
4. **Say what the Editor had flagged.** The verdict of each loop, and each finding in one line
   with its level. Then compare with step 3: did the owner correct something Nora had not
   flagged? That is a gap in the written rules, and Sacha needs to see it.
5. **Write ONE hypothesis.** One sentence that links the verdict to a cause you can name in the
   piece. Mark it as a hypothesis. Add what would confirm it and what would contradict it.
   First rule out the cheap explanations: the day, the hour, the format, the subject, luck.
   One piece proves nothing: a hypothesis becomes a lesson only with a second piece.
6. **Leave the signals for the loop.** A lesson candidate, a pillar signal (which pillar, or
   "outside every pillar"), a writing signal (the class of the owner's correction). Write
   "none" when there is none.
7. **Save the card.** One file per piece. On an update, change the numbers, keep the earlier
   hypothesis and say whether the new reading supports it.

## Output format
`brain/6-debrief/reviews/posts/<slug>.md`:

    # Piece review: <title>
    - slug: <slug>
    - date: <date it went out>
    - kind: <kind>
    - pillar: <pillar, or "outside every pillar">
    - verdict: ok | reach problem | conversion problem | pending | no numbers
    - score: <n> / 100
    - numbers: real | sample numbers | none in this brain
    - updated: <date of this card>

    ## Numbers
    | Reading | Result | Against the baseline |
    |---|---|---|
    | 24 h | ... | ... |
    | 72 h | ... | ... |
    | 7 d | ... | ... |

    ## What the owner changed
    Kept <n> % of the words of the draft. Then one line per change:
    - opening: "<draft>" became "<posted text>"

    ## What the Editor had flagged
    Loop 1: FIX, 2 findings. Loop 2: PASS.
    - major: <the finding, in one line>
    Not flagged by the Editor, corrected by the owner: <what, or "nothing">

    ## Hypothesis (not a fact)
    <one sentence>. Confirmed if: <...>. Contradicted if: <...>.

    ## For the loop
    - lesson candidate: <a rule one could apply, or "none">
    - pillar signal: <...>
    - writing signal: <...>

## Check before you finish
- [ ] Every number of the card is in the scorecard, digit for digit.
- [ ] Each change of the owner is quoted from the two texts and has one of the seven classes.
- [ ] The card has exactly one hypothesis, and the word "hypothesis" is in its heading.
- [ ] "sample numbers" is written when `sample_data` is yes.
- [ ] One card per piece, in `reviews/posts/`. Nothing else was written.

## Common mistakes
| Mistake | What happens | Do this instead |
|---|---|---|
| "It worked because of the opening" | A guess becomes a fact, then a rule | One hypothesis, marked, with its test |
| Three hypotheses | Nothing can be tested next week | One |
| Skipping the owner's edits | The loop ignores the best signal it has | Quote every change |
| Recomputing a rate | Two figures for the same piece | Copy the scorecard |
| Judging the piece on taste | You become a second Editor | Numbers, edits, findings. The taste is the owner's |
| A lesson written in the card as decided | It skips Diego and the owner | "lesson candidate", nothing more |
