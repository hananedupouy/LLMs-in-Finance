---
name: build-ears
description: Build Step E, Ears (what comes in), of your own brain. Launch it with /build-ears. It files your own knowledge first, the courses, slides, book and notes you dropped in my-knowledge/, with a small script and your yes, then asks for the few outside sources you trust and one thing to capture now, calls Emma, and ends on the "Done when" checklist of the step, ticked honestly. Use it after /build-self. It opens the Front Desk (capture by hand) and, as an option, a daily radar on up to three sources (an arXiv search, a blog feed) with Carl, the Gatekeeper, who scores what the radar brings and keeps 20 at most.
user-invocable: true
---

# Build Step E: Ears

## When to use
- Your Self exists (`/build-self`) and you want things to reach your brain.
- You have material of your own (courses, slides, a book, notebooks, notes) the brain should know.
- You want to test that a capture takes two seconds and asks nothing.
- You want the brain to look in a few sources by itself every morning (the radar option).
- Not to summarize what came in (`/build-condense`). Not to watch people or accounts.

A brain with no ears knows only what you type. A brain with too many drowns. This step lets in
two things, in this order: what the reader already knows, then a short list of outside sources.

You are the session the reader talks to. You check, you ask, you run the library tool, you call
Emma, you tick the list.

## Two folders, two jobs
| Folder | What the reader puts there | Who reads it | When |
|---|---|---|---|
| `my-documents/` | who they are and how they write: a CV, a bio, a few pieces | Sofia, Sacha, Serena | Step S, never here |
| `my-knowledge/` | what they know: courses, slides, a book, notebooks, notes, talks | `ops/tools/library.py`, then Chloe and Cato | this step files it, Step C digests it |

The reader's own folders are never "sources to read by hand". They are filed.

## Inputs
- `brain/BRAIN.md` and `brain/1-self/pillars.md`: the outside sources are chosen per pillar.
- `my-knowledge/` at the root of the folder, and the tool `ops/tools/library.py`: a small script,
  no AI inside. It reads, counts, converts to text and files. It never judges and never sends.
- `brain/1-self/rules.md`, section "Private words": the names the tool looks for.
- `brains/_template/2-ears/`, if the kit has it.
- The agent of the step: `.claude/agents/emma.md`. Her skill: `.claude/skills/capture/SKILL.md`.
- For the radar option: the skill `.claude/skills/radar/SKILL.md` and the tool `ops/tools/radar.py`.
  For its filter: `.claude/agents/carl.md`, the skill `.claude/skills/gatekeeper/SKILL.md`, and Serena for the rubric.

## Steps
1. **Check the brain.** No `brain/BRAIN.md`, or not the reader's: stop, `/build-self` comes
   first. No `pillars.md`: go on, and ask for the sources without the pillars.
2. **Check the kit.** `emma.md` and the skill `capture` exist. One is missing: name it and stop.
   `ops/tools/library.py` is missing: say so, skip step 5, leave its line of the checklist empty.
3. **Show what exists.** Count the cards of `brain/2-ears/inbox/` and list those that still
   say `status: new` and are older than 7 days. Count the files of `brain/2-ears/sources/`.
   Run `python ops/tools/library.py status`: what is filed, what waits.
4. **Create what is missing.** Copy what `brains/_template/2-ears/` holds and the brain lacks.
   Never overwrite. The folders appear when Emma writes her first card.
5. **The reader's own knowledge, first.** Five moves. The screen shows the tool running and
   finished (page E, card "Your knowledge").
   1. `my-knowledge/` is empty: say "Put what you know in `my-knowledge/`: courses, slides, a
      book, notebooks, notes, in any folders. Tell me when it is there, or say later." Later: go
      to step 6, and leave the line of the checklist empty with "nothing in my-knowledge/".
   2. **Scan.** `python ops/tools/library.py scan`. It files nothing. Show the table of
      `brain/2-ears/library.md`: one line per folder (files, readable, duplicates, private
      words, words), then what is not readable and what to do about it ("save it as .pptx").
   3. **One question, in the queue, answered once.**
      `python .claude/skills/run-trace/scripts/queue.py add --from alfred --ask "Which folders of my-knowledge do I file?" --file brain/2-ears/library.md --choices "all|all except the folders I name|none for now"`
      The reader answers in their words ("all, except the old folders"). A folder shows private
      words: ask in the same message what to do with them: keep them, mask them (`[private]` in
      their place), or leave those documents out. Never choose for the reader.
   4. **File**, exactly as the reader said. Examples:
      `python ops/tools/library.py file --all --except old --private mask`
      `python ops/tools/library.py file "Training/Module-1" Book`
      `python ops/tools/library.py leave-out "Training/old"` for a folder the reader refuses.
      One text file per document goes to `brain/2-ears/sources/`, marked `origin: mine`. The
      originals do not move. A second run files nothing twice.
      Put the folders before `--except`. Name a folder only when the reader named it: naming it
      decides again for that folder and takes back what was left out there. `--all` keeps the
      earlier choices: a folder left out stays out. `leave-out` needs a scan first.
      The tool answers "WAITS for your choice" for a folder: its documents hold private words
      and no choice was given. Ask the reader, then file that folder again with `--private`.
   5. **Emma, one run:** "one card per folder filed, from brain/2-ears/library.md", each with
      `type: document`, `from: my-knowledge/<folder>`, `route: chloe`. Then **Serena, one run:**
      "check the pillars against the library". She answers "the pillars match", or leaves one
      move in the queue. Then say the figures: filed, left out, not readable.
   Say it plainly: filed is not known. A filed document becomes memory at Step C, one folder at
   a time.
6. **Ask about the outside, in one message:**
   - "Outside your own material: which two or three sources per pillar do you already trust?
     One line each: what it is, why you trust it. Ten at most."
   - "Did you open each one today, and does it still publish?"
   - "Give me one thing to capture right now: a link, an idea, a note."
   - "An article or a paper to keep in full? Give its link."
   - "Do you want a daily radar too? Up to three sources with a feed (an arXiv search, a blog
     with RSS) that the brain reads every morning and lists for you. Which ones? Carl, the
     Gatekeeper, then keeps 20 at most, scored against a rubric drawn from your pillars."
7. **Call Emma, once per thing.** One card per capture.
   1. The list of outside sources, as given: one card, `type: source list`. The reader reads
      these by hand and captures what matters. Those with a feed can go on the radar (step 8).
      A line of the list that is a folder or a file of the reader: take it out of the list and
      tell the reader to put it in `my-knowledge/`.
   2. The thing to capture, exactly as the reader typed it. Note whether Emma asked anything:
      she must not.
   3. The link to keep in full: "fetch <link>". Emma files the full text with the library tool.
8. **The radar, only if the reader wants it.** Follow the skill `radar`, parts B and C.
   1. Copy `brains/_template/2-ears/radar.json` to `brain/2-ears/radar.json` if it is missing,
      and write the reader's sources in it: three at most, the reader's words in `name`.
   2. `python ops/tools/radar.py --check`, then `python ops/tools/radar.py`. Show the page of the
      day. Run it a second time: it must say "0 new". That is the proof for the checklist.
   3. `python ops/tools/radar.py --print-schedule`, and give the lines to the reader. The reader
      registers the schedule. You never create a scheduled task.
   The reader says no: write nothing, and leave the four radar lines of the checklist empty.
9. **The Gatekeeper, with the radar only.** Follow the skill `gatekeeper`.
   1. No `brain/1-self/rubric.md` with `status: approved`: call Serena to draft it (part A).
      Show it, with its last block "How Carl scores". The reader answers "approve" or
      "change: ...". Never approve it for them.
   2. Call Carl on today's radar. Show his shortlist: kept out of read, the top 3, the skipped list.
   3. Ask: "One kept item that should not be there, or one skipped item that should have passed?"
      One or more: Serena proposes the smallest change to the rubric, the reader approves it,
      and Carl scores the day again at once.
10. **Show the door.** The reader types one capture alone: `/capture` followed by anything.
    Show the card it made, and its suggested route.
11. **Finish on the checklist.** Tick only what you verified, with the evidence.

## Output format
Your last message to the reader:

    Step E, Ears
    Created:  <the folders and files created, or "nothing, all was there">
    Filed:    <n> documents of yours from <f> folders, <k> left out by you, <x> not readable
    Captured: <the paths of the cards, and of the source filed>

    Done when
    [x] Your own material is filed, and you chose what went in
        proof: brain/2-ears/library.md, 84 documents from 9 folders, 2 folders left out by you,
        6 files not readable (listed there, with what to do)
    [x] 10 outside sources or fewer, each one checked for real
        proof: 7 sources in brain/2-ears/inbox/<date>-my-sources.md, opened by you today
    [x] A second run on the same day brings nothing new
        proof: radar run twice at 07:11, the second said "0 new item(s)"
        (no radar chosen: leave it empty, "no radar chosen")
    [x] Your rubric fits on one screen and you wrote it in your words
        proof: brain/1-self/rubric.md, 16 lines, status: approved by you on <date>
    [x] A normal morning leaves 20 items or fewer in front of you
        proof: brain/2-ears/shortlist/<date>.md, 9 kept out of 64
    [x] /capture takes two seconds and asks nothing
        proof: 2 captures, 0 questions
    [ ] You know at 07:05 whether the morning run happened
        not yet: the schedule is printed, the reader registers it, then brain/2-ears/radar/<date>.md
        exists every morning with its run time. Tick it the first morning it does
    [x] An inbox card never stays without a route for more than 7 days
        proof: 4 cards, all with a route, the oldest is 2 days old

    Next: /build-condense. It digests your filed folders, one at a time

The list is the "Done when" of Step E, with one line more for the reader's own material. Four
of its lines need the radar, and two of those need Carl and an approved rubric. Without them,
they stay empty, with the reason. The radar lists, Carl judges: nothing reaches Condense that
the reader did not pick from his shortlist, bring by hand or file from `my-knowledge/`.

Later, any day: the reader drops new files in `my-knowledge/` and says "file my new documents".
You scan, show what is new, ask the one question, file with `--all`: the earlier choices stay,
only what is new or changed is filed.

## Check before you finish
- [ ] Every card was written by Emma, not by you.
- [ ] Nothing of `my-knowledge/` was filed before the reader answered the question in the queue.
- [ ] No document with private words was filed without the reader's choice: keep, mask or leave out.
- [ ] No folder or file of the reader sits in the list of outside sources.
- [ ] The source list holds ten lines at most, and the reader said they opened each one.
- [ ] Emma asked no question during a capture. If she did, say so: the line stays empty.
- [ ] Nothing was fetched from the network without the reader's word. Choosing the radar is that word,
      for the radar's sources only.
- [ ] No scheduled task was created by you. The reader has the lines to paste.
- [ ] A radar line is ticked only with its proof: two runs, and the page of the day.
- [ ] The rubric was approved by the reader, not by you. The shortlist lists every item, kept or skipped.

## Common mistakes
| Mistake | What happens | Do this instead |
|---|---|---|
| The reader's own folders written as "sources I read by hand" | The most valuable material never enters the brain | Scan, the reader's yes, file |
| Ticking "each source checked" for folders nobody opened | A box ticked with no proof | The library line has its own proof: `library.md` |
| Filing a folder with a client name inside, without asking | A private name in every later draft | Keep, mask or leave out: the reader chooses |
| Calling a filed document "known" | The plan and the drafts find nothing | Filed, then digested at Step C |
| A hundred outside sources on day one | Noise, and nobody reads them | Ten, then one more when something is missed |
| A capture that asks five questions | The reader stops capturing | Store first, think later |
| Several doors (notes, mail, bookmarks) | Ideas get lost between them | One door: `/capture` |
| Ticking the radar lines "in spirit" | The reader thinks a morning run exists | Tick only with the proof: two runs, a page of the day |
| Ten sources on the radar | A page nobody reads | Three, the ones the reader trusts most |
| Approving the rubric for the reader | Carl applies your taste, not theirs | The reader edits and approves it |
| Writing the card yourself | Two writers in one folder | Call Emma |
| Fetching the reader's links to be helpful | A page refuses, or needs a login | Only on "fetch" |
