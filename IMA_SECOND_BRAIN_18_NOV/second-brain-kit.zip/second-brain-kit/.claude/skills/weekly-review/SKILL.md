---
name: weekly-review
description: How Diane, the Coach, writes the weekly review in 6-debrief/reviews/. Read the cards of the week, say what to keep, stop and try, check whether each active lesson was applied and whether it helped, list the triggers seen for the pillars and the writing rules, and list the changes whose review date has come with the result kept, extended or rolled back. Use it once a week after the piece cards are written.
user-invocable: false
---

# Weekly review

## When to use
- Once a week, after `post-debrief` wrote the cards of the pieces that went out.
- When the owner asks "how did my week go" or "what should I change".
- Not to add a lesson to `lessons.md`: the review names candidates, `lessons-ledger` proposes.

**Where this sits in the feedback loop.** Seven stages. One agent and its skill at each stage.
The review closes stage 2, feeds stage 3, and carries stage 7 at each review date.

| Stage | Who | Skill | Output |
|---|---|---|---|
| 1. Measure | Dexter | `scorecard` (tools `scorecard.py`, `edit_diff.py`) | numbers at 24 h, 72 h, 7 days against a fixed baseline, and what the owner changed between the draft and the posted text |
| 2. Review each piece | Diane | `post-debrief` | one card per piece: numbers, verdict, the owner's edits, what the Editor had flagged, one hypothesis |
| 3. Propose | Diane (lesson), Serena (pillar), Sacha (writing) | `lessons-ledger`, `pillar-review`, `writing-tune-up` | one proposal file per change |
| 4. Challenge | Diego | `change-challenge` | ACCEPT, NEEDS MORE EVIDENCE or REJECT, per proposal |
| 5. Decide | the human | (queue) | accept, trial for 4 weeks, reject, or reword |
| 6. Apply | the owner of the file: Diane `lessons.md`, Serena `pillars.md`, Sacha `voice.md` and `writing/<kind>.md` | same skills | the file changed, one line in the ledger |
| 7. Verify | Sosie now (Double test must not drop), Dexter and Diane at the review date | `double-test`, `scorecard` | kept, extended or rolled back |

Three levers: **lessons** (weekly, at most 10, each with evidence from 2 pieces), **pillars**
(monthly, one move at a time), **writing rules** (monthly, the smallest edit, with a before and
after example). Triggers that open a proposal:

- Pillar: 4 pieces in a row under the baseline, or above it. 2 pieces outside every pillar above
  the baseline. No piece on a pillar for 4 weeks.
- Writing: the same correction by the owner in 3 of the last 8 pieces. The same FIX from the
  Editor 3 times in a month. A lesson confirmed for 4 weeks is promoted into the writing rules.
- Any time: the owner says "it's not me". That goes straight to the rules, no numbers needed.

## Inputs
- The cards in `brain/6-debrief/reviews/posts/` of the pieces that went out since the last review.
- `brain/6-debrief/metrics/scorecards.md`: the table per pillar and the triggers found.
- `brain/6-debrief/lessons.md` and the last `brain/6-debrief/reviews/<date>-weekly.md`.
- `brain/6-debrief/changes/ledger.md`: the changes applied and their review dates.
- `brain/1-self/rules.md` and `not-me.md`: nothing in the review may ask to break them.

## Steps
1. **Set the period.** From the day after the last weekly review to today. No piece went out:
   write a short review that says so, and still do steps 5 and 6.
2. **Build the table of the week** from the cards: piece, pillar, verdict, score, how much the
   owner changed, the Editor's verdict. Copy, do not recompute.
3. **Check the lessons, one by one.** For each lesson that is not retired: was it applied in
   each piece of the week, and did the pieces that applied it do better than those that did
   not? "The rule stopped working" and "the rule was not applied" are two different findings.
4. **Write keep, stop, try.** One to three lines each, the fewer the better. Each line names
   the pieces it rests on. "Try" is one experiment for next week, with how it will be judged.
   A line that rests on one piece says so.
5. **List the triggers seen.** Copy the triggers of the scorecard. Add the ones you see in the
   cards (the same class of correction by the owner, the same FIX by the Editor). For each:
   the count, the pieces, and who should propose: Serena for a pillar, Sacha for a writing
   rule. A lesson confirmed for 4 weeks goes to Sacha. You do not propose in their place.
6. **Review the changes that are due.** In the ledger, each applied change whose review date is
   today or earlier. Compare the pieces before and after it (Dexter's numbers, the edit diffs).
   Write what you see and your recommendation: kept, extended or rolled back. Then one queue
   line per change, because the owner decides:
   `python .claude/skills/run-trace/scripts/queue.py add --from diane --ask "Change <id> is due for review: <what the numbers say>" --file brain/6-debrief/reviews/<date>-weekly.md --choices "keep|extend 4 weeks|roll back"`
7. **Name the lesson candidates.** A pattern seen in at least 2 pieces. Hand them to
   `lessons-ledger`. Save the review.

## Output format
`brain/6-debrief/reviews/<date>-weekly.md`, with `<date>` as YYYY-MM-DD:

    # Weekly review: <date>
    - period: <from> to <to>
    - pieces reviewed: <n>
    - numbers: real | sample numbers | none in this brain

    ## The week
    | Piece | Pillar | Verdict | Score | Owner changed | Editor |
    |---|---|---|---|---|---|

    ## Lessons: applied, and did it help
    | Lesson | Applied in | Not applied in | What the numbers say |
    |---|---|---|---|

    ## Keep
    ## Stop
    ## Try

    ## Triggers seen
    | Trigger | Count | Pieces | Who proposes |
    |---|---|---|---|

    ## Changes due for review
    | Change | Applied on | Before | After | Recommendation |
    |---|---|---|---|---|

    ## Lesson candidates
    - <a rule one could apply>: <slug>, <slug>

## Check before you finish
- [ ] Every line of keep, stop and try names its pieces.
- [ ] Each active lesson has its row: applied or not, helped or not.
- [ ] Each trigger has a count you can show, and a named proposer.
- [ ] Each change that is due has a recommendation and its queue line.
- [ ] Nothing in the review asks to break `rules.md` or `not-me.md`.
- [ ] `lessons.md`, `pillars.md` and the writing rules are untouched.

## Common mistakes
| Mistake | What happens | Do this instead |
|---|---|---|
| Ten recommendations | None is applied | Three lines at most per heading |
| "Engagement was good this week" | Nobody can act on it | A piece, a number, a rule to apply |
| Blaming a rule that was not applied | A good rule gets retired | Check "applied" before "helped" |
| A trigger named without its count | Diego sends it back | The count and the pieces |
| Deciding a roll-back yourself | The brain changes the Self alone | Recommend, then the queue |
| Comparing this week with last week | The yardstick moves | The fixed baseline |
