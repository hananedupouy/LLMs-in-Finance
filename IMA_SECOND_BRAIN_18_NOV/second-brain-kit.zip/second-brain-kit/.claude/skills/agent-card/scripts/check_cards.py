#!/usr/bin/env python3
"""Check the card of every agent: the comment "<!-- card ... -->" under the front matter.

  python .claude/skills/agent-card/scripts/check_cards.py [--project .] [NAME ...]

One line per agent: "ok", or what is missing or wrong. Exit code 1 when a card has a problem.
The card is the only source of what Mission Control shows about an agent.
Standard library only.
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

REQUIRED = ["first_name", "title", "step", "kind", "tagline", "reads", "writes", "checked_by", "runs"]
KINDS = {"worker", "reviewer", "governance"}


def find_project(given: str | None) -> Path:
    if given:
        return Path(given).resolve()
    here = Path(__file__).resolve()
    if len(here.parents) > 4 and here.parents[3].name == ".claude":
        return here.parents[4]
    return Path.cwd().resolve()


def read_card(text: str) -> dict | None:
    found = re.search(r"<!--\s*card\s*\n(.*?)-->", text, re.S)
    if not found:
        return None
    card = {}
    for line in found.group(1).splitlines():
        if ":" in line:
            key, value = line.split(":", 1)
            card[key.strip().lower()] = value.strip()
    return card


def names_in(value: str) -> list[str]:
    return [n for n in re.split(r"[,\s]+", value.lower()) if n and n not in ("and", "the")]


def main() -> int:
    parser = argparse.ArgumentParser(description="Check the card of every agent in .claude/agents/.")
    parser.add_argument("--project", help="the project folder (default: the one this skill is installed in)")
    parser.add_argument("names", nargs="*", help="check only these agents")
    args = parser.parse_args()
    project = find_project(args.project)
    folder = project / ".claude" / "agents"
    if not folder.is_dir():
        print(f"No agents here: {folder} is missing.")
        return 1
    letters = set()
    try:
        method = json.loads((project / "ops" / "method.json").read_text(encoding="utf-8-sig"))
        letters = {str(s.get("letter", "")).upper() for s in method.get("steps", [])}
        if isinstance(method.get("governance"), dict):
            letters.add(str(method["governance"].get("letter", "G")).upper())
    except (OSError, ValueError):
        pass
    files = sorted(folder.glob("*.md"))
    known = {p.stem.lower() for p in files}
    bad = 0
    for path in files:
        if args.names and path.stem not in args.names:
            continue
        text = path.read_text(encoding="utf-8-sig", errors="replace")
        problems = []
        front = re.match(r"^---\r?\n(.*?)\r?\n---", text, re.S)
        if not front:
            problems.append("no front matter (--- name, description ---)")
        else:
            name = re.search(r"^name:\s*(.+)$", front.group(1), re.M)
            if not name:
                problems.append("front matter has no name")
            elif name.group(1).strip().strip("\"'") != path.stem:
                problems.append(f"name is {name.group(1).strip()!r}, the file is {path.name}")
            if not re.search(r"^description:\s*\S", front.group(1), re.M):
                problems.append("front matter has no description")
        card = read_card(text)
        if card is None:
            problems.append("no card: add the comment <!-- card ... --> right under the front matter")
        else:
            for key in REQUIRED:
                if not card.get(key):
                    problems.append(f"card has no {key}")
            kind = card.get("kind", "").lower()
            if kind and kind not in KINDS:
                problems.append(f"kind is {kind!r}: use worker, reviewer or governance")
            step = card.get("step", "").upper()
            if step and letters and step not in letters:
                problems.append(f"step is {step!r}: ops/method.json knows {', '.join(sorted(letters))}")
            if kind == "reviewer" and not card.get("reviews"):
                problems.append("a reviewer needs the line reviews: <who it checks>")
            for key in ("checked_by", "reviews"):
                for other in names_in(card.get(key, "")):
                    if other not in known and other not in ("you", "nobody", "human", "owner", "none"):
                        problems.append(f"{key} names {other!r}: no such agent file")
            if kind == "reviewer" and path.stem.lower() in names_in(card.get("reviews", "")):
                problems.append("a reviewer cannot review itself")
            if len(card.get("tagline", "")) > 90:
                problems.append("tagline is longer than 90 characters: it is cut on the screen")
        if problems:
            bad += 1
            print(f"{path.stem}: " + "; ".join(problems))
        else:
            print(f"{path.stem}: ok ({card.get('first_name')}, {card.get('title')}, step {card.get('step')}, {card.get('kind')})")
    print(f"{len(files) - bad} of {len(files)} cards are complete." if not args.names else "done.")
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
