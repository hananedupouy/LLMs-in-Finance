---
name: agent-card
description: Write, repair or check the card of an agent, the small comment under the front matter of .claude/agents/NAME.md that says its first name, its title, its step, what it reads, what it writes and who checks it. The card is the only source of what Mission Control shows about an agent. Use it when a new agent is created, when an agent appears with no name or in the wrong place on the screen, or to check every card of a project. Launch it yourself with /agent-card. Works in any project that has .claude/agents/.
---

# The card of an agent

## When to use
- A new agent file was written and it has no card.
- The screen shows an agent with a wrong title, in the wrong step, or under "Other agents".
- Before a demo: check every card in one command.
- Not to write the instructions of the agent (its job, its steps). Only the card.

## What a card is
An HTML comment placed right after the front matter. One `key: value` per line. Claude Code
ignores it. Mission Control reads it. A person understands the agent from it in ten seconds.

    ---
    name: chloe
    description: Chloe, the Analyst. Turns ONE source into a faithful summary ...
    tools: Read, Glob, Grep, Write, Edit, Bash
    model: sonnet
    ---
    <!-- card
    first_name: Chloe
    title: The Analyst
    step: C
    kind: worker
    tagline: one source in, one faithful summary out
    reads: brain/2-ears/sources/, brain/1-self/
    writes: brain/3-condense/summaries/
    checked_by: cato
    runs: on demand, in the Production Line
    -->

| Key | What to write | Rule |
|---|---|---|
| `first_name` | the name people say | one word. In the SECOND method it starts with the letter of the step |
| `title` | a job title everyone understands | "The Analyst", "The Editor". No jargon |
| `step` | the letter of the step it works on | a letter of `ops/method.json`, or `G` for governance |
| `kind` | `worker`, `reviewer` or `governance` | a reviewer writes only its review file |
| `tagline` | the one job, in one line | under 90 characters, no "and" that hides a second job |
| `reads` | folders or files it reads | paths from the project root, comma separated |
| `writes` | the folder or files it alone writes | one agent, one folder. Two writers: the design is wrong |
| `checked_by` | the file name of its reviewer, or `you` | never itself |
| `runs` | when it runs | "on demand", "weekly", the routine it belongs to |
| `reviews` | reviewers only: who it checks | file names of agents, comma separated |

## Steps
1. **Check what exists:**

       python .claude/skills/agent-card/scripts/check_cards.py            every agent
       python .claude/skills/agent-card/scripts/check_cards.py chloe      one agent

   It prints one line per agent: `ok`, or what is missing or wrong.
2. **Read the agent file in full** before you write its card. The card says what the file says.
   The job comes from its section "Your job", the paths from "What you write" and "Before you
   start", the reviewer from "Who checks you".
3. **Write the card** right under the closing `---` of the front matter, before the first
   heading. Keep the ten keys in the order above.
4. **Two agents write the same folder?** Do not hide it in the cards. Say it to the owner: one
   of the two files must change.
5. **Run the check again**, then look at the agent on the screen (`#/agent/<name>`).

## Check before you finish
- [ ] `check_cards.py` prints `ok` for the agent, and the last line counts every card as complete.
- [ ] `name` in the front matter is the file name without `.md`.
- [ ] The tagline names ONE job.
- [ ] `writes` is a place no other card writes.
- [ ] A reviewer has `reviews`, and does not review itself.
- [ ] You changed nothing below the card.

## Common mistakes
| Mistake | What happens | Do this instead |
|---|---|---|
| The card above the front matter | Claude Code no longer reads the front matter | The card goes right under the closing `---` |
| A title that needs explaining | The audience does not know what the agent does | A job title from real life |
| `step: Self` | The agent lands in "Other agents" | The letter: `S` |
| `checked_by: Cato the Fact-Checker` | The link on the screen is broken | The file name: `cato` |
| Copying the description into the tagline | It is cut on the screen | One line, under 90 characters |
| Writing the card from memory | The card and the file disagree | Read the file first |
