---
name: build-narrate
description: Build Step N, Narrate (say it in my voice), of your own brain. Launch it with /build-narrate. It checks that the Self and one checked source exist, creates what is missing, asks for a 3-line brief, calls Naomi then Nora on a first piece, stops at the gate where you read the text, records what really went out on your word, and ends on the "Done when" checklist of the step, ticked honestly. Use it after the Self and Condense steps. It never sends anything.
user-invocable: true
---

# Build Step N: Narrate

## When to use
- Your Self is approved and the memory holds at least one checked summary: you want a first
  piece, written by the team, in your voice.
- You already wrote pieces with the team and want to close the step: the records of what
  went out, then the checklist.
- Not for one more draft in a brain that is built (say "write a piece from [source]" to
  Alfred). Not to change a writing rule (say "it's not me").

The rule of the step never bends: the brain writes a first version. You finish it and you
send it yourself. Starting the method here, with no Self and no source, gives generic text.

You are the session the reader talks to. You check, you ask, you call the agents, you tick.
You write no draft and no review yourself.

## Inputs
- `brain/BRAIN.md` (`piece_kinds`), `brain/1-self/voice.md`, `rules.md`, `not-me.md`,
  `pillars.md`, `writing/<kind>.md`.
- A checked source: `brain/3-condense/summaries/<slug>/condensed.md` with `fact-check.md` at
  PASS. Or a raw source of the reader (a note, a transcript).
- `brain/6-debrief/lessons.md`, `brain/5-narrate/drafts/` and `posted/`, if they exist.
- `brains/_template/5-narrate/`, if it is there.
- The agents: `.claude/agents/naomi.md`, `nora.md`, and `sacha.md` when writing rules are
  missing. Their skills: `write-draft`, `edit-review`, `review-verdict`, `run-trace`.

## Steps
1. **Check the brain.** No `brain/BRAIN.md`, or no approved `voice.md`: stop, `/build-self`
   first. No checked summary and no raw source: `/build-condense` first.
2. **Check the kit.** `naomi.md` and `nora.md` exist. One is missing: name it and stop. A
   draft with no independent review is not this step.
3. **Show what exists.** The writing rules of each kind of `piece_kinds`. The summaries with
   the index status `checked`. The drafts, each with the verdict of its review. The records
   in `posted/`.
4. **Create what is missing.** The folders `brain/5-narrate/drafts/` and `posted/`: copy what
   `brains/_template/5-narrate/` holds and the brain lacks, never overwrite. A missing
   `writing/<kind>.md` is Sacha's file: call him, with two or three pieces of this kind that
   the reader wrote and likes. The reader says yes in the queue before Naomi uses it.
5. **Ask, in one message:**
   - "Which kind of piece first?" Only when `piece_kinds` lists more than one.
   - "Your brief, in three lines." No more: a long brief gives a specification sheet.

         Subject:  the single point the piece makes
         Source:   the path of the checked summary, or of the source itself
         Intent:   for whom it is, and what they should keep or do

   - "A note for the writer?" Optional. It becomes the priority instruction.
6. **Call the agents, in this order.** One at a time. A failed step or a BLOCK stops the
   chain: say it, never skip it.
   1. Naomi, with the brief. She writes `brain/5-narrate/drafts/<slug>/piece.md`.
   2. Nora, with the path of the draft. She writes `review.md`. On FIX: Naomi revises once,
      Nora reviews again. Two loops at most.
   3. The gate. Nora added "Read the draft" to the queue. Show the reader the text, the
      verdict and the open findings. They choose: edit, send back with a note, or drop.
      `python .claude/skills/run-trace/scripts/queue.py resolve <id> --decision "<their words>"`
7. **Let the reader finish it.** They edit the text and send it with their own hands. No
   agent can, and you do not offer to.
8. **Record what went out, on the reader's word only.** They say "published": the final text
   goes in `brain/5-narrate/posted/<date>-<slug>.md`, under a line `## Text`. It is the
   reader's file: they save it, or they dictate it and you type it word for word. Never the
   draft, never guessed. Then `python ops/tools/memory_index.py status --slug <slug> --set used`.
9. **Catch the corrections.** `python ops/tools/edit_diff.py --slug <slug>` shows what the
   reader changed. A change looks like a preference: ask "Is this a rule?" On yes, call
   Sacha with their exact words. "It's not me" goes straight to the rules.
10. **Finish on the checklist.** Tick only what you verified, with the evidence.

## Output format
Your last message, after the paths written:

    STEP N, NARRATE: done when
    [x] A draft reaches you with a review that says PASS
        (brain/5-narrate/drafts/<slug>/review.md: PASS at loop 2)
    [ ] You change less than a fifth of the text on average     (kept: 74 %, on 1 piece)
    [x] No piece left the brain without your hand on it         (1 record, on your word)
    [ ] Every published piece has a record with the text as it went out   (found: 1 of 2)
    [ ] A correction you made twice has become a rule           (none yet)
    Not built: <what, and which agent file was missing>
    Next: /build-debrief

The list is the "Done when" of Step N. "Less than a fifth" is read in
`brain/6-debrief/metrics/edits.json`: `average_kept` is 0.8 or more, on three pieces at least.
A correction became a rule when `writing/<kind>.md`, `voice.md` or `rules.md` holds its dated line.

## Check before you finish
- [ ] The draft was written by Naomi and reviewed by Nora. Never by its writer, never by you.
- [ ] Nothing was published, sent or marked as sent by an agent.
- [ ] A record in `posted/` exists only when the reader said "published" and gave the text.
- [ ] Each tick has a path or a count behind it. An item you could not verify stays empty.
- [ ] Nothing waits in the queue without the reader knowing it.

## Common mistakes
| Mistake | What happens | Do this instead |
|---|---|---|
| Starting the method here | Generic text. "It sounds like AI" | Self and Condense first |
| A long, detailed brief | A specification sheet | Three lines |
| Writing the draft yourself to go faster | Nobody reviews it with fresh eyes | Naomi writes, Nora reviews |
| Letting the reviewer fix the text | Two authors, zero review | Verdict and findings only |
| Recording the draft as "published" | The history is wrong, and the lessons too | The text that went out, on the reader's word |
| Ticking every box after one piece | The reader trusts a step that is not built | Count, quote, or leave it empty |
