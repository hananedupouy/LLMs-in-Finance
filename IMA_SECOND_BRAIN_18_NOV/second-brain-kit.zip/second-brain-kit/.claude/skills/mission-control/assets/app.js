﻿/* Mission Control: the page. It shows what /api/state returns, and nothing else.
   Routes: #/  #/team  #/agent/<name>  #/step/<letter>  #/memory  #/loop  #/routines  #/runs  #/skills  #/file/<path>
   How to add or restyle a page: the skill mission-control-design. */
'use strict';

const S = { data: null, raw: '', file: null, filePath: '', filters: { agent: '', status: '' },
  previews: {}, loading: {}, expanded: {}, drafts: {}, recorded: {}, folds: {}, dirty: false, hold: 0 };
const $ = (sel) => document.querySelector(sel);
const esc = (t) => String(t ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const STEPS_FALLBACK = { name: 'Team', color: '#6B635C' };

/* ---------------------------------------------------------------- helpers */

function route() {
  const h = decodeURIComponent(location.hash.replace(/^#\/?/, ''));
  const [page, ...rest] = h.split('/');
  return { page: page || 'home', arg: rest.join('/') };
}
const agentOf = (name) => (S.data.agents || []).find((a) => a.name === String(name || '').toLowerCase());
const statusOf = (name) => (S.data.status || {})[String(name || '').toLowerCase()] || { state: 'idle', runs: 0 };
const steps = () => (S.data.method && S.data.method.steps) || [];
const stepOf = (letter) => steps().find((s) => s.letter === letter) || (S.data.method && S.data.method.governance && S.data.method.governance.letter === letter ? S.data.method.governance : null);
const num = (n) => (n === null || n === undefined || n === '' ? '' : Number(n).toLocaleString('en-US'));
const pct = (x, d = 0) => (x === null || x === undefined ? '' : (x * 100).toFixed(d) + ' %');
/* A tool is a script with no AI that writes its own run lines ("source": "tool"): the radar, the library. */
const isTool = (name) => !agentOf(name) && !!statusOf(name).tool;
const toolName = (name) => String(name || '').charAt(0).toUpperCase() + String(name || '').slice(1);
const TOOL_PAGE = { radar: '#/step/E', library: '#/step/E' };
const whoHref = (name) => (agentOf(name) ? '#/agent/' + esc(name) : TOOL_PAGE[name] || '#/runs');
const lead = () => (S.data.journey && S.data.journey.boss) || 'your main agent';
const short = (text, n) => (String(text).length > n ? String(text).slice(0, n - 3) + '...' : String(text));
function lasted(ts) {
  const s = Math.round((Date.now() - new Date(ts).getTime()) / 1000);
  if (isNaN(s)) return '';
  const m = Math.floor(Math.max(0, s) / 60);
  if (m < 1) return 'less than a minute';
  return m < 60 ? `${m} min` : `${Math.floor(m / 60)} h ${String(m % 60).padStart(2, '0')} min`;
}

function when(ts) {
  if (!ts) return '';
  const d = new Date(ts);
  if (isNaN(d)) return esc(ts);
  const now = new Date();
  const hm = d.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' });
  if (d.toDateString() === now.toDateString()) return hm;
  return d.toLocaleDateString('en-GB', { day: 'numeric', month: 'short' }) + ' ' + hm;
}
function avatar(a, cls = '') {
  if (!a) return `<i class="av you ${cls}">Y</i>`;
  return `<i class="av ${esc(a.kind)} ${cls}" title="${esc(a.first_name)}${a.title ? ', ' + esc(a.title) : ''}">${esc(a.initials)}</i>`;
}
function avatarByName(name, cls = '') {
  const a = agentOf(name);
  if (a) return avatar(a, cls);
  const n = String(name || '?');
  if (isTool(n)) return `<i class="av tool ${cls}" title="${esc(toolName(n))}: a script with no AI">${esc(n.slice(0, 1).toUpperCase())}</i>`;
  return `<i class="av you ${cls}" title="${esc(n)}">${esc(n.slice(0, 1).toUpperCase())}</i>`;
}
function tone(word) {
  const w = String(word || '').toLowerCase();
  if (/^(pass|accept|ok|done|kept|applied|accepted|checked|used|built|finished|filed)/.test(w)) return 'good';
  if (/^(fix|needs|trial|waiting|proposed|challenged|pending|summarized|drafted|extended|partly|in progress)/.test(w)) return 'warn';
  if (/^(block|reject|failed|blocked|reach|rolled|stopped)/.test(w)) return 'bad';
  if (/^(conversion|running|new)/.test(w)) return 'info';
  return '';
}
const tag = (word, cls) => (word ? `<span class="tag ${cls || tone(word)}">${esc(word)}</span>` : '');
const fileHref = (path) => '#/file/' + String(path).split('/').map(encodeURIComponent).join('/');
const fileLink = (path, label) => (path ? `<a class="link" href="${fileHref(path)}">${esc(label || path)}</a>` : '');
const openItems = () => (S.data.queue || []).filter((q) => q.open);
function ownerName() {
  const o = (S.data.brain && S.data.brain.owner) || '';
  if (o && !/fictional/i.test(o)) return o.split(',')[0].trim();
  return (S.data.method && S.data.method.human && S.data.method.human.name) || 'You';
}
function agentRow(a, sub) {
  const st = statusOf(a.name);
  const state = st.state === 'unknown' ? 'idle' : st.state;
  return `<a class="agent" href="#/agent/${esc(a.name)}">${avatar(a)}
    <span class="who"><b>${esc(a.first_name)}${a.title ? ` <span style="display:inline;font-weight:600">· ${esc(a.title.replace(/^The /, ''))}</span>` : ''}</b>
    <span>${esc(sub || a.tagline || a.description)}</span></span>
    <span class="when"><i class="dot ${esc(state)}" title="${esc(state)}"></i><br>${st.state === 'running' ? sinceCell(st.started) : when(st.last)}</span></a>`;
}
/* Since when, and for how long. The length is redrawn every 20 seconds from the start time of the run log. */
const sinceCell = (ts) => `since ${when(ts)}<br><span data-since="${esc(ts)}">${esc(lasted(ts))}</span>`;
const sinceLine = (ts) => `since ${when(ts)} · <span data-since="${esc(ts)}">${esc(lasted(ts))}</span>`;
function toolRow(name) {
  const st = statusOf(name);
  return `<a class="agent" href="${whoHref(name)}">${avatarByName(name)}
    <span class="who"><b>${esc(toolName(name))} ${tag('tool')} <span style="display:inline;font-weight:600">· a script, no AI</span></b><span>${esc(st.summary || '')}</span></span>
    <span class="when"><i class="dot running" title="running"></i><br>${sinceCell(st.started)}</span></a>`;
}
function toast(text) {
  document.querySelectorAll('.toast').forEach((n) => n.remove());
  const el = document.createElement('div');
  el.className = 'toast';
  el.textContent = text;
  document.body.appendChild(el);
  setTimeout(() => el.remove(), 6000);
}

/* ---------------------------------------------------------------- markdown, small and safe */

function inline(text) {
  let t = esc(text);
  const keep = [];
  t = t.replace(/`([^`]+)`/g, (_m, code) => {
    const plain = code.replace(/&amp;/g, '&');
    const isPath = /^(brain|brains|ops|docs|\.claude)\/[\w\-./ ]+\.(md|json|jsonl|py|txt)$/.test(plain);
    keep.push(isPath ? `<a class="link" href="${fileHref(plain)}"><code>${code}</code></a>` : `<code>${code}</code>`);
    return `\u0000${keep.length - 1}\u0000`;
  });
  t = t.replace(/\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g, '<a href="$2" target="_blank" rel="noopener">$1</a>');
  t = t.replace(/\[([^\]]+)\]\(([\w\-./]+\.(?:md|json|py|txt))\)/g, (_m, label, p) => `<a class="link" href="${fileHref(p)}">${label}</a>`);
  t = t.replace(/(^|[\s(])(https?:\/\/[^\s<)]+)/g, '$1<a href="$2" target="_blank" rel="noopener">$2</a>');
  t = t.replace(/\*\*([^*]+)\*\*/g, '<b>$1</b>').replace(/(^|[\s(])\*([^*\s][^*]*)\*(?=[\s).,;:!?]|$)/g, '$1<i>$2</i>');
  t = t.replace(/^\[ \]\s/, '☐ ').replace(/^\[x\]\s/i, '☑ ');
  t = t.replace(/^(verdict|status|decision):\s*(.+)$/i, (_m, k, v) => `${k}: ${tag(v.replace(/<[^>]+>/g, ''))}`);
  return t.replace(/\u0000(\d+)\u0000/g, (_m, i) => keep[Number(i)]);
}

function md(source) {
  let text = String(source || '').replace(/\r\n/g, '\n');
  let meta = '';
  const fm = text.match(/^---\n([\s\S]*?)\n---\n?/);
  if (fm) {
    meta = `<div class="meta mono">${esc(fm[1]).replace(/\n/g, '<br>')}</div>`;
    text = text.slice(fm[0].length);
  }
  text = text.replace(/<!--\s*card\s*\n([\s\S]*?)-->/g, (_m, body) => '```card\n' + body.trim() + '\n```').replace(/<!--[\s\S]*?-->/g, '');
  const lines = text.split('\n');
  const out = [];
  let i = 0;
  let para = [];
  const flush = () => { if (para.length) { out.push('<p>' + para.map(inline).join('<br>') + '</p>'); para = []; } };
  while (i < lines.length) {
    const line = lines[i];
    if (/^```/.test(line)) {
      flush();
      const lang = line.slice(3).trim();
      const buf = [];
      i++;
      while (i < lines.length && !/^```/.test(lines[i])) buf.push(lines[i++]);
      i++;
      out.push(`<pre class="${lang === '' || lang === 'text' ? 'text' : ''}">${esc(buf.join('\n'))}</pre>`);
      continue;
    }
    if (/^ {4,}\S/.test(line) && !para.length && !/^\s*([-*]|\d+\.)\s/.test(line)) {
      const buf = [];
      while (i < lines.length && (/^ {4,}/.test(lines[i]) || lines[i].trim() === '')) buf.push(lines[i++].replace(/^ {4}/, ''));
      while (buf.length && buf[buf.length - 1].trim() === '') buf.pop();
      out.push(`<pre>${esc(buf.join('\n'))}</pre>`);
      continue;
    }
    const h = line.match(/^(#{1,4})\s+(.*)$/);
    if (h) { flush(); out.push(`<h${h[1].length}>${inline(h[2])}</h${h[1].length}>`); i++; continue; }
    if (/^\s*\|.*\|\s*$/.test(line)) {
      flush();
      const rows = [];
      while (i < lines.length && /^\s*\|.*\|\s*$/.test(lines[i])) rows.push(lines[i++].trim().replace(/^\||\|$/g, '').split('|').map((c) => c.trim()));
      const body = rows.filter((r) => !r.every((c) => /^:?-{2,}:?$/.test(c)));
      const head = body.shift() || [];
      out.push('<table><thead><tr>' + head.map((c) => `<th>${inline(c)}</th>`).join('') + '</tr></thead><tbody>' +
        body.map((r) => '<tr>' + r.map((c) => `<td>${inline(c)}</td>`).join('') + '</tr>').join('') + '</tbody></table>');
      continue;
    }
    if (/^\s*([-*]|\d+[.)])\s+/.test(line)) {
      flush();
      const items = [];
      while (i < lines.length && (/^\s*([-*]|\d+[.)])\s+/.test(lines[i]) || (/^\s{2,}\S/.test(lines[i]) && items.length))) {
        const m = lines[i].match(/^(\s*)([-*]|\d+[.)])\s+(.*)$/);
        if (m) items.push({ depth: Math.floor(m[1].length / 2), ordered: /\d/.test(m[2]), n: m[2], text: m[3] });
        else items[items.length - 1].text += ' ' + lines[i].trim();
        i++;
      }
      const ordered = items[0].ordered;
      out.push(`<${ordered ? 'ol' : 'ul'}>` + items.map((it) =>
        `<li style="margin-left:${Math.min(it.depth, 4) * 18}px"${ordered && it.ordered ? ` value="${parseInt(it.n, 10)}"` : ''}>${inline(it.text)}</li>`).join('') + `</${ordered ? 'ol' : 'ul'}>`);
      continue;
    }
    if (/^>\s?/.test(line)) {
      flush();
      const buf = [];
      while (i < lines.length && /^>\s?/.test(lines[i])) buf.push(lines[i++].replace(/^>\s?/, ''));
      out.push('<blockquote>' + buf.map(inline).join('<br>') + '</blockquote>');
      continue;
    }
    if (/^\s*(-{3,}|\*{3,})\s*$/.test(line)) { flush(); out.push('<hr>'); i++; continue; }
    if (line.trim() === '') { flush(); i++; continue; }
    para.push(line);
    i++;
  }
  flush();
  return meta + out.join('\n');
}

/* ---------------------------------------------------------------- frame: sidebar and pill */

function renderSide() {
  const r = route();
  const open = openItems().length;
  const nav = (page, ico, label, sub, count) => `<a class="nav ${r.page === page ? 'on' : ''}" href="#/${page === 'home' ? '' : page}">
    <i class="ico">${ico}</i><span><b>${label}</b><span>${sub}</span></span>${count ? `<em class="count">${count}</em>` : ''}</a>`;
  let html = '<h6>Operate</h6>' +
    nav('home', '◉', 'Mission Control', 'what needs you now', open) +
    nav('team', '☷', 'AI Team', 'agents and roles') +
    nav('routines', '↻', 'Routines', 'chains and gates');
  if (steps().length) {
    html += `<h6>The method${S.data.method.method ? ': ' + esc(S.data.method.method) : ''}</h6>` + steps().map((s) =>
      `<a class="navdot ${r.page === 'step' && r.arg === s.letter ? 'on' : ''}" href="#/step/${esc(s.letter)}"><i style="background:${esc(s.color)}"></i>${esc(s.letter)} · ${esc(s.name)}<em>${esc(s.organ || '')}</em></a>`).join('');
  }
  html += '<h6>System</h6>' +
    nav('memory', '▤', 'Memory', 'what the brain knows') +
    nav('loop', '∞', 'The Loop', 'measure, propose, decide') +
    nav('runs', '≡', 'Run log', 'every run, newest first') +
    nav('skills', '✦', 'Skills', 'the know-how');
  const shelf = (S.data.shelf || []).filter((b) => !b.template);
  if (S.data.brain.exists || shelf.length) {
    html += '<h6>Brains</h6>';
    if (S.data.brain.exists) html += `<a class="navdot on" href="#/file/brain/BRAIN.md"><i style="background:#2FA36B"></i>${esc(S.data.brain.id || S.data.brain.name)}<em>active</em></a>`;
    html += shelf.map((b) => `<a class="navdot" href="${fileHref(b.folder + '/BRAIN.md')}" title="python ops/tools/switch_brain.py use ${esc(b.id || '')}"><i style="background:#CFC7BD"></i>${esc(b.id || b.name)}<em>shelf</em></a>`).join('');
  }
  $('#side').innerHTML = html;
}

function renderPill() {
  const b = S.data.brain;
  const parts = [];
  if (b.exists) {
    parts.push('brain: ' + (b.id || b.name));
    if (/fictional/i.test(b.kind || '')) parts.push('fictional');
    if (S.data.loop && S.data.loop.scorecards) parts.push(b.sample_data ? 'sample numbers' : 'real numbers');
    else if (b.sample_data) parts.push('sample numbers');
  } else parts.push(S.data.project);
  const open = openItems().length;
  if (open) parts.push(open + ' waiting for you');
  const el = $('#pill');
  el.textContent = parts.join(' · ');
  el.className = 'pill' + (b.sample_data ? ' sample' : '');
}

/* ---------------------------------------------------------------- pages */

/* The file an agent asks you to read, shown inside its card: the first 40 lines, then all of it. */
const PREVIEW_LINES = 40;
const previewKey = (q) => q.file + '|' + (q.file_mtime || '');
function previewBlock(q) {
  if (!q.file) return '';
  if (!q.file_ok) return `<div class="small muted" style="margin-bottom:10px">Read first: ${esc(q.file)} (this file is not there, or the screen cannot show it)</div>`;
  const p = S.previews[previewKey(q)];
  if (!p) return `<div class="preview"><div class="phead small muted">Reading ${esc(q.file)}...</div></div>`;
  if (p.error) return `<div class="small muted" style="margin-bottom:10px">Read first: ${fileLink(q.file)} (${esc(p.error)})</div>`;
  const lines = p.text.split('\n');
  const long = lines.length > PREVIEW_LINES;
  const all = !long || !!S.expanded[q.id];
  const text = all ? p.text : lines.slice(0, PREVIEW_LINES).join('\n');
  return `<div class="preview"><div class="phead small muted">Read first: ${fileLink(q.file)} · changed ${when(q.file_mtime)}${long ? ` · ${lines.length} lines` : ''}</div>
    <div class="pbody md ${long && all ? 'all' : ''}">${/\.md$/.test(q.file) ? md(text) : `<pre>${esc(text)}</pre>`}</div>
    ${long ? `<div class="pfoot"><button class="btn" data-expand="${esc(q.id)}">${all ? `Show the first ${PREVIEW_LINES} lines only` : `Show all (${lines.length} lines)`}</button></div>` : ''}</div>`;
}
/* One vocabulary: the choices as the agent wrote them (Approve when it wrote none), and one box to change something. */
function waitCard(q) {
  const picks = q.choices.filter((c) => !/^change( something)?$/i.test(c.trim()));
  const buttons = picks.length
    ? picks.map((c, i) => `<button class="btn ${i === 0 ? 'go' : ''}" data-decide="${esc(q.id)}" data-choice="${esc(c)}">${esc(c)}</button>`).join(' ')
    : `<button class="btn go" data-decide="${esc(q.id)}" data-choice="approve">Approve</button>`;
  return `<div class="card wait">${avatarByName(q.from, 'lg')}<div>
    <div class="small muted">${esc(q.id)} · ${esc((agentOf(q.from) || {}).first_name || q.from)} asks · ${when(q.ts)}</div>
    <p>${esc(q.ask)}</p>
    ${previewBlock(q)}
    <div class="row" style="flex-wrap:wrap">${buttons}</div>
    <div class="change"><label class="k" for="note-${esc(q.id)}">Change something</label>
      <div class="row"><textarea id="note-${esc(q.id)}" rows="2" data-note="${esc(q.id)}" placeholder="Say what to change, in your own words">${esc(S.drafts[q.id] || '')}</textarea>
        <button class="btn" data-change="${esc(q.id)}">Send</button></div>
      <div class="small muted">Send records "change:" and your text. If you click a choice instead, your text goes with it as a note.</div></div></div></div>`;
}
/* A click cannot wake the terminal: say so until an agent starts again. */
const recordedItems = () => (S.data.queue || []).filter((q) => !q.open && (q.via === 'screen' || S.recorded[q.id]) && q.decided_recent && !q.moved_on);
function recordedCard(q) {
  return `<div class="card wait done">${avatarByName(q.from, 'lg')}<div>
    <div class="small muted">${esc(q.id)} · decided ${when(q.decided_ts)}</div>
    <p>Recorded. Now tell ${esc(lead())}: continue.</p>
    <div class="small">Your decision: <b>${esc(q.decision || '')}</b>${q.note ? ` <span class="muted">(note: ${esc(q.note)})</span>` : ''}</div>
    <div class="small muted" style="margin-top:6px">A click cannot wake ${esc(lead())}'s window. Go to it and type <span class="say">continue</span> to have your decision applied.</div></div></div>`;
}
function runRow(rn) {
  const a = agentOf(rn.agent);
  const tool = !a && (rn.source === 'tool' || isTool(rn.agent));
  const outs = (rn.outputs || []).map((p) => fileLink(p, p.split('/').slice(-2).join('/'))).join('<br>');
  return `<tr><td class="num muted">${when(rn.ts)}</td>
    <td><span class="row" style="gap:8px">${avatarByName(rn.agent, 'sm')}<a href="${whoHref(rn.agent)}"><b>${esc(a ? a.first_name : tool ? toolName(rn.agent) : rn.agent)}</b></a>${tool ? tag('tool') : ''}</span></td>
    <td>${rn.event === 'start' ? tag('running', 'info') : tag(rn.status)} ${tag(rn.verdict)}</td>
    <td>${esc(rn.summary || '')}${rn.routine ? ` <span class="muted small">(${esc(rn.routine)})</span>` : ''}${rn.source === 'hook' ? ' <span class="muted small">hook</span>' : ''}</td>
    <td class="small">${outs}</td></tr>`;
}

/* Where you are: the steps of the method, each one built, in progress or not started. Read from the files by serve.py. */
const STATE_TONE = { built: 'good', 'in progress': 'warn', 'not started': '' };
function journeyBlock() {
  const j = S.data.journey;
  if (!j || !j.steps.length) return '';
  const cell = (s) => {
    const st = stepOf(s.letter) || STEPS_FALLBACK;
    const cls = s.state === 'built' ? 'built' : s.state === 'in progress' ? 'doing' : 'todo';
    const here = j.next && j.next.letter === s.letter;
    return `<div class="jstep ${cls} ${here ? 'here' : ''}">
      <a href="#/step/${esc(s.letter)}" title="${esc(s.short)}"><i class="letter" style="background:${esc(st.color)}">${esc(s.letter)}</i><b>${esc(s.name)}</b></a>
      ${tag(s.state, STATE_TONE[s.state] || '')}
      ${s.proof ? `<a class="link small" href="${fileHref(s.proof)}" title="${esc(s.proof)}">${esc(s.says)}</a>` : j.in_use ? `<span class="small muted">${esc(s.says)}</span>` : ''}
      ${here ? '<em>you are here</em>' : ''}</div>`;
  };
  return `<div class="card tight"><div class="spread"><span class="k">Where you are</span>
      <span class="small muted">${j.in_use ? 'each state is read from a file: click it to open the proof' : 'No brain is in use yet. The first step is the Self.'}</span></div>
    <div class="journey">${j.steps.map(cell).join('')}</div></div>`;
}
/* What to do now: decide, or wait, or tell the main agent to continue. */
function nowBlock() {
  const n = S.data.journey && S.data.journey.now;
  if (!n) return '';
  const length = n.kind === 'wait' && n.since ? ` <span class="muted">(<span data-since="${esc(n.since)}">${esc(lasted(n.since))}</span>)</span>` : '';
  const side = n.kind === 'decide' ? '<button class="btn go" data-scroll="waiting">Show me</button>' : n.say ? `<span class="say">${esc(n.say)}</span>` : '';
  return `<div class="card now ${esc(n.kind)}"><div><div class="k">What to do now</div><b>${esc(n.title)}${length}</b><p>${esc(n.text)}</p></div>${side}</div>`;
}
/* Your computer: the few things that stop a first run. Open until the Self is built, folded after. */
const MARK = { ok: '✓', todo: '!', fix: '!', unknown: '?', info: 'i' };
function computerBlock() {
  const c = S.data.computer;
  if (!c || !c.lines.length) return '';
  const open = S.folds.computer !== undefined ? S.folds.computer : c.open;
  const ok = c.lines.filter((l) => l.mark === 'ok').length;
  const look = c.lines.filter((l) => l.mark === 'todo' || l.mark === 'fix').length;
  return `<details class="card tight computer" data-keep="computer" ${open ? 'open' : ''}><summary>Your computer <span class="small muted">${ok} OK${look ? `, ${look} to look at` : ''}</span></summary>
    <ul class="checks">${c.lines.map((l) => `<li class="chk ${esc(l.mark)}"><i>${MARK[l.mark] || '?'}</i><span><b>${esc(l.fact)}</b>${l.do ? `<span class="small muted">${esc(l.do)}</span>` : ''}</span></li>`).join('')}</ul></details>`;
}
const runsTable = (runs) => (runs.length ? `<table class="tbl"><thead><tr><th>When</th><th>Agent</th><th>Result</th><th>What</th><th>Files</th></tr></thead><tbody>${runs.map(runRow).join('')}</tbody></table>` : '<div class="empty">No run yet. Every agent writes a start line and a stop line (skill run-trace).</div>');

function viewHome() {
  const d = S.data;
  const open = openItems();
  const told = recordedItems();
  const running = d.agents.filter((a) => statusOf(a.name).state === 'running');
  const tools = Object.keys(d.status || {}).filter((n) => isTool(n) && statusOf(n).state === 'running');
  const stops = d.runs.filter((r) => r.event === 'stop' || statusOf(r.agent).state === 'running');
  const today = new Date().toDateString();
  let recent = stops.filter((r) => new Date(r.ts).toDateString() === today);
  let label = 'Today';
  if (!recent.length && stops.length) { recent = stops.slice(0, 12); label = 'Latest runs'; }
  const done = (d.queue || []).filter((q) => !q.open).slice(-4).reverse();
  const radar = d.radar ? radarStatus() : null;
  const lib = d.library ? libraryStatus() : null;
  const facts = [
    [d.agents.length, 'agents', '#/team'], [open.length, 'waiting for you', '#/'],
    [recent.filter((r) => r.event === 'stop').length, label === 'Today' ? 'runs today' : 'latest runs', '#/runs'],
    [(d.index || []).length, 'sources in memory', '#/memory'],
  ];
  return `<h1>Mission Control</h1><p class="lead">Where you are, what to do now, what waits for you. The brain proposes, you decide.</p>
    ${journeyBlock()}${nowBlock()}${computerBlock()}
    <div class="grid g4" style="margin-top:18px">${facts.map((f) => `<a class="card tight fact" href="${f[2]}"><b>${f[0]}</b><span>${f[1]}</span></a>`).join('')}</div>
    ${radar ? `<p class="small" style="margin-top:12px"><a class="link" href="#/step/E">Radar</a> ${tag(radar.word, RADAR_TONE[radar.word] || '')} <span class="muted">${esc(radar.line)}</span></p>` : ''}
    ${lib ? `<p class="small" style="margin-top:8px"><a class="link" href="#/step/E">Your knowledge</a> ${tag(lib.word, LIB_TONE[lib.word] || '')} <span class="muted">${esc(lib.line)}</span></p>` : ''}
    <h2 id="waiting">Waiting for you <small>${open.length ? 'each card is a gate: nothing goes on without your answer' : ''}</small></h2>
    <div class="grid">${told.map(recordedCard).join('')}${open.length ? open.map(waitCard).join('') : told.length ? '' : '<div class="card empty">Nothing waits for you.</div>'}</div>
    ${done.length ? `<p class="small muted" style="margin-top:12px">Last decisions: ${done.map((q) => `${esc(q.id)} ${tag(short(q.decision || 'done', 48))}`).join(' &nbsp; ')}</p>` : ''}
    <h2>Running now <small>since when, and for how long</small></h2>
    <div class="card tight">${running.length || tools.length ? `<div class="grid g3">${running.map((a) => agentRow(a, statusOf(a.name).summary)).join('')}${tools.map(toolRow).join('')}</div>` : '<div class="empty">No agent is running.</div>'}
      <p class="small muted advice">Do not press Esc in ${esc(lead())}'s window while an agent works: it stops the agent.</p></div>
    <h2>${label} <small><a class="link" href="#/runs">the whole run log</a></small></h2>
    <div class="card">${runsTable(recent.slice(0, 25))}</div>`;
}

function viewTeam() {
  const d = S.data;
  const gov = d.agents.filter((a) => a.kind === 'governance' || a.step === 'G');
  const reviewers = d.agents.filter((a) => a.kind === 'reviewer');
  const lead = gov[0];
  const groups = steps().length ? steps().map((s) => ({ step: s, agents: d.agents.filter((a) => a.step === s.letter) })) : [];
  const placed = new Set([...gov, ...groups.flatMap((g) => g.agents)].map((a) => a.name));
  const others = d.agents.filter((a) => !placed.has(a.name));
  if (others.length) groups.push({ step: { letter: '·', name: 'Other agents', organ: 'no step on their card', color: '#6B635C' }, agents: others });
  const hqName = (d.method.governance && d.method.governance.name) || 'Headquarters';
  const dept = (g) => `<div class="card dept"><a class="head" ${g.step.folder ? `href="#/step/${esc(g.step.letter)}"` : ''}>
      <i class="letter" style="background:${esc(g.step.color)}">${esc(g.step.letter)}</i>
      <span><b>${esc(g.step.name)}</b><span>${esc(g.step.organ || '')}${g.step.short ? ' · ' + esc(g.step.short) : ''}</span></span></a>
      ${g.agents.length ? g.agents.map((a) => agentRow(a)).join('') : '<div class="empty small">No agent on this step yet.</div>'}</div>`;
  return `<div class="team"><div>
      <div class="human"><i class="av xl you">${esc(ownerName().slice(0, 1).toUpperCase())}</i><b>${esc(ownerName())}</b>
        <span>${esc((d.method.human && d.method.human.subtitle) || 'The human · final decisions')}</span></div>
      <div class="wire"></div>
      <div class="card"><div class="spread"><b style="font-size:1.12rem">${esc(hqName)}</b><span class="muted small">${lead ? 'Led by ' + esc(lead.first_name) : ''}</span></div>
        <div class="hq">${gov.map((a) => agentRow(a)).join('')}
          <a class="fact" href="#/"><b>${openItems().length}</b><span>waiting for you</span></a>
          <a class="fact" href="#/routines"><b>${(d.routines || []).length}</b><span>routines</span></a></div></div>
      <div class="wire"></div>
      <h2 style="margin-top:0">${steps().length ? 'The six steps' : 'The team'} <small>${steps().length ? 'one agent, one job, one folder' : ''}</small></h2>
      <div class="grid g3">${groups.map(dept).join('')}</div></div>
    <div class="card"><b style="font-size:1.12rem">Independent reviewers</b><div class="muted small" style="margin-bottom:12px">Nobody reviews their own work</div>
      ${reviewers.length ? reviewers.map((a) => agentRow(a, a.reviews ? 'checks ' + a.reviews : a.tagline)).join('') : '<div class="empty small">No reviewer yet (kind: reviewer on the card).</div>'}
      <div style="border-top:1px solid var(--line);margin:14px 0 10px"></div>
      <div class="small muted">Orange: a worker. Teal: a reviewer, who writes only its review file. A dot: the last run. Click an agent for its card, skills and outputs.</div></div></div>`;
}

function viewAgent(name) {
  const a = agentOf(name);
  if (!a) return `<h1>No agent named ${esc(name)}</h1><p><a class="link" href="#/team">Back to the team</a></p>`;
  const st = statusOf(a.name);
  const s = stepOf(a.step);
  const runs = S.data.runs.filter((r) => r.agent === a.name).slice(0, 15);
  const outs = [...new Set(S.data.runs.filter((r) => r.agent === a.name).flatMap((r) => r.outputs || []))].slice(0, 12);
  const checks = S.data.agents.filter((x) => (x.reviews || '').toLowerCase().split(/[,\s]+/).includes(a.name) || (a.checked_by || '').toLowerCase() === x.name);
  const skills = a.skills.map((n) => { const sk = (S.data.skills || []).find((k) => k.name === n); return sk ? `<a class="tag" href="${fileHref(sk.file)}">${esc(n)}</a>` : tag(n); }).join(' ');
  const who = (text) => esc(text).replace(/\b([a-z]{3,12})\b/g, (w) => (agentOf(w) ? `<a class="link" href="#/agent/${w}">${esc(agentOf(w).first_name)}</a>` : w));
  return `<div class="crumb"><a class="link" href="#/team">AI Team</a> / ${esc(a.name)}</div>
    <div class="row" style="gap:18px;margin-bottom:18px">${avatar(a, 'xl ring')}<div><h1>${esc(a.first_name)}${a.title ? ', ' + esc(a.title) : ''}</h1>
      <div class="muted">${esc(a.tagline)}</div>
      <div style="margin-top:8px">${s ? `<a class="tag step" style="background:${esc(s.color)}" href="${s.folder && a.step !== 'G' ? '#/step/' + esc(a.step) : '#/team'}">${esc(a.step)} · ${esc(s.name)}</a>` : ''} ${tag(a.kind, a.kind === 'reviewer' ? 'good' : '')} ${a.model ? tag('model: ' + a.model) : ''}
        <i class="dot ${esc(st.state)}" style="margin-left:8px"></i> <span class="small muted">${st.state === 'running' ? 'running now, ' + sinceLine(st.started) : st.last ? 'last run ' + when(st.last) : 'never ran here'}</span></div></div></div>
    <div class="grid g2"><div class="card"><dl class="kv">
        <dt>Job</dt><dd>${esc(a.description)}</dd>
        <dt>Reads</dt><dd>${inline(a.reads.split(',').map((p) => '`' + p.trim() + '`').join(', '))}</dd>
        <dt>Writes</dt><dd>${inline(a.writes.split(',').map((p) => '`' + p.trim() + '`').join(', '))}</dd>
        ${a.reviews ? `<dt>Reviews</dt><dd>${who(a.reviews)}</dd>` : ''}
        <dt>Checked by</dt><dd>${who(a.checked_by || 'nobody yet')}</dd>
        <dt>Runs</dt><dd>${esc(a.runs)}</dd>
        <dt>Skills</dt><dd>${skills || '<span class="muted">none</span>'}</dd>
        <dt>File</dt><dd>${fileLink(a.file)}</dd></dl>
        ${a.has_card ? '' : '<p class="small muted">This agent has no card. The skill agent-card writes it.</p>'}</div>
      <div class="card"><b>Last outputs</b>${outs.length ? `<ul class="files" style="columns:1">${outs.map((p) => `<li>${fileLink(p)}</li>`).join('')}</ul>` : '<div class="empty">Nothing yet.</div>'}
        ${checks.length ? `<div style="margin-top:14px"><b>Works with</b>${checks.map((x) => agentRow(x)).join('')}</div>` : ''}</div></div>
    <h2>Last runs</h2><div class="card">${runsTable(runs)}</div>`;
}

function fileList(files, base) {
  if (!files.length) return '<div class="empty">No file here yet.</div>';
  return `<ul class="files">${files.map((f) => `<li>${fileLink(f.path, f.path.slice(base.length).replace(/^\//, ''))}<em>${when(f.mtime)}</em></li>`).join('')}</ul>`;
}
/* The radar of brain/2-ears/: is it set up, did it run today, what did Carl keep. Read from its files only. */
function localDate(d = new Date()) {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}
const RADAR_TONE = { running: 'info', 'ran today': 'good', 'not today': 'warn', 'never ran': 'warn', failed: 'bad', cut: 'bad' };
function radarStatus() {
  const r = S.data.radar;
  if (!r) return { word: 'no radar', line: 'No radar for this brain. /build-ears sets one up, if you want it.' };
  const live = statusOf('radar');   /* radar.py writes a start and a stop line in ops/runs/ */
  if (live.state === 'running') return { word: 'running', line: `Running since ${when(live.started)}. ${live.summary || ''}` };
  if (live.state === 'unknown') return { word: 'cut', line: `Started at ${when(live.started)} and never ended: the run was cut. Run it again: python ops/tools/radar.py` };
  if (live.state === 'failed' && String(live.last || '').slice(0, 10) === localDate()) return { word: 'failed', line: `Failed today at ${when(live.last)}. ${live.summary || ''}` };
  const real = r.sources.filter((s) => !s.example);
  if (!r.days.length && !real.length) return { word: 'not set up', line: 'radar.json still holds the examples of the template. /build-ears writes your sources in it.' };
  const day = r.days[0];
  if (!day) return { word: 'never ran', line: `${real.length} source(s), never run yet. Run: python ops/tools/radar.py` };
  const last = day.runs[day.runs.length - 1];
  const what = last ? `${num(last.new)} new from ${last.sources} source(s)${last.failed ? `, ${last.failed} could not be read` : ''}` : 'a page with no run line';
  const carl = day.shortlist ? ` Carl kept ${day.kept ?? '?'}${day.scored ? ' of ' + num(day.scored) : ''}.` : ' Not scored by Carl yet.';
  if (day.date === localDate()) return { word: last && last.failed && last.failed === last.sources ? 'failed' : 'ran today', day, line: `Ran today at ${last ? last.time : '?'}: ${what}.${carl}` };
  return { word: 'not today', day, line: `Not run today. Last run: ${day.date}${last ? ' at ' + last.time : ''}, ${what}.${carl}` };
}
function radarBlock() {
  const r = S.data.radar;
  const st = radarStatus();
  const sources = r ? r.sources.map((s) => `<span class="tag ${s.example ? '' : 'info'}">${esc(s.name)} · ${esc(s.kind)}${s.example ? ' (example)' : ''}</span>`).join(' ') : '';
  const rows = r ? r.days.map((d) => `<tr><td>${fileLink(d.page, d.date)}</td>
      <td class="small">${d.runs.map((x) => esc(x.time)).join(', ') || '<span class="muted">none</span>'}</td>
      <td class="num">${num(d.runs.reduce((n, x) => n + x.new, 0))}${d.runs.some((x) => x.failed) ? ' ' + tag('a source failed', 'bad') : ''}</td>
      <td>${d.shortlist ? `${fileLink(d.shortlist, 'kept ' + (d.kept ?? '?') + (d.scored ? ' of ' + num(d.scored) : ''))}` : '<span class="muted small">not scored yet: ask "score today\'s radar"</span>'}</td></tr>`).join('') : '';
  return `<h2>The radar <small>a script with no AI: it lists, Carl scores</small></h2>
    <div class="card"><div class="row" style="gap:10px;flex-wrap:wrap">${tag(st.word, RADAR_TONE[st.word] || '')}<span>${esc(st.line)}</span></div>
      ${sources ? `<div class="row" style="gap:6px;flex-wrap:wrap;margin-top:12px">${sources}</div>` : ''}
      ${rows ? `<table class="tbl" style="margin-top:14px"><thead><tr><th>Day</th><th>Runs at</th><th>New items</th><th>Carl's shortlist</th></tr></thead><tbody>${rows}</tbody></table>` : ''}
      <p class="small muted" style="margin-bottom:0">Each run of the radar writes a start line and a stop line in the run log (<code>ops/runs/</code>): this card and Alfred read them to say whether it is running or done. The 07:00 run happens only once you registered the schedule that <code>python ops/tools/radar.py --print-schedule</code> prints.</p></div>`;
}

/* Your knowledge: what ops/tools/library.py found in my-knowledge/ and filed, and whether it runs now.
   Read from brain/2-ears/library/state.json and from the lines of the script in the run log. */
const LIB_TONE = { running: 'info', finished: 'good', failed: 'bad', stopped: 'bad', 'not run yet': '' };
function libraryStatus() {
  const L = S.data.library;
  const f = L.flag;
  const t = L.totals;
  const counts = t ? `${num(t.filed)} filed, ${num(t.waiting)} waiting, ${num(L.digested)} digested.` : '';
  if (f.word === 'running') return { word: 'running', line: `Running since ${when(f.since)}. ${f.line || ''}` };
  if (f.word === 'stopped') return { word: 'stopped', line: `Started at ${when(f.since)} and stopped without a stop line. Tell ${lead()}: file my knowledge.` };
  if (f.word === 'failed') return { word: 'failed', line: `Failed at ${when(f.at)}. ${f.line || ''}` };
  if (f.word === 'finished') return { word: 'finished', line: `Finished at ${when(f.at)}. ${counts || f.line || ''}` };
  if (L.knowledge_files) return { word: 'not run yet', line: `${num(L.knowledge_files)} file(s) in ${L.knowledge_dir}, not scanned yet. Tell ${lead()}: file my knowledge.` };
  return { word: 'not run yet', line: `No file in ${L.knowledge_dir}/ yet. Put what you know there (a book, slides, notes): the Ears step files it, with your yes.` };
}
function libraryBlock() {
  const L = S.data.library;
  if (!L) return '';
  const f = L.flag;
  const t = L.totals;
  const flags = {
    running: `<span class="tag flag info"><i class="dot running"></i>Running now</span><span>${sinceLine(f.since)}</span>`,
    finished: `<span class="tag flag good">Finished</span><span>at ${when(f.at)}</span>`,
    failed: `<span class="tag flag bad">Failed</span><span>at ${when(f.at)}</span>`,
    stopped: `<span class="tag flag bad">Stopped</span><span>started at ${when(f.since)}, stopped without a stop line</span>`,
  };
  const said = f.word === 'not run yet' || f.word === 'stopped' ? libraryStatus().line : f.line;
  const facts = t ? [[num(t.filed), 'filed', 'documents in brain/2-ears/sources/, marked origin: mine'], [num(t.waiting), 'waiting', 'readable files of a folder you did not decide yet'],
    [num(t.left_out), 'left out', 'files of a folder you said no to'], [num(t.not_readable), 'not readable', 'see the list below'],
    [`${num(L.digested)} of ${num(L.documents)}`, 'digested', 'filed documents that Condense summarized: a line in the memory index']] : [];
  const more = (x) => [x.not_readable ? `${x.not_readable} not readable` : '', x.duplicates ? `${x.duplicates} already filed or twice` : '', x.private ? `${x.private} with a private word` : ''].filter(Boolean).join(' · ');
  const rows = L.folders.map((x) => `<tr><td><b>${esc(x.folder || '(top of the folder)')}</b>${more(x) ? `<div class="small muted">${esc(more(x))}</div>` : ''}</td>
      <td class="num">${num(x.files)}</td><td class="num">${num(x.readable)}</td><td class="num">${num(x.words)}</td><td class="num">${num(x.filed)}</td><td>${tag(x.status)}</td></tr>`).join('');
  const unread = L.not_readable.length ? `<details data-keep="unread" ${S.folds.unread ? 'open' : ''}><summary>${L.not_readable.length} file(s) could not be read</summary>
      <ul class="unread">${L.not_readable.map((u) => `<li><span class="mono">${esc(u.path)}</span> <span class="muted">${esc(u.why)}</span></li>`).join('')}</ul></details>` : '';
  return `<h2>Your knowledge <small>what you put in ${esc(L.knowledge_dir)}/: a script with no AI files it, folder by folder, with your yes</small></h2>
    <div class="card"><div class="row" style="gap:10px;flex-wrap:wrap">${flags[f.word] || '<span class="tag flag">Not run yet</span>'}</div>
      ${said ? `<p style="margin:10px 0 0">${esc(said)}</p>` : ''}
      ${!t && L.knowledge_files && f.word !== 'not run yet' ? `<p class="small muted" style="margin:6px 0 0">${num(L.knowledge_files)} file(s) in ${esc(L.knowledge_dir)}, not scanned yet.</p>` : ''}
      ${facts.length ? `<div class="facts">${facts.map((x) => `<div class="fact" title="${esc(x[2])}"><b>${x[0]}</b><span>${x[1]}</span></div>`).join('')}</div>` : ''}
      ${rows ? `<table class="tbl" style="margin-top:6px"><thead><tr><th>Folder</th><th class="num">Files</th><th class="num">Readable</th><th class="num">Words</th><th class="num">Filed</th><th>Status</th></tr></thead><tbody>${rows}</tbody></table>` : ''}
      ${unread}
      <p class="small muted" style="margin-bottom:0">${L.page ? `The whole list, file by file: ${fileLink(L.page)}. ` : ''}The script is <code>ops/tools/library.py</code>. It reads ${esc(L.knowledge_dir)}/ and files nothing without your yes for the folder. ${L.state ? `These numbers come from ${fileLink(L.state)}.` : 'Its numbers appear here after the first scan.'}</p></div>`;
}

function viewStep(letter) {
  const s = stepOf(letter);
  if (!s) return `<h1>No step ${esc(letter)}</h1>`;
  const agents = S.data.agents.filter((a) => a.step === letter);
  const files = S.data.tree.filter((f) => f.path.startsWith(s.path + '/')).sort((x, y) => (x.mtime < y.mtime ? 1 : -1));
  const readme = S.data.tree.find((f) => f.path === s.path + '/README.md');
  return `<div class="row" style="gap:16px;margin-bottom:6px"><i class="letter" style="background:${esc(s.color)};width:58px;height:58px;font-size:1.4rem">${esc(s.letter)}</i>
      <div><h1>${esc(s.name)} <span class="muted" style="font-weight:600;font-size:1.1rem">· ${esc(s.organ || '')}</span></h1><div class="muted">${esc(s.question || '')}</div></div></div>
    <h2>Its agents</h2><div class="card tight"><div class="grid g3">${agents.map((a) => agentRow(a)).join('') || '<div class="empty">No agent on this step.</div>'}</div></div>
    ${s.folder === '2-ears' ? libraryBlock() + radarBlock() : ''}
    <h2>Its memory <small class="mono">${esc(s.path)}/</small></h2>
    <div class="card">${readme ? `<p class="small muted" style="margin-top:0">What goes there, and who writes it: ${fileLink(readme.path, 'README.md')}</p>` : ''}${fileList(files.filter((f) => !f.path.endsWith('README.md')), s.path)}</div>`;
}

function viewMemory() {
  const d = S.data;
  if (!d.brain.exists) return '<h1>Memory</h1><p class="lead">No brain/ folder in this project yet.</p>';
  const count = (prefix, skip) => d.tree.filter((f) => f.path.startsWith('brain/' + prefix) && !f.path.endsWith('README.md') && !(skip && f.path.includes(skip))).length;
  const byStatus = {};
  d.index.forEach((r) => { byStatus[r.status] = (byStatus[r.status] || 0) + 1; });
  const shelves = [
    ['Who I am', count('1-self/', '_tests'), 'files in 1-self', '#/step/S'],
    ['What I know', d.index.length, 'sources in the index', '#/step/C'],
    ['What I did', count('5-narrate/posted/'), 'pieces that went out', '#/step/N'],
    ['What I learned', (d.loop && d.loop.lessons) || 0, 'lessons kept', '#/loop'],
  ];
  const rows = d.index.map((r) => `<tr><td class="num muted">${esc(r.date)}</td><td><b>${esc(r.title)}</b><div class="mono muted">${esc(r.slug)}</div></td>
      <td>${esc(r.pillar)}</td><td>${tag(r.status)}</td><td class="small">${/^brain\//.test(r.summary || '') ? fileLink(r.summary, 'summary') : esc(r.summary || '')}</td>
      <td class="small">${/^https?:/.test(r.source || '') ? `<a class="link" href="${esc(r.source)}" target="_blank" rel="noopener">source</a>` : esc(r.source || '')}</td></tr>`).join('');
  const folders = steps().map((s) => {
    const files = d.tree.filter((f) => f.path.startsWith(s.path + '/'));
    return `<details><summary><span class="tag step" style="background:${esc(s.color)}">${esc(s.letter)}</span> ${esc(s.folder)} <span class="muted small">· ${files.length} files</span></summary>${fileList(files, s.path)}</details>`;
  }).join('');
  return `<h1>Memory</h1><p class="lead">The memory is six folders of plain files. A new session knows nothing: it reads them. Four shelves.</p>
    <div class="grid g4">${shelves.map((s) => `<a class="card shelf" href="${s[3]}"><span class="k">${s[0]}</span><b>${s[1]}</b><span class="muted small">${s[2]}</span></a>`).join('')}</div>
    <h2>The index <small>${Object.entries(byStatus).map(([k, v]) => `${v} ${k}`).join(' · ')}</small></h2>
    <div class="card">${rows ? `<table class="tbl"><thead><tr><th>Date</th><th>Source</th><th>Pillar</th><th>Status</th><th>Summary</th><th>Link</th></tr></thead><tbody>${rows}</tbody></table>` : '<div class="empty">The index is empty. Chloe adds a line for each source she summarizes.</div>'}
      <p class="small muted">One line per source. The status moves: new, summarized, checked, drafted, used. So the brain can answer "did I already use it?".</p></div>
    <h2>The files <small>${fileLink('brain/BRAIN.md', 'BRAIN.md')}</small></h2><div class="card">${folders || fileList(d.tree, 'brain')}</div>`;
}

function viewLoop() {
  const L = S.data.loop;
  if (!L || (!L.scorecards && !L.proposals.length)) {
    return `<h1>The Loop</h1><p class="lead">Measure, review, propose, challenge, you decide, apply, verify. No result in this brain yet.</p>
      <div class="card empty">Put your results in <code>brain/6-debrief/metrics/posts.json</code>, or launch <code>/build-debrief</code>.</div>`;
  }
  const sc = L.scorecards || { pieces: [], pillars: [], triggers: [], baseline: {} };
  const edits = {};
  ((L.edits && L.edits.pieces) || []).forEach((e) => { edits[e.slug] = e; });
  const waiting = openItems().filter((q) => /changes\//.test(q.file || ''));
  const applied = L.ledger.filter((r) => /applied|kept|rolled/.test(r.status || '')).length;
  const lastTest = L.tests[0];
  const measured = sc.pieces.filter((p) => p.verdict !== 'pending').length;
  const st = (n, title, who, text, live) => `<div class="stage ${live ? 'live' : ''}"><span class="n">Stage ${n}</span><b>${title}</b><div class="avs">${who.map((w) => avatarByName(w, 'sm')).join('')}</div><p>${text}</p></div>`;
  const stages = [
    st(1, 'Measure', ['dexter'], `${sc.pieces.length} pieces, ${measured} measured`),
    st(2, 'Review', ['diane'], `${Object.keys(L.cards).length} piece cards`),
    st(3, 'Propose', ['diane', 'serena', 'sacha'], `${L.proposals.length} proposals`),
    st(4, 'Challenge', ['diego'], `${L.proposals.filter((p) => p.challenge).length} challenged`),
    st(5, 'Decide', ['you'], waiting.length ? `${waiting.length} waiting for you` : 'nothing waits', waiting.length > 0),
    st(6, 'Apply', ['diane', 'serena', 'sacha'], `${applied} in the ledger`),
    st(7, 'Verify', ['sosie'], lastTest ? `Double test: ${esc(lastTest.score || lastTest.verdict || 'done')}` : 'no Double test yet'),
  ].join('');
  const triggers = (sc.triggers || []).map((t) => `<li>${tag(t.lever || t.type, 'warn')} ${esc(t.text)}</li>`).join('');
  const props = L.proposals.map((p) => `<tr><td class="mono">${fileLink(p.path, p.id)}</td><td>${tag(p.lever, 'info')}</td><td><b>${esc(p.title)}</b><div class="small muted">${fileLink(p.file)}</div></td>
      <td><span class="row" style="gap:6px">${avatarByName(p.proposed_by, 'sm')}${esc((agentOf(p.proposed_by) || {}).first_name || p.proposed_by)}</span></td>
      <td>${p.challenge ? `${tag(p.challenge.verdict)} <span class="small">${fileLink(p.challenge.path, 'challenge')}</span>` : '<span class="muted small">not challenged yet</span>'}</td><td>${tag(p.status)}</td></tr>`).join('');
  const ledger = L.ledger.map((r) => `<tr><td class="num muted">${esc(r.date)}</td><td class="mono">${esc(r.id)}</td><td>${tag(r.lever, 'info')}</td><td>${esc(r.summary)}<div class="small muted">${fileLink(r.file)}</div></td><td>${tag(r.decision)}</td><td>${tag(r.status)}</td><td class="small">${esc(r['review date'] || '')}</td><td class="small muted">${esc(r.note || '')}</td></tr>`).join('');
  const pillars = (sc.pillars || []).map((p) => `<tr><td><b>${esc(p.pillar)}</b></td><td class="num">${p.count}</td><td class="num">${p.measured}</td><td class="num">${num(Math.round(p.median_views_7d || 0))}</td>
      <td style="min-width:150px">${pct(p.median_vs_baseline)}<div class="bar"><i class="${p.median_vs_baseline >= 1 ? 'over' : ''}" style="width:${Math.min(100, (p.median_vs_baseline || 0) * 50)}%"></i></div></td>
      <td class="num">${p.ok} of ${p.measured}</td><td class="small">${p.run && p.run.length ? `${p.run.length} ${esc(p.run.side || p.run.direction || '')}` : ''}</td></tr>`).join('');
  const pieces = sc.pieces.map((p) => {
    const r7 = (p.readings && p.readings['7d']) || {};
    const e = edits[p.slug];
    const ratio = r7.views_vs_baseline;
    const posted = S.data.tree.find((f) => f.path.includes('/posted/') && f.path.endsWith(p.slug + '.md'));
    return `<tr><td class="num muted">${esc(p.date)}</td><td>${posted ? `<a class="link" href="${fileHref(posted.path)}">${esc(p.title)}</a>` : esc(p.title)}<div class="small muted">${esc(p.pillar || 'no pillar')} · ${esc(p.format || '')}</div></td>
      <td class="num" style="min-width:120px">${r7.views !== undefined && r7.views !== null ? num(r7.views) : '<span class="muted">not yet</span>'}${ratio ? `<div class="bar"><i class="${ratio >= 1 ? 'over' : ''}" style="width:${Math.min(100, ratio * 50)}%"></i></div>` : ''}</td>
      <td class="num">${ratio ? pct(ratio) : ''}</td><td>${tag(p.verdict)}</td><td class="num"><b>${p.score ?? ''}</b></td>
      <td class="small">${e ? `${e.hook_changed ? tag('first line rewritten', 'warn') : tag('first line kept')} <a class="link" href="${fileHref(e.report)}">${Math.round((e.kept || 0) * 100)} % kept</a>` : '<span class="muted">no draft</span>'}</td>
      <td class="small">${L.cards[p.slug] ? fileLink(L.cards[p.slug], 'card') : ''}</td></tr>`;
  }).join('');
  const base = sc.baseline || {};
  return `<h1>The Loop</h1><p class="lead">Debrief feeds Self. Seven stages, one agent at each. Three things can change: a lesson, a pillar, a writing rule. Somebody else challenges each change, you decide, and every change can be undone.</p>
    <div class="stages">${stages}</div>
    ${triggers ? `<h2>Triggers found <small>they open a proposal, they decide nothing</small></h2><div class="card"><ul style="margin:0;padding-left:18px">${triggers}</ul></div>` : ''}
    <h2>Proposed changes <small>${L.lessons_file ? fileLink(L.lessons_file, 'the lessons') : ''}</small></h2>
    <div class="card">${props ? `<table class="tbl"><thead><tr><th>Id</th><th>Lever</th><th>Change</th><th>Proposed by</th><th>Diego says</th><th>Status</th></tr></thead><tbody>${props}</tbody></table>` : '<div class="empty">No proposal yet.</div>'}</div>
    <h2>The ledger <small>${L.ledger_file ? fileLink(L.ledger_file, 'ledger.md') : ''}</small></h2>
    <div class="card">${ledger ? `<table class="tbl"><thead><tr><th>Date</th><th>Id</th><th>Lever</th><th>Change</th><th>Decision</th><th>Status</th><th>Review</th><th>Note</th></tr></thead><tbody>${ledger}</tbody></table>` : '<div class="empty">No decision recorded yet. One line per decision, written by ledger.py.</div>'}</div>
    ${L.tests.length ? `<h2>Double tests <small>the likeness must not drop after a change</small></h2><div class="card"><table class="tbl"><tbody>${L.tests.map((t) => `<tr><td class="num muted">${esc(t.date || when(t.mtime))}</td><td>${fileLink(t.path, t.title)}</td><td>${t.score ? '<b>' + esc(t.score) + '</b>' : ''}</td><td>${tag(t.verdict)}</td></tr>`).join('')}</tbody></table></div>` : ''}
    ${pillars ? `<h2>Pillars <small>baseline: ${num(base.views)} views at 7 days</small></h2><div class="card"><table class="tbl"><thead><tr><th>Pillar</th><th class="num">Pieces</th><th class="num">Measured</th><th class="num">Median views</th><th>Against the baseline</th><th class="num">OK</th><th>In a row</th></tr></thead><tbody>${pillars}</tbody></table></div>` : ''}
    ${pieces ? `<h2>Pieces <small>${fileLink('brain/6-debrief/metrics/scorecards.md', 'the full scorecards')}${L.weekly.length ? ' · ' + fileLink(L.weekly[0].path, 'the weekly review') : ''}</small></h2><div class="card"><table class="tbl"><thead><tr><th>Date</th><th>Piece</th><th class="num">Views 7 d</th><th class="num">Vs baseline</th><th>Verdict</th><th class="num">Score</th><th>Your edits</th><th>Review</th></tr></thead><tbody>${pieces}</tbody></table></div>` : ''}`;
}

function viewRoutines() {
  const cards = (S.data.routines || []).map((r) => {
    const last = S.data.runs.find((x) => x.routine === r.id && x.event === 'stop');
    const chain = (r.chain || []).map((c) => (c.gate
      ? `<span class="chip gate" title="${esc(c.gate)}">✋ you: ${esc(c.gate.length > 46 ? c.gate.slice(0, 44) + '...' : c.gate)}</span>`
      : `<a class="chip" href="#/agent/${esc(c.agent)}" title="${esc(c.does || '')}">${avatarByName(c.agent, 'sm')}${esc((agentOf(c.agent) || {}).first_name || c.agent)}</a>`)).join('<span class="arrow">→</span>');
    return `<div class="card"><div class="spread"><b style="font-size:1.12rem">${esc(r.name)}</b><span class="small muted">${last ? 'last run ' + when(last.ts) + ' ' + tag(last.status) : 'not run here yet'}</span></div>
      <div class="muted small" style="margin:2px 0 10px">${esc(r.when || '')}</div>
      <span class="say">${esc(r.say || '')}</span><div class="chain">${chain}</div></div>`;
  }).join('');
  return `<h1>Routines</h1><p class="lead">A routine is a fixed chain: who is called, in which order, and where it stops for you. Say the phrase to ${esc((S.data.agents.find((a) => a.kind === 'governance') || { first_name: 'the main agent' }).first_name)}.</p>
    <div class="grid">${cards || '<div class="card empty">No ops/routines.json in this project.</div>'}</div>`;
}

function viewRuns() {
  const f = S.filters;
  const agents = [...new Set(S.data.runs.map((r) => r.agent))].sort();
  const runs = S.data.runs.filter((r) => (!f.agent || r.agent === f.agent) && (!f.status || (r.event === 'start' ? 'start' : r.status) === f.status));
  const opt = (v, cur, label) => `<option value="${esc(v)}" ${v === cur ? 'selected' : ''}>${esc(label || v)}</option>`;
  return `<h1>Run log</h1><p class="lead">Every run leaves a trace: a start line and a stop line in <code>ops/runs/</code>. Newest first.</p>
    <div class="row" style="margin-bottom:14px"><select data-filter="agent">${opt('', f.agent, 'every agent')}${agents.map((a) => opt(a, f.agent)).join('')}</select>
      <select data-filter="status">${opt('', f.status, 'every status')}${['done', 'waiting', 'blocked', 'failed', 'start'].map((s) => opt(s, f.status)).join('')}</select>
      <span class="muted small">${runs.length} lines</span></div>
    <div class="card">${runsTable(runs.slice(0, 200))}</div>`;
}

function viewSkills() {
  const skills = S.data.skills || [];
  const card = (k) => `<a class="card tight" href="${fileHref(k.file)}"><div class="spread"><b>${esc(k.name)}</b>${k.you_can_launch ? `<span class="tag good mono">/${esc(k.name)}</span>` : ''}</div>
      <div class="small muted" style="margin:6px 0 10px;display:-webkit-box;-webkit-line-clamp:4;-webkit-box-orient:vertical;overflow:hidden">${esc(k.description)}</div>
      <div class="row" style="gap:4px;flex-wrap:wrap">${k.used_by.map((n) => avatarByName(n, 'sm')).join('') || '<span class="small muted">launched by you</span>'}${k.has_scripts ? ' <span class="tag">with scripts</span>' : ''}</div></a>`;
  return `<h1>Skills</h1><p class="lead">A skill is the know-how of one job, in a folder you can copy. ${skills.filter((k) => k.you_can_launch).length} of the ${skills.length} can be launched by you, with a slash.</p>
    <div class="grid g3">${skills.map(card).join('') || '<div class="card empty">No skill in .claude/skills/.</div>'}</div>`;
}

function viewFile(path) {
  const f = S.file;
  const crumbs = path.split('/').map((p) => esc(p)).join(' / ');
  if (!f || S.filePath !== path) return `<div class="crumb">${crumbs}</div><p class="muted">Reading...</p>`;
  if (f.error) return `<div class="crumb">${crumbs}</div><div class="card empty">${esc(f.error)}</div>`;
  let body;
  if (/\.md$/.test(path)) body = md(f.text);
  else if (/\.jsonl?$/.test(path)) { let t = f.text; try { if (/\.json$/.test(path)) t = JSON.stringify(JSON.parse(f.text), null, 2); } catch (e) { /* show as is */ } body = `<pre>${esc(t)}</pre>`; }
  else body = `<pre>${esc(f.text)}</pre>`;
  return `<div class="crumb">${crumbs} <span style="margin-left:10px">· changed ${when(f.mtime)} · read-only</span></div><div class="card md">${body}</div>`;
}

/* ---------------------------------------------------------------- render, events, refresh */

function render() {
  if (!S.data) return;
  if (S.data.error) { $('#main').innerHTML = `<div class="card empty">${esc(S.data.error)}</div>`; return; }
  renderSide();
  renderPill();
  const r = route();
  const views = { home: viewHome, team: viewTeam, agent: () => viewAgent(r.arg), step: () => viewStep(r.arg), memory: viewMemory, loop: viewLoop,
    routines: viewRoutines, runs: viewRuns, skills: viewSkills, file: () => viewFile(r.arg) };
  $('#main').innerHTML = (views[r.page] || viewHome)();
  document.title = 'Mission Control' + (openItems().length ? ` (${openItems().length})` : '');
}

async function loadFile(path) {
  try {
    const res = await fetch('/api/file?path=' + encodeURIComponent(path));
    const data = await res.json();
    const changed = S.filePath !== path || !S.file || S.file.text !== data.text || S.file.error !== data.error;
    S.file = data;
    S.filePath = path;
    if (changed && route().page === 'file' && route().arg === path) render();
  } catch (e) { /* the server is away: keep what is shown */ }
}

/* The page is not redrawn while you type in it, nor in the instant of a click: what you wrote stays. */
const typing = () => !!document.querySelector('#main textarea:focus, #main input[type=text]:focus');
function redraw(force) {
  if (!S.dirty) return;
  if (!force && (typing() || Date.now() - S.hold < 700)) return;
  S.dirty = false;
  render();
}

/* The text of each file an open item asks you to read. Asked once per file and per change of the file. */
async function loadPreviews() {
  for (const q of openItems().filter((x) => x.file && x.file_ok)) {
    const key = previewKey(q);
    if (S.previews[key] || S.loading[key]) continue;
    S.loading[key] = true;
    try {
      const res = await fetch('/api/file?path=' + encodeURIComponent(q.file));
      const data = await res.json();
      let text = String(data.text || '').replace(/\r\n/g, '\n');
      if (/\.json$/.test(q.file)) { try { text = JSON.stringify(JSON.parse(text), null, 2); } catch (e) { /* show as is */ } }
      S.previews[key] = data.error ? { error: data.error } : { text };
      S.dirty = true;
    } catch (e) { /* the server is away: ask again at the next turn */ }
    delete S.loading[key];
  }
  redraw();
}

async function poll(force) {
  try {
    const res = await fetch('/api/state');
    const text = (await res.text()).replace(/"generated":\s*"[^"]*",?/, '');
    if (text !== S.raw) { S.raw = text; S.data = JSON.parse(text); S.dirty = true; }
    redraw(force);
    const r = route();
    if (r.page === 'file') loadFile(r.arg);
    if (!S.data.error) loadPreviews();
  } catch (e) { /* the server is away: keep what is shown */ }
}

async function decide(id, choice, change) {
  const field = document.querySelector(`[data-note="${CSS.escape(id)}"]`);
  const text = String((field && field.value) || S.drafts[id] || '').trim();
  if (change && !text) { toast('Write what to change first, then Send.'); return; }
  const body = change ? { id, decision: 'change: ' + text, note: '' } : { id, decision: choice, note: text };
  try {
    const res = await fetch('/api/queue/resolve', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Mission-Control': '1' }, body: JSON.stringify(body) });
    const data = await res.json();
    if (data.ok) { S.recorded[id] = true; delete S.drafts[id]; }
    toast(data.ok ? `Recorded. Now tell ${lead()}: continue.` : `Not recorded: ${data.message || data.error}`);
  } catch (e) { toast('The server did not answer.'); }
  S.dirty = true;
  poll(true);
}

document.addEventListener('click', (ev) => {
  const btn = ev.target.closest('[data-decide]');
  if (btn) { btn.disabled = true; decide(btn.dataset.decide, btn.dataset.choice, false); return; }
  const change = ev.target.closest('[data-change]');
  if (change) { decide(change.dataset.change, '', true); return; }
  const more = ev.target.closest('[data-expand]');
  if (more) { S.expanded[more.dataset.expand] = !S.expanded[more.dataset.expand]; render(); return; }
  const go = ev.target.closest('[data-scroll]');
  if (go) { const el = document.getElementById(go.dataset.scroll); if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' }); return; }
  const fold = ev.target.closest('summary');
  if (fold && fold.parentElement.dataset.keep) S.folds[fold.parentElement.dataset.keep] = !fold.parentElement.open;
});
document.addEventListener('input', (ev) => {
  const field = ev.target.closest('[data-note]');
  if (field) S.drafts[field.dataset.note] = field.value;
});
document.addEventListener('mousedown', () => { S.hold = Date.now(); });
document.addEventListener('change', (ev) => {
  const sel = ev.target.closest('[data-filter]');
  if (sel) { S.filters[sel.dataset.filter] = sel.value; render(); }
});
window.addEventListener('hashchange', () => {
  const r = route();
  if (r.page === 'file') { S.file = null; loadFile(r.arg); }
  render();
  window.scrollTo(0, 0);
});

poll().then(() => { const r = route(); if (r.page === 'file') loadFile(r.arg); });
setInterval(() => { if (!document.hidden) poll(); }, 2500);
setInterval(() => document.querySelectorAll('[data-since]').forEach((el) => { el.textContent = lasted(el.dataset.since); }), 20000);
