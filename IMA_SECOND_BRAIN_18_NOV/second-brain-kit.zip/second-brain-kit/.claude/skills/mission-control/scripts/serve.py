﻿#!/usr/bin/env python3
"""Mission Control: one screen for a team of agents that works on plain files.

  python .claude/skills/mission-control/scripts/serve.py [--port 8770] [--project .] [--open]
  python .claude/skills/mission-control/scripts/serve.py --journey    where you are, what waits, what is next
  python .claude/skills/mission-control/scripts/serve.py --check      what was found, and the checks of your computer

It reads, and never invents:
  .claude/agents/*.md          the team (front matter, and the "card" comment under it)
  .claude/skills/*/SKILL.md    the skills
  ops/runs/*.jsonl             one line per start and per stop of a run
  ops/queue.json               the "Waiting for you" queue
  ops/routines.json            the routines
  ops/method.json              the steps of the method (names, questions, colors)
  brain/**                     the active brain
  brains/*/BRAIN.md            the shelf
  brain/2-ears/library/state.json   what ops/tools/library.py filed from my-knowledge/
  my-documents/, my-knowledge/      how many files wait there (it counts them, it does not open them)
  ~/.claude.json               one yes or no: was the trust question answered for this folder
It writes one thing only: the decision of the human on a queue item, by calling
  .claude/skills/run-trace/scripts/queue.py resolve ID --decision "..." --via screen

It listens on 127.0.0.1 only. No external resource: it works offline.
Everything is optional: a project with only .claude/agents/ still gets its team page.
Standard library only.
"""
from __future__ import annotations

import argparse
import importlib.util
import json
import os
import re
import shutil
import subprocess
import sys
import time
import webbrowser
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

SKILL_DIR = Path(__file__).resolve().parents[1]
ASSETS = SKILL_DIR / "assets"
TEXT_TYPES = {".md", ".json", ".jsonl", ".txt", ".py", ".csv"}
MIME = {".html": "text/html", ".css": "text/css", ".js": "text/javascript", ".svg": "image/svg+xml",
        ".png": "image/png", ".ico": "image/x-icon"}
MAX_FILE = 600_000
PROJECT = Path.cwd()
STALE_AFTER = 45 * 60                                  # a start with no stop for 45 minutes: not running any more
STALE_TOOL = {"library": 45 * 60}                      # the same cut as library.py (STUCK_AFTER): its status and this screen agree
SYNCED = {"onedrive": "OneDrive", "dropbox": "Dropbox", "google drive": "Google Drive", "googledrive": "Google Drive",
          "my drive": "Google Drive", "icloud": "iCloud", "mobile documents": "iCloud"}
STEP_FOLDERS = ("1-self", "2-ears", "3-condense", "4-orient", "5-narrate", "6-debrief")
_CACHE: dict = {}


# ---------------------------------------------------------------- small readers

def read_text(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8-sig", errors="replace")
    except OSError:
        return ""


def read_json(path: Path, default):
    try:
        return json.loads(path.read_text(encoding="utf-8-sig"))
    except (OSError, ValueError):
        return default


def rel(path: Path) -> str:
    try:
        return path.resolve().relative_to(PROJECT).as_posix()
    except ValueError:
        return path.as_posix()


def mtime(path: Path) -> str:
    try:
        return datetime.fromtimestamp(path.stat().st_mtime).isoformat(timespec="seconds")
    except OSError:
        return ""


def cached(key: str, seconds: float, make):
    """Keep a slow answer for a few seconds: the page asks for the state every 2.5 seconds."""
    hit = _CACHE.get(key)
    now = time.monotonic()
    if hit and now - hit[0] < seconds:
        return hit[1]
    value = make()
    _CACHE[key] = (now, value)
    return value


def seconds_since(ts) -> float | None:
    """How long ago a time of the run log was. None: not a time."""
    try:
        then = datetime.fromisoformat(str(ts))
    except ValueError:
        return None
    if then.tzinfo is not None:
        then = then.astimezone().replace(tzinfo=None)
    return (datetime.now() - then).total_seconds()


def clock(ts) -> str:
    return str(ts or "")[11:16]


def lasted(seconds: float | None) -> str:
    if seconds is None:
        return ""
    minutes = int(max(0, seconds) // 60)
    if minutes < 1:
        return "less than a minute"
    return f"{minutes} min" if minutes < 60 else f"{minutes // 60} h {minutes % 60:02d} min"


def as_int(value) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return 0


def count_files(folder: Path, limit: int = 5000) -> int:
    """The files someone dropped in a folder: every file but the README and the hidden ones.
    They are counted, never opened."""
    def count() -> int:
        found = 0
        if not folder.is_dir():
            return 0
        try:
            for path in folder.rglob("*"):
                if any(part.startswith(".") for part in path.relative_to(folder).parts) or path.name.lower() == "readme.md":
                    continue
                if path.is_file():
                    found += 1
                    if found >= limit:
                        break
        except OSError:
            pass
        return found
    return cached(f"count:{folder}", 8, count)


def newest(paths) -> Path | None:
    """The file changed last, among the files given (no README, no hidden file)."""
    best, stamp = None, -1.0
    for path in paths:
        if path.name.startswith(".") or path.name.lower() == "readme.md":
            continue
        try:
            if path.is_file() and path.stat().st_mtime > stamp:
                best, stamp = path, path.stat().st_mtime
        except OSError:
            continue
    return best


def front_matter(text: str) -> tuple[dict, str]:
    """A small reader for the front matter of agent and skill files: "key: value" and "- item" lists."""
    match = re.match(r"^---\r?\n(.*?)\r?\n---\r?\n?(.*)$", text, re.S)
    if not match:
        return {}, text
    data: dict = {}
    key = None
    for line in match.group(1).splitlines():
        if re.match(r"^\s+-\s+", line) and key:
            if not isinstance(data.get(key), list):
                data[key] = []
            data[key].append(line.split("-", 1)[1].strip().strip("\"'"))
            continue
        found = re.match(r"^([A-Za-z][\w-]*):\s*(.*)$", line)
        if found:
            key = found.group(1)
            value = found.group(2).strip()
            data[key] = value.strip("\"'") if value else ""
        elif key and line.startswith(" ") and isinstance(data.get(key), str):
            data[key] = (data[key] + " " + line.strip()).strip()
    return data, match.group(2)


def as_list(value) -> list[str]:
    if isinstance(value, list):
        return [str(v) for v in value if str(v).strip()]
    if not value:
        return []
    text = str(value).strip().strip("[]")
    return [part.strip().strip("\"'") for part in re.split(r",(?![^(]*\))", text) if part.strip()]


def header_lines(text: str) -> dict:
    """The "- key: value" lines at the top of a file of the brain (before its first "##")."""
    out: dict = {}
    for line in text.split("\n## ", 1)[0].splitlines():
        found = re.match(r"^\s*[-*]\s+([A-Za-z][\w ]{0,30}):\s*(.*)$", line)
        if found:
            out[found.group(1).strip().lower().replace(" ", "_")] = found.group(2).strip()
    return out


def title_of(text: str, fallback: str = "") -> str:
    found = re.search(r"^#\s+(.+)$", text, re.M)
    return found.group(1).strip() if found else fallback


def table_rows(text: str) -> list[dict]:
    """The first markdown table of a text, as a list of rows."""
    rows, header = [], None
    for line in text.splitlines():
        line = line.strip()
        if not line.startswith("|"):
            if header and rows:
                break
            continue
        cells = [c.strip() for c in line.strip("|").split("|")]
        if header is None:
            header = [c.lower() for c in cells]
        elif all(re.fullmatch(r":?-{2,}:?", c) for c in cells):
            continue
        else:
            rows.append({header[i]: cells[i] if i < len(cells) else "" for i in range(len(header))})
    return rows


# ---------------------------------------------------------------- the team

def read_card(text: str) -> dict:
    found = re.search(r"<!--\s*card\s*\n(.*?)-->", text, re.S)
    card: dict = {}
    if found:
        for line in found.group(1).splitlines():
            if ":" in line:
                key, value = line.split(":", 1)
                card[key.strip().lower()] = value.strip()
    return card


def read_agents() -> list[dict]:
    agents = []
    folder = PROJECT / ".claude" / "agents"
    for path in sorted(folder.glob("*.md")) if folder.is_dir() else []:
        text = read_text(path)
        meta, _body = front_matter(text)
        card = read_card(text)
        name = meta.get("name") or path.stem
        first = card.get("first_name") or name.replace("-", " ").title()
        title = card.get("title", "")
        role = re.sub(r"^(the|a|an)\s+", "", title.strip(), flags=re.I)
        words = ([first, role] if role else name.replace("-", " ").split()) or ["?"]
        initials = (words[0][:1] + (words[1][:1] if len(words) > 1 else "")).upper()
        agents.append({
            "name": name, "file": rel(path), "first_name": first, "title": title, "initials": initials,
            "step": (card.get("step") or "").upper(), "kind": (card.get("kind") or "worker").lower(),
            "tagline": card.get("tagline") or "", "reads": card.get("reads", ""), "writes": card.get("writes", ""),
            "checked_by": card.get("checked_by", ""), "reviews": card.get("reviews", ""),
            "runs": card.get("runs", ""), "has_card": bool(card),
            "description": meta.get("description", ""), "model": meta.get("model", ""),
            "tools": as_list(meta.get("tools")), "skills": as_list(meta.get("skills")),
        })
    # The order inside a step: the list "agents" of the step in ops/method.json when it exists,
    # then the workers before the reviewers, then the name.
    method = read_json(PROJECT / "ops" / "method.json", {})
    wanted: list[str] = []
    for step in (method.get("steps") or []) if isinstance(method, dict) else []:
        wanted += [str(n).lower() for n in step.get("agents", [])] if isinstance(step, dict) else []
    rank = {name: i for i, name in enumerate(wanted)}
    agents.sort(key=lambda a: (rank.get(a["name"], 999), a["kind"] == "reviewer", a["name"]))
    return agents


def read_skills(agents: list[dict]) -> list[dict]:
    skills = []
    folder = PROJECT / ".claude" / "skills"
    for path in sorted(folder.glob("*/SKILL.md")) if folder.is_dir() else []:
        meta, _body = front_matter(read_text(path))
        name = meta.get("name") or path.parent.name
        launch = str(meta.get("user-invocable", "true")).lower() != "false"
        skills.append({
            "name": name, "file": rel(path), "description": meta.get("description", ""),
            "you_can_launch": launch,
            "used_by": [a["name"] for a in agents if name in a["skills"]],
            "has_scripts": (path.parent / "scripts").is_dir(),
        })
    return skills


# ---------------------------------------------------------------- runs and queue

def read_runs(limit: int = 600) -> list[dict]:
    """The run records, newest first. Two records of the same second keep the order of the file."""
    keyed = []
    folder = PROJECT / "ops" / "runs"
    files = sorted(folder.glob("*.jsonl"))[-30:] if folder.is_dir() else []
    for path in files:                                   # oldest file first: the log is append-only
        for line in read_text(path).splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                record = json.loads(line)
            except ValueError:
                continue
            if isinstance(record, dict) and record.get("agent"):
                keyed.append((str(record.get("ts", "")), len(keyed), record))
    keyed.sort(key=lambda item: (item[0], item[1]), reverse=True)
    return [record for _, _, record in keyed[:limit]]


def agent_status(runs: list[dict]) -> dict:
    """For each agent: is it running, and what did its last run say."""
    status: dict = {}
    for record in reversed(runs):                      # oldest first
        name = str(record.get("agent", "")).lower()
        entry = status.setdefault(name, {"state": "idle", "runs": 0})
        if record.get("source") == "tool":             # a script with no AI (the radar, the library), not an agent
            entry["tool"] = True
        if record.get("event") == "start":
            entry.update(state="running", started=record.get("ts"), summary=record.get("summary") or "")
        elif record.get("event") == "stop":
            entry["runs"] += 1
            entry.update(state=record.get("status") or "done", last=record.get("ts"),
                         summary=record.get("summary") or "", verdict=record.get("verdict"),
                         outputs=record.get("outputs") or [], routine=record.get("routine"))
    for name, entry in status.items():
        if entry["state"] == "running":
            age = seconds_since(entry.get("started")) or 0
            if age > STALE_TOOL.get(name, STALE_AFTER):   # a start with no stop for too long: not running any more
                entry["state"] = "unknown"
    return status


def read_queue(runs: list[dict] | None = None) -> list[dict]:
    """The queue. For an item with a file: can the screen show it, and when did it change.
    For a decided item: did an agent start after the decision (the work went on)."""
    data = read_json(PROJECT / "ops" / "queue.json", {})
    items = data.get("items", []) if isinstance(data, dict) else []
    starts = [str(r.get("ts", "")) for r in runs or [] if r.get("event") == "start" and r.get("source") != "tool"]
    last_start = max(starts, default="")
    out = []
    for item in items:
        if not isinstance(item, dict):
            continue
        choices = item.get("choices") or []
        if isinstance(choices, str):
            choices = [c.strip() for c in choices.split("|") if c.strip()]
        entry = {**item, "choices": choices, "open": str(item.get("status", "open")).lower() == "open"}
        shown = safe_path(str(item.get("file") or ""))
        entry["file_ok"] = shown is not None
        entry["file_mtime"] = mtime(shown) if shown else ""
        decided = str(item.get("decided_ts") or "")
        age = seconds_since(decided) if decided else None
        entry["decided_recent"] = age is not None and age < 12 * 3600
        entry["moved_on"] = bool(item.get("applied")) or bool(decided and last_start[:19] > decided[:19])
        out.append(entry)
    return out


# ---------------------------------------------------------------- the brain

def brain_info(folder: Path) -> dict:
    text = read_text(folder / "BRAIN.md")
    info = header_lines(text)
    info["name"] = title_of(text, folder.name)
    info["folder"] = rel(folder)
    info["exists"] = folder.is_dir()
    info["sample_data"] = str(info.get("sample_data", "no")).lower().startswith("y")
    return info


def read_shelf() -> list[dict]:
    folder = PROJECT / "brains"
    shelf = []
    for path in sorted(folder.iterdir()) if folder.is_dir() else []:
        if path.is_dir():
            info = brain_info(path)
            info["template"] = path.name.startswith("_")
            shelf.append(info)
    return shelf


def read_tree(folder: Path, limit: int = 1500) -> list[dict]:
    files = []
    if not folder.is_dir():
        return files
    for path in sorted(folder.rglob("*")):
        if not path.is_file() or path.name.startswith(".") or path.suffix.lower() not in TEXT_TYPES:
            continue
        try:
            stat = path.stat()
        except OSError:
            continue
        files.append({"path": rel(path), "size": stat.st_size,
                      "mtime": datetime.fromtimestamp(stat.st_mtime).isoformat(timespec="seconds")})
        if len(files) >= limit:
            break
    return files


def verdict_of(path: Path) -> dict:
    text = read_text(path)
    head = header_lines(text)
    return {"path": rel(path), "title": title_of(text, path.stem), "verdict": head.get("verdict", ""),
            "reviewer": head.get("reviewer", ""), "date": head.get("date", ""), "loop": head.get("loop", ""),
            "score": head.get("score", head.get("likeness", "")), "mtime": mtime(path)}


def read_loop(brain: Path) -> dict:
    debrief = brain / "6-debrief"
    metrics = debrief / "metrics"
    scorecards = read_json(metrics / "scorecards.json", None)
    edits = read_json(metrics / "edits.json", None)
    if isinstance(edits, dict):
        for piece in edits.get("pieces", []) if isinstance(edits.get("pieces"), list) else []:
            piece["report"] = f"{rel(metrics)}/edits/{piece.get('slug', '')}.md"
    proposals = []
    changes = debrief / "changes"
    for path in sorted(changes.glob("*-proposal.md")) if changes.is_dir() else []:
        text = read_text(path)
        head = header_lines(text)
        change_id = head.get("id") or path.name.replace("-proposal.md", "")
        challenge = changes / f"{change_id}-challenge.md"
        proposals.append({
            "id": change_id, "title": re.sub(r"^Change\s+\S+:\s*", "", title_of(text, change_id)),
            "lever": head.get("lever", ""), "proposed_by": head.get("proposed_by", ""),
            "file": head.get("file", ""), "status": head.get("status", ""), "path": rel(path),
            "challenge": verdict_of(challenge) if challenge.is_file() else None,
        })
    cards = sorted((debrief / "reviews" / "posts").glob("*.md")) if (debrief / "reviews" / "posts").is_dir() else []
    weekly = sorted((debrief / "reviews").glob("*.md"), reverse=True) if (debrief / "reviews").is_dir() else []
    tests_dir = brain / "1-self" / "_tests"
    tests = [verdict_of(p) for p in sorted(tests_dir.glob("*.md"), reverse=True)] if tests_dir.is_dir() else []
    lessons_text = read_text(debrief / "lessons.md")
    return {
        "scorecards": scorecards, "edits": edits, "proposals": proposals,
        "ledger": table_rows(read_text(changes / "ledger.md")),
        "ledger_file": rel(changes / "ledger.md") if (changes / "ledger.md").is_file() else "",
        "cards": {p.stem: rel(p) for p in cards},
        "weekly": [{"path": rel(p), "title": title_of(read_text(p), p.stem)} for p in weekly],
        "lessons_file": rel(debrief / "lessons.md") if lessons_text else "",
        "lessons": len(re.findall(r"^###?\s+(?:Lesson\s+)?L?\d+", lessons_text, re.M)),
        "tests": tests,
    }


def read_reviews(brain: Path) -> list[dict]:
    """Every verdict file of the brain: fact-checks, draft reviews, Double tests, challenges."""
    found = []
    for pattern in ("3-condense/summaries/*/fact-check*.md", "5-narrate/drafts/*/review*.md",
                    "1-self/_tests/*.md", "6-debrief/changes/*-challenge.md"):
        for path in brain.glob(pattern):
            found.append(verdict_of(path))
    found.sort(key=lambda v: v["mtime"], reverse=True)
    return found


RADAR_RUN = re.compile(r"^Run of (\d\d:\d\d): (\d+) new item\(s\) from (\d+) source\(s\)"
                       r"(?:, (\d+) source\(s\) could not be read)?\.", re.M)


def read_radar(brain: Path) -> dict | None:
    """The daily radar of brain/2-ears/: its sources (radar.json), each run written by
    ops/tools/radar.py in radar/<date>.md, and Carl's shortlist of the same day. None: no radar."""
    ears = brain / "2-ears"
    config = read_json(ears / "radar.json", None)
    folder = ears / "radar"
    if not isinstance(config, dict) and not folder.is_dir():
        return None
    sources = []
    for s in (config or {}).get("sources") or []:
        if isinstance(s, dict):
            sources.append({"name": s.get("name") or s.get("id", ""), "kind": s.get("kind", ""),
                            "example": "example" in str(s.get("id", "")) or "example.org" in str(s.get("feed", ""))})
    days = []
    pages = sorted(folder.glob("????-??-??.md"), reverse=True)[:14] if folder.is_dir() else []
    for page in pages:
        runs = [{"time": m[0], "new": int(m[1]), "sources": int(m[2]), "failed": int(m[3] or 0)}
                for m in RADAR_RUN.findall(read_text(page))]
        shortlist = ears / "shortlist" / page.name
        head = read_text(shortlist)[:2000] if shortlist.is_file() else ""
        kept = re.search(r"(\d+) kept", head)
        scored = re.search(r"(\d+) items? of radar/", head)
        days.append({"date": page.stem, "page": rel(page), "runs": runs, "mtime": mtime(page),
                     "shortlist": rel(shortlist) if shortlist.is_file() else "",
                     "kept": int(kept[1]) if kept else None, "scored": int(scored[1]) if scored else None})
    return {"config": rel(ears / "radar.json") if isinstance(config, dict) else "",
            "sources": sources, "days": days}


# ---------------------------------------------------------------- the library: the owner's own knowledge

def library_flag(runs: list[dict], last_run) -> dict:
    """Is ops/tools/library.py running, finished or failed. From its lines in the run log
    ("agent": "library"), and from the last run it wrote in state.json when that one is newer."""
    last = next((r for r in runs if str(r.get("agent", "")).lower() == "library"), None)
    saved = last_run if isinstance(last_run, dict) else {}
    ended = str(saved.get("ended") or "")
    what = str(saved.get("what") or "")
    if last and not (ended and ended[:19] > str(last.get("ts", ""))[:19]):
        ts = str(last.get("ts", ""))
        if last.get("event") == "start":
            if (seconds_since(ts) or 0) > STALE_TOOL["library"]:
                return {"word": "stopped", "since": ts, "line": "It wrote a start line and no stop line: it was stopped on the way."}
            return {"word": "running", "since": ts, "line": str(last.get("summary") or "")}
        failed = str(last.get("status") or "").lower() in ("failed", "blocked")
        return {"word": "failed" if failed else "finished", "at": ts, "what": what,
                "line": str(last.get("summary") or saved.get("line") or "")}
    if ended:
        failed = str(saved.get("status") or "").lower() == "failed"
        return {"word": "failed" if failed else "finished", "at": ended, "what": what, "line": str(saved.get("line") or "")}
    return {"word": "not run yet", "line": ""}


def read_library(brain: Path, runs: list[dict], index: list[dict]) -> dict:
    """The owner's own knowledge: what waits in my-knowledge/, what ops/tools/library.py filed
    (brain/2-ears/library/state.json), what Condense digested, and whether the script runs now."""
    ears = brain / "2-ears"
    state_file = ears / "library" / "state.json"
    state = read_json(state_file, None)
    if not isinstance(state, dict):
        state = {}
    name = str(state.get("knowledge_dir") or "my-knowledge").strip("/\\ ")
    if not re.fullmatch(r"[\w .-]{1,60}", name) or name.startswith("."):
        name = "my-knowledge"
    documents = [d for d in state.get("documents") or [] if isinstance(d, dict)]
    slugs = {str(row.get("slug", "")) for row in index}
    totals = None
    if state:
        raw = state.get("totals") if isinstance(state.get("totals"), dict) else {}
        totals = {key: as_int(raw.get(key)) for key in ("folders", "files", "readable", "not_readable", "duplicates",
                                                         "private", "filed", "left_out", "waiting", "words")}
    folders = []
    for f in state.get("folders") or []:
        if isinstance(f, dict):
            folders.append({"folder": str(f.get("folder", "")), "status": str(f.get("status") or ""),
                            **{key: as_int(f.get(key)) for key in ("files", "readable", "not_readable", "duplicates",
                                                                    "private", "words", "filed")}})
    unread = [{"path": str(u.get("path", "")), "why": str(u.get("why", ""))}
              for u in state.get("not_readable") or [] if isinstance(u, dict)][:300]
    page = ears / "library.md"
    return {
        "state": rel(state_file) if state else "", "page": rel(page) if page.is_file() else "",
        "knowledge_dir": name, "has_folder": (PROJECT / name).is_dir(), "knowledge_files": count_files(PROJECT / name),
        "flag": library_flag(runs, state.get("last_run")),
        "totals": totals, "folders": folders, "not_readable": unread, "documents": len(documents),
        "digested": sum(1 for d in documents if d.get("slug") and str(d.get("slug")) in slugs),
        "pdf_reader": str(state.get("pdf_reader") or ""), "updated": str(state.get("updated") or ""),
    }


# ---------------------------------------------------------------- where you are, and what to do now

def same_as_template(path: Path, template: Path) -> bool:
    """True when a file of the brain is missing, empty, or still the text of the template."""
    text = read_text(path).replace("\r\n", "\n").strip()
    return not text or text == read_text(template).replace("\r\n", "\n").strip()


def latest_test(folder: Path) -> dict | None:
    """The newest Double test: by its date, then its loop, then the time of the file."""
    tests = [verdict_of(p) for p in sorted(folder.glob("*.md"))] if folder.is_dir() else []
    tests = [t for t in tests if t["verdict"]]
    tests.sort(key=lambda t: (t["date"], as_int(t["loop"]), t["mtime"]))
    return tests[-1] if tests else None


def step_state(folder: str, brain: Path, index: list[dict], loop: dict | None) -> tuple[str, str, str]:
    """One step: its state (built, in progress, not started), the file that proves it, and what
    that file says. From the files only. The rules go by the folder of the step."""
    base = brain / folder
    template = PROJECT / "brains" / "_template" / folder
    if folder == "1-self":
        test = latest_test(base / "_tests")
        if test and test["verdict"].upper().startswith("PASS"):
            return "built", test["path"], "the latest Double test says PASS" + (f", likeness {test['score']}" if test["score"] else "")
        if test:
            return "in progress", test["path"], f"the latest Double test says {test['verdict']}"
        if not same_as_template(base / "about-me.md", template / "about-me.md"):
            return "in progress", rel(base / "about-me.md"), "about-me.md is written, no Double test yet"
        return "not started", "", "about-me.md is not written yet"
    if folder == "2-ears":
        cards = [p for p in sorted((base / "inbox").glob("*.md")) if p.name.lower() != "readme.md"]
        if cards:
            return "built", rel(cards[-1]), f"{len(cards)} card(s) in the inbox"
        source = newest((base / "sources").glob("*.md"))
        page = newest((base / "radar").glob("*.md"))
        if source:
            return "in progress", rel(source), "a source is filed, no card in the inbox yet"
        if (base / "library" / "state.json").is_file():
            return "in progress", rel(base / "library" / "state.json"), "your knowledge was scanned, no card in the inbox yet"
        if page:
            return "in progress", rel(page), "the radar ran, no card in the inbox yet"
        if not same_as_template(base / "radar.json", template / "radar.json"):
            return "in progress", rel(base / "radar.json"), "your sources are written, no card in the inbox yet"
        return "not started", "", "no card in the inbox yet"
    if folder == "3-condense":
        checked = [r for r in index if str(r.get("status", "")).lower() in ("checked", "drafted", "used")]
        if checked:
            return "built", rel(base / "index.md"), f"{len(checked)} source(s) checked in the memory index"
        if index:
            return "in progress", rel(base / "index.md"), f"{len(index)} source(s) in the memory index, none checked yet"
        return "not started", "", "the memory index is empty"
    if folder == "4-orient":
        if (base / "plan.md").is_file():
            return "built", rel(base / "plan.md"), "the plan is written"
        return "not started", "", "no plan yet"
    if folder == "5-narrate":
        review = newest(base.glob("drafts/*/review*.md"))
        if review:
            return "built", rel(review), "a draft was reviewed"
        piece = newest(base.glob("drafts/*/piece.md"))
        if piece:
            return "in progress", rel(piece), "a draft is written, not reviewed yet"
        return "not started", "", "no draft yet"
    if folder == "6-debrief":
        lessons = (loop or {}).get("lessons") or 0
        if lessons:
            return "built", rel(base / "lessons.md"), f"{lessons} lesson(s) kept"
        weekly = newest((base / "reviews").glob("*.md"))
        if weekly:
            return "built", rel(weekly), "a weekly review is written"
        if (base / "metrics" / "scorecards.json").is_file():
            return "in progress", rel(base / "metrics" / "scorecards.json"), "the scorecards exist, no review yet"
        return "not started", "", "no result measured yet"
    return "", "", ""


def read_journey(brain: Path, method, agents: list[dict], skills: list[dict], index: list[dict],
                 loop: dict | None, queue: list[dict], status: dict) -> dict:
    """Where the owner is in the method, what waits, who runs, and what to do now.
    One answer for the home page and for --journey."""
    in_use = (brain / "BRAIN.md").is_file()
    skill_names = {s["name"] for s in skills}
    steps = []
    for step in (method.get("steps") or []) if isinstance(method, dict) else []:
        if not isinstance(step, dict) or str(step.get("folder")) not in STEP_FOLDERS:
            continue
        folder = str(step["folder"])
        state, proof, says = step_state(folder, brain, index, loop) if in_use else ("not started", "", "no brain in use")
        skill = "build-" + str(step.get("name", "")).lower()
        steps.append({"letter": str(step.get("letter", "")), "name": str(step.get("name", "")), "folder": folder,
                      "short": str(step.get("short", "")), "state": state, "proof": proof, "says": says,
                      "skill": skill if skill in skill_names else ""})
    todo = next((s for s in steps if s["state"] != "built"), None)
    lead = next((a for a in agents if a["kind"] == "governance"), None)
    boss = lead["first_name"] if lead else "your main agent"

    by_name = {a["name"]: a for a in agents}
    running = []
    for name, entry in status.items():
        if entry.get("state") != "running":
            continue
        agent = by_name.get(name)
        if agent:
            label = agent["first_name"] + (" (" + re.sub(r"^The ", "the ", agent["title"]) + ")" if agent["title"] else "")
        else:
            label = f"The {name} script (no AI)" if entry.get("tool") else name
        running.append({"name": name, "label": label, "since": str(entry.get("started") or ""),
                        "tool": bool(entry.get("tool")) and not agent, "summary": str(entry.get("summary") or "")})
    running.sort(key=lambda r: r["since"])
    waiting = [q for q in queue if q["open"]]
    to_apply = [q for q in queue if not q["open"] and q.get("via") == "screen" and q["decided_recent"] and not q["moved_on"]]

    step_line = f"Step {todo['letter']}, {todo['name']}" if todo else ""
    next_line = (step_line + (f" (/{todo['skill']})" if todo["skill"] else "")) if todo else "nothing to build, every step is built"
    now = None
    if waiting:
        many = len(waiting) > 1
        now = {"kind": "decide", "title": f"{len(waiting)} decision{'s' if many else ''} wait{'' if many else 's'} for you below",
               "text": "Read the file in each card, then choose. Nothing goes on without your answer.", "say": "", "since": ""}
    elif running:
        names = [r["label"] for r in running]
        who = names[0] if len(names) == 1 else ", ".join(names[:-1]) + " and " + names[-1]
        now = {"kind": "wait", "title": f"{who} {'is' if len(names) == 1 else 'are'} working since {clock(running[0]['since'])}",
               "text": f"Nothing to do: it will come back to you. Do not press Esc in {boss}'s window.",
               "say": "", "since": running[0]["since"]}
    elif steps:
        about = f": {todo['short']}" if todo and todo["short"] else ""
        if not in_use:
            text = f"No brain is in use yet. The first step is the Self: {boss} will start {step_line}{about}."
        elif to_apply:
            ids = ", ".join(str(q.get("id")) for q in to_apply)
            text = f"Your decision is recorded ({ids}). {boss} applies it" + (f", then goes on with {step_line}." if todo else ".")
        elif todo is None:
            text = f"Every step is built. Tell {boss} what you want: a memory question, a piece to write, the weekly review."
        elif todo["state"] == "in progress":
            text = f"{boss} will go on with {step_line}{about}."
        else:
            text = f"{boss} will start {step_line}{about}."
        say = "" if (todo is None and not to_apply) else "continue"
        now = {"kind": "continue", "title": f"Tell {boss}: continue" if say else "Nothing waits, nothing runs",
               "text": text, "say": say, "since": ""}
    return {"in_use": in_use, "steps": steps, "boss": boss, "running": running, "waiting": len(waiting),
            "to_apply": [str(q.get("id")) for q in to_apply],
            "next": {"letter": todo["letter"], "name": todo["name"], "skill": todo["skill"], "state": todo["state"]} if todo else None,
            "next_line": next_line, "now": now}


# ---------------------------------------------------------------- your computer

def trust_answer() -> str:
    """Was the trust question answered for this folder: "yes", "no" or "unknown".
    It reads one yes or no in the settings file of the agent tool, and nothing else of that file."""
    home = Path(os.environ.get("CLAUDE_CONFIG_DIR") or Path.home())
    data = read_json(home / ".claude.json", None)
    projects = data.get("projects") if isinstance(data, dict) else None
    if not isinstance(projects, dict):
        return "unknown"

    def norm(path) -> str:
        text = str(path).replace("\\", "/").rstrip("/")
        return text.lower() if os.name == "nt" else text

    wanted = {norm(p) for p in (PROJECT, *PROJECT.parents)}
    for key, value in projects.items():
        if norm(key) in wanted and isinstance(value, dict) and value.get("hasTrustDialogAccepted") is True:
            return "yes"
    return "no"


def find_pdf_reader() -> str:
    """A way to read a PDF on this machine: pdftotext (on the PATH, or in Git for Windows), or pypdf."""
    if shutil.which("pdftotext"):
        return "pdftotext"
    for root in (os.environ.get("ProgramFiles"), os.environ.get("ProgramW6432"), os.environ.get("ProgramFiles(x86)"),
                 os.path.join(os.environ.get("LOCALAPPDATA") or "", "Programs")):
        if root and (Path(root) / "Git" / "mingw64" / "bin" / "pdftotext.exe").is_file():
            return "pdftotext, in Git for Windows"
    try:
        if importlib.util.find_spec("pypdf"):
            return "pypdf"
    except (ImportError, ValueError):
        pass
    return ""


def read_computer(library: dict | None, self_built: bool) -> dict:
    """The few things of this machine that stop a first run. Each line: a mark (ok, todo, fix,
    unknown, info), the fact, and what to do when it is not OK."""
    facts = cached("computer", 20, lambda: {"claude": shutil.which("claude") is not None,
                                             "trust": trust_answer(), "pdf": find_pdf_reader()})
    lines: list[dict] = []

    def add(mark: str, fact: str, do: str = "") -> None:
        lines.append({"mark": mark, "fact": fact, "do": do})

    version = ".".join(str(n) for n in sys.version_info[:3])
    if sys.version_info >= (3, 9):
        add("ok", f"Python {version}")
    else:
        add("fix", f"Python {version} is too old", "Install Python 3 from python.org, then start the screen again.")
    if facts["claude"]:
        add("ok", "Claude Code is installed")
    else:
        add("fix", "Claude Code was not found", "Install Claude Code and sign in. Then open a new terminal and start the screen again.")
    synced = next((label for part in PROJECT.parts for word, label in SYNCED.items() if word in part.lower()), "")
    if synced:
        add("todo", f"This folder is inside {synced}",
            "Move the whole folder to a place that is not synced, for example C:\\second-brain. A sync can lock a file while the brain works.")
    else:
        add("ok", "This folder is not in a synced folder")
    if facts["trust"] == "yes":
        add("ok", "The trust question is answered for this folder")
    elif facts["trust"] == "no":
        add("todo", "The trust question is not answered for this folder",
            "Open a terminal in this folder, type claude, answer Yes, then type /exit. Without it you get many more questions.")
    else:
        add("unknown", "The trust question: unknown",
            "This screen could not read it. If you get many permission questions: type claude in this folder and answer Yes.")
    reader = facts["pdf"] or str((library or {}).get("pdf_reader") or "")
    if reader:
        add("ok", f"PDF files can be read ({reader})")
    else:
        add("todo", "No PDF reader was found",
            "A PDF will be listed as not readable. Save it as .txt or .md, or install Git for Windows, which brings one.")
    mine = count_files(PROJECT / "my-documents")
    if mine:
        add("ok", f"{mine} file(s) in my-documents/")
    elif self_built:
        add("info", "No file in my-documents/")
    else:
        add("todo", "No file in my-documents/",
            "Before the Self step, put your CV, a short bio and 5 to 10 pieces you wrote in the folder my-documents.")
    name = (library or {}).get("knowledge_dir") or "my-knowledge"
    known = (library or {}).get("knowledge_files") if library else count_files(PROJECT / name)
    if known:
        add("ok", f"{known} file(s) in {name}/")
    else:
        add("info", f"No file in {name}/",
            f"When you want: put what you know (a book, slides, notes) in the folder {name}. The Ears step files it, with your yes.")
    return {"open": not self_built, "lines": lines}


def build_state() -> dict:
    brain = PROJECT / "brain"
    agents = read_agents()
    skills = read_skills(agents)
    runs = read_runs()
    status = agent_status(runs)
    queue = read_queue(runs)
    method = read_json(PROJECT / "ops" / "method.json", {})
    index = table_rows(read_text(brain / "3-condense" / "index.md"))
    loop = read_loop(brain) if brain.is_dir() else None
    library = read_library(brain, runs, index) if brain.is_dir() else None
    journey = read_journey(brain, method, agents, skills, index, loop, queue, status)
    self_built = any(s["folder"] == "1-self" and s["state"] == "built" for s in journey["steps"])
    return {
        "generated": datetime.now().isoformat(timespec="seconds"),
        "project": PROJECT.name,
        "method": method,
        "routines": read_json(PROJECT / "ops" / "routines.json", []),
        "agents": agents,
        "skills": skills,
        "runs": runs,
        "status": status,
        "queue": queue,
        "brain": brain_info(brain),
        "shelf": read_shelf(),
        "index": index,
        "tree": read_tree(brain),
        "loop": loop,
        "reviews": read_reviews(brain) if brain.is_dir() else [],
        "radar": read_radar(brain) if brain.is_dir() else None,
        "library": library,
        "journey": journey,
        "computer": read_computer(library, self_built),
    }


# ---------------------------------------------------------------- files and decisions

def safe_path(text: str) -> Path | None:
    """A file of the project that the screen may show. Nothing outside, nothing secret."""
    if not text or "\x00" in text:
        return None
    path = (PROJECT / text).resolve()
    try:
        parts = path.relative_to(PROJECT).parts
    except ValueError:
        return None
    if not parts or path.suffix.lower() not in TEXT_TYPES or not path.is_file():
        return None
    if parts[0] == ".claude":
        return path if len(parts) > 1 and parts[1] in ("agents", "skills") else None
    if any(part.startswith(".") for part in parts) or parts[0] in ("node_modules", "demo"):
        return None
    return path


def resolve_item(item_id: str, decision: str, note: str) -> tuple[bool, str]:
    script = PROJECT / ".claude" / "skills" / "run-trace" / "scripts" / "queue.py"
    if not script.is_file():
        return False, "The skill run-trace is not installed: no queue.py to record the decision."
    if not re.fullmatch(r"[\w.-]{1,40}", item_id) or not decision.strip():
        return False, "A decision needs the id of the item and the choice."
    command = [sys.executable, str(script), "resolve", item_id, "--decision", " ".join(decision.split())[:2000]]
    if note.strip():
        command += ["--note", " ".join(note.split())[:600]]
    done = None
    for extra in (["--via", "screen"], []):            # an older queue.py does not know --via: ask again without it
        try:
            done = subprocess.run(command + extra, cwd=PROJECT, capture_output=True, text=True, encoding="utf-8",
                                  errors="replace", timeout=20)
        except (OSError, subprocess.SubprocessError) as error:
            return False, f"queue.py did not run: {error}"
        if not (extra and done.returncode != 0 and "unrecognized arguments" in (done.stderr or "")):
            break
    message = (done.stdout or done.stderr or "").strip()
    return done.returncode == 0, message or ("recorded" if done.returncode == 0 else "queue.py refused")


# ---------------------------------------------------------------- the server

class Handler(BaseHTTPRequestHandler):
    server_version = "MissionControl/1.0"

    def log_message(self, *_args):                     # keep the terminal quiet
        return

    def local(self) -> bool:
        host = (self.headers.get("Host") or "").split(":")[0].lower()
        return host in ("127.0.0.1", "localhost")

    def send(self, code: int, body: bytes, kind: str):
        self.send_response(code)
        self.send_header("Content-Type", kind + ("; charset=utf-8" if kind.startswith(("text/", "application/json")) else ""))
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        self.wfile.write(body)

    def send_json(self, data, code: int = 200):
        self.send(code, json.dumps(data, ensure_ascii=False).encode("utf-8"), "application/json")

    def do_GET(self):
        if not self.local():
            return self.send_json({"error": "local use only"}, 403)
        url = urlparse(self.path)
        if url.path == "/api/state":
            try:
                return self.send_json(build_state())
            except Exception as error:                 # the screen must stay up while files are being written
                return self.send_json({"error": f"{type(error).__name__}: {error}"}, 500)
        if url.path == "/api/file":
            wanted = (parse_qs(url.query).get("path") or [""])[0]
            path = safe_path(wanted)
            if path is None:
                return self.send_json({"error": f"No such file to show: {wanted}"}, 404)
            if path.stat().st_size > MAX_FILE:
                return self.send_json({"error": f"{wanted} is too large to show here."}, 413)
            return self.send_json({"path": rel(path), "text": read_text(path), "mtime": mtime(path)})
        name = "index.html" if url.path in ("/", "/index.html") else url.path.lstrip("/")
        asset = (ASSETS / name).resolve()
        if ASSETS.resolve() in asset.parents and asset.is_file() and asset.suffix in MIME:
            return self.send(200, asset.read_bytes(), MIME[asset.suffix])
        return self.send_json({"error": "not found"}, 404)

    def do_POST(self):
        if not self.local() or self.headers.get("X-Mission-Control") != "1":
            return self.send_json({"error": "local use only"}, 403)
        if urlparse(self.path).path != "/api/queue/resolve":
            return self.send_json({"error": "not found"}, 404)
        try:
            length = min(int(self.headers.get("Content-Length") or 0), 20_000)
            data = json.loads(self.rfile.read(length).decode("utf-8") or "{}")
        except (ValueError, OSError):
            return self.send_json({"error": "The request was not readable."}, 400)
        ok, message = resolve_item(str(data.get("id", "")), str(data.get("decision", "")), str(data.get("note", "")))
        return self.send_json({"ok": ok, "message": message}, 200 if ok else 400)


def find_project(given: str | None) -> Path:
    if given:
        return Path(given).resolve()
    here = Path(__file__).resolve()
    if len(here.parents) > 4 and here.parents[3].name == ".claude":
        return here.parents[4]                         # <project>/.claude/skills/mission-control/scripts/serve.py
    return Path.cwd().resolve()


def print_journey(state: dict) -> None:
    """The same answer as the top of the home page, as plain text. The main agent runs it when the
    owner says "continue"."""
    journey, brain = state["journey"], state["brain"]
    if journey["in_use"]:
        print(f"Brain in use: {brain.get('id') or brain.get('name')} ({brain.get('name')}), in brain/")
    else:
        print("Brain in use: none (no brain/BRAIN.md). The first step is the Self.")
    for step in journey["steps"]:
        proof = f"Proof: {step['proof']} ({step['says']})" if step["proof"] else f"Why: {step['says']}"
        print(f"Step {step['letter']}, {step['name']}: {step['state']}. {proof}")
    waiting = [q for q in state["queue"] if q["open"]]
    print(f"Waiting for you: {len(waiting) or 'nothing'}")
    for q in waiting:
        print(f"  {q.get('id')}, from {q.get('from')}" + (f", file {q.get('file')}" if q.get("file") else "") + f": {q.get('ask')}")
    for q in state["queue"]:
        if str(q.get("id")) in journey["to_apply"]:
            print(f"Decided on the screen, not applied yet: {q.get('id')} = {q.get('decision')}")
    if journey["running"]:
        for run in journey["running"]:
            print(f"Running now: {run['label']}, since {clock(run['since'])} ({lasted(seconds_since(run['since']))})")
    else:
        print("Running now: nobody")
    print(f"Next: {journey['next_line']}")


def main() -> int:
    global PROJECT
    parser = argparse.ArgumentParser(description="Mission Control: the screen of a team of agents. Local only.")
    parser.add_argument("--port", type=int, default=8770)
    parser.add_argument("--project", help="the project folder (default: the one this skill is installed in)")
    parser.add_argument("--open", action="store_true", help="open the page in the browser")
    parser.add_argument("--check", action="store_true", help="read everything once, print what was found, and stop")
    parser.add_argument("--journey", action="store_true",
                        help="print where you are: each step, what waits, who runs, what is next, and stop")
    args = parser.parse_args()
    PROJECT = find_project(args.project)
    if not PROJECT.is_dir():
        print(f"No such project folder: {PROJECT}")
        return 1
    if args.check or args.journey:
        try:
            sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        except (AttributeError, ValueError):
            pass
    if args.journey:
        print_journey(build_state())
        return 0
    if args.check:
        state = build_state()
        open_items = sum(1 for item in state["queue"] if item["open"])
        without_card = [a["name"] for a in state["agents"] if not a["has_card"]]
        print(f"project: {PROJECT}")
        print(f"agents: {len(state['agents'])}, skills: {len(state['skills'])}, routines: {len(state['routines'])}")
        print(f"runs: {len(state['runs'])}, queue: {len(state['queue'])} ({open_items} open)")
        print(f"brain: {state['brain'].get('name')} ({'found' if state['brain']['exists'] else 'no brain/ folder'}), "
              f"files: {len(state['tree'])}, index lines: {len(state['index'])}, shelf: {len(state['shelf'])}")
        if without_card:
            print("agents with no card (the skill agent-card writes it): " + ", ".join(without_card))
        steps = state["journey"]["steps"]
        if steps:
            print("steps: " + ", ".join(f"{s['letter']} {s['state']}" for s in steps) + f". Next: {state['journey']['next_line']}")
        library = state["library"]
        if library:
            flag = library["flag"]
            moment = ""
            if flag.get("since"):
                moment = (" since " if flag["word"] == "running" else " without a stop line, started at ") + clock(flag["since"])
            elif flag.get("at"):
                moment = " at " + clock(flag["at"])
            print(f"your knowledge: {library['knowledge_files']} file(s) in {library['knowledge_dir']}/, "
                  f"{(library['totals'] or {}).get('filed', 0)} filed, {library['digested']} digested, "
                  f"the library script: {flag['word']}{moment}")
        print("your computer:")
        words = {"ok": "ok", "todo": "to do", "fix": "to fix", "unknown": "unknown", "info": "note"}
        for line in state["computer"]["lines"]:
            print(f"  [{words.get(line['mark'], line['mark'])}] {line['fact']}" + (f". {line['do']}" if line["do"] else ""))
        return 0
    try:
        server = ThreadingHTTPServer(("127.0.0.1", args.port), Handler)
    except OSError as error:
        print(f"Port {args.port} is not free ({error.strerror or error}). Try: --port {args.port + 1}")
        return 1
    address = f"http://127.0.0.1:{args.port}/"
    print(f"Mission Control: {address}   project: {PROJECT}   (Ctrl+C to stop)")
    if args.open:
        webbrowser.open(address)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopped.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
