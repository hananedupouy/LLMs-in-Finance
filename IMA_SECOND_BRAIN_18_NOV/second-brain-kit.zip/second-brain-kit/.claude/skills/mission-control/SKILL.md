---
name: mission-control
description: Start, check or install Mission Control, the local screen of a team of agents. It shows where the human is in the method and what to do now, what waits for the human with the file to read, who is running and since when, the human's own knowledge, the team chart, the memory, the feedback loop, the routines, the run log and the skills, read live from the files of the project. Use it when the owner says "start the screen", "open Mission Control", "show me the team", or wants the same screen in another project. Launch it yourself with /mission-control. It reads files and writes one thing only, the decision of the human on a queue item.
---

# Mission Control: the screen of the team

## When to use
- The owner wants to see the team, what waits for them, or where a result is.
- A new project has agents in `.claude/agents/` and wants the same screen.
- The screen is open but looks wrong or empty: run the check below.
- Not to change how the screen looks (skill `mission-control-design`). Not to write the card of
  an agent (skill `agent-card`).

## What it is
One small Python server (standard library, no install) and one page. Everything travels in this
folder: copy `.claude/skills/mission-control/` into another project and the screen works there.

    python .claude/skills/mission-control/scripts/serve.py            start, on http://127.0.0.1:8770/
    python .claude/skills/mission-control/scripts/serve.py --open     start and open the browser
    python .claude/skills/mission-control/scripts/serve.py --check    read everything once, say what was found, check your computer
    python .claude/skills/mission-control/scripts/serve.py --port 8771 --project PATH

`--journey` prints, as plain text, what the top of the home page shows: the brain in use, one line
per step (built, in progress or not started, with the file that proves it), what waits, who runs,
and a last line `Next: Step E, Ears (/build-ears)`. The main agent runs it when the owner says
"continue".

It listens on this machine only (127.0.0.1). It loads nothing from the internet: it works offline.

## What it reads
Everything is optional. A page with no data says what is missing and how to create it.

| File | Gives | Written by |
|---|---|---|
| `.claude/agents/*.md` | the team: the front matter, and the card under it | you, the skill `agent-card` |
| `.claude/skills/*/SKILL.md` | the skills, who uses them, which ones you can launch | you |
| `ops/method.json` | the steps, their questions, their colors, the order of the agents | you |
| `ops/routines.json` | the routines: when, the chain, the phrase to say | you |
| `ops/runs/*.jsonl` | every run: one start line, one stop line | the skill `run-trace` |
| `ops/queue.json` | "Waiting for you" | the skill `run-trace` (`queue.py`) |
| `brain/**` | the memory, the index, the results, the changes, and where you are in the method | the agents |
| `brains/*/BRAIN.md` | the shelf: the brains not in use | you |
| `brain/2-ears/library/state.json` | your knowledge: what was filed, what waits, folder by folder | `ops/tools/library.py` |
| `my-documents/`, `my-knowledge/` | how many files wait there. They are counted, never opened | you |
| the settings file of the agent tool, in your home folder | one yes or no: is the trust question answered for this folder | the agent tool |

## What the home page shows
In this order:
1. **Where you are.** The six steps, each `built`, `in progress` or `not started`, read from the
   files. Click a state to open the file that proves it.
2. **What to do now.** One sentence: decide (N decisions wait), or wait (an agent or a script is
   running, since when), or tell the main agent "continue" and the step it will start.
3. **Your computer.** Python, the agent tool, a synced folder, the trust question, a PDF reader,
   the files in `my-documents/` and `my-knowledge/`. Open until the Self is built, folded after.
4. **Waiting for you.** Each card shows the file to read (40 lines, then all of it), the choices of
   the agent as buttons, and a box "Change something".
5. **Running now.** Each agent and each script (tag "tool"), since when and for how long.

On the page E · Ears, the card "Your knowledge" says whether `ops/tools/library.py` is RUNNING
NOW, FINISHED or FAILED, from its lines in the run log, with the totals and the folders.

## Steps
1. **Check first.** Run `serve.py --check`. It prints the number of agents, skills, runs, queue
   items and files it found, the agents that have no card, the state of each step, and the checks
   of your computer with what to do for each one that is not OK.
2. **Start it.** Run `serve.py --open` in a terminal that stays open. Tell the owner the address.
   The port is taken: the script says so, start again with `--port 8771`.
3. **Read the screen with the owner**, in this order:
   - Mission Control: where you are, what to do now, then "Waiting for you". Each card is a gate:
     it shows the file to read and the choices.
   - AI Team: the human on top, the headquarters, the six steps, the reviewers on the right.
   - The Loop: the seven stages, the triggers, the proposals, the ledger.
4. **A decision on the screen.** Clicking a choice records the decision in the queue (through
   `queue.py resolve ... --via screen`). The box "Change something" records `change:` and the
   owner's words. It applies nothing, and a click cannot wake the terminal: the card then says
   "Recorded. Now tell Alfred: continue." (the first name of your main agent, read from its card).
   The agent that owns the file applies the decision.
5. **Refresh.** Nothing to do: the page asks for the state every 2.5 seconds and redraws when a
   file changed. Changes to `serve.py` itself need a restart.

## Install it in another project
1. Copy the folder `.claude/skills/mission-control/` there.
2. Run `serve.py --check` from the root of that project.
3. For the status dots and the run log: copy the skill `run-trace` too.
4. For the chart by step: add `ops/method.json` (copy the one of this project and edit it), and
   give each agent a card (skill `agent-card`). Without them the chart shows one group.

## Check before you finish
- [ ] `serve.py --check` listed every agent, and none "with no card".
- [ ] The page opens, and the pill at the top right names the active brain.
- [ ] You told the owner the address, and that the terminal must stay open.
- [ ] You did not start a second server on the same port.

## Common mistakes
| Mistake | What happens | Do this instead |
|---|---|---|
| Starting it from another folder with no `--project` | It still finds the project it is installed in | Fine. Use `--project` only for another project |
| Expecting a click to apply a change | Nothing changes in the brain | The click records the decision. Say "continue" to the main agent: the agent applies it |
| Pressing Esc in the main agent's window while an agent works | The agent is stopped, its work is lost | Look at "Running now": wait for it to come back |
| Editing the queue or the index by hand to "fix" the screen | The tools and the screen disagree | Use `queue.py`, `memory_index.py`, `ledger.py` |
| Opening it to the network | Your files are readable by others | It binds to 127.0.0.1 on purpose. Leave it |
| An agent shows a grey dot forever | It never wrote its stop line | Its agent file must call `log_run.py` (skill `run-trace`) |
