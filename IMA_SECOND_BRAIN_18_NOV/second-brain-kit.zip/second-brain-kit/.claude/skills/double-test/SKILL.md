---
name: double-test
description: How Sosie, the Double, tests the Self files. She writes three short pieces as the owner using only brain/1-self/ and no real piece, lists what the files failed to tell her about the voice and the limits, lists apart the knowledge the pieces needed (it never lowers the score), and gives a likeness score out of 100 with its reasons and a verdict PASS, FIX or BLOCK in brain/1-self/_tests/. Use it at the end of Onboarding, every quarter, and after any change to the voice, the pillars or the writing rules, to compare with the earlier score.
user-invocable: false
---

# The Double test

## When to use
- The Self files were just written or completed: are they enough to imitate the owner?
- A change was applied to `voice.md`, `pillars.md` or `writing/<kind>.md`: the likeness must
  not drop (stage 7 of the feedback loop).
- Every quarter: a score that falls means the owner's voice moved and the files did not.
- Not to review a draft (that is Nora, with `edit-review`). Not to repair a Self file.

## Inputs
- The Self files, and nothing else: `brain/1-self/about-me.md`, `voice.md`, `pillars.md`,
  `rules.md`, `not-me.md`, `writing/<kind>.md`. And `brain/BRAIN.md` for the `piece_kinds`.
- Three subjects, from your task. None given: one subject from each of three pillars. For a
  test after a change: the same three subjects as the last test, and the id of the change.
- Forbidden before the pieces are scored: `brain/1-self/_raw/`, `brain/5-narrate/`,
  `brain/3-condense/`, and the earlier reports of `brain/1-self/_tests/`.

## Steps
1. **Read the Self files in full.** A file is missing, empty, or still the template with its
   guiding lines: note it, it is a finding. `voice.md`, `about-me.md` or the writing rules of
   the kind in that state: BLOCK, write no piece.
2. **Write three short pieces**, one per subject, of the first kind of `piece_kinds`: about 100
   to 150 words each, or the shortest length the writing rules allow. Write as the owner would,
   from what the files say. No fact, no story, no figure that is not in the files.
   You test how the owner sounds and what the owner refuses. You do not test what the owner
   knows. Where a piece needs a fact about its subject that the Self does not hold (a figure, a
   lab, something the owner built), write `[missing: ask the owner]` in its place and go on.
3. **Keep two lists while you write.** They are not the same thing.
   - **Gaps in the Self.** Each time you had to decide how the owner would do it and the files
     did not say: the decision, the file that should have said it, what you guessed. They count.
   - **Knowledge the pieces needed.** Each `[missing: ask the owner]`: the fact, and for which
     piece. They never count. The Self is a portrait: what the owner knows lives in the memory
     (`my-knowledge/`, filed at Step E). No Self file should grow to hold it.
4. **Score each piece on ten points.**

   | # | Point | The files told you... |
   |---|---|---|
   | 1 | The opening | how the owner starts a piece |
   | 2 | Rhythm | the length of the sentences and of the paragraphs |
   | 3 | Words | the vocabulary, and the never-use words |
   | 4 | Signature phrases | at least one, quoted exactly, with where it fits |
   | 5 | Structure | the parts and their order for this kind of piece |
   | 6 | Length | the limits for this kind of piece |
   | 7 | Point of view | who speaks, to whom, how personal |
   | 8 | Subject and angle | the pillar, its promise, its audience |
   | 9 | Substance | which kind of proof the owner uses (a story, a figure, a failure) and which stories and beliefs of `about-me.md` fit |
   | 10 | The ending | how the owner closes |

   For each point: 1 when a line of the files told you exactly how (you can quote it). 0.5
   when the files gave only a general word ("direct", "warm") and you interpreted. 0 when the
   files said nothing and you guessed. Likeness = the 30 marks added, divided by 30, times 100,
   rounded. A `[missing: ask the owner]` never lowers a mark: point 9 is marked on what the
   files say about the owner's stories, beliefs and way of proving, not on the facts of a subject.
5. **Turn the gaps in the Self into findings.** The knowledge list gives no finding.
   - `blocker`: a core file missing or empty, or two Self files that contradict each other.
   - `major`: a point at 0 in two pieces or more. After a change: any drop of the score.
   - `minor`: a point at 0.5, or at 0 in one piece only.
6. **Only now open the latest earlier report** in `brain/1-self/_tests/`. Copy its score and
   its date. Compute the difference.
7. **Decide.**

   | Verdict | When |
   |---|---|
   | BLOCK | a blocker, or a likeness under 50, or a drop of 5 points or more after a change |
   | FIX | no blocker, and a likeness from 50 to 79 or at least one major |
   | PASS | a likeness of 80 or more, no blocker, no major |

8. **Write the report**, add the queue line, stop. The owner's answer is the real result.

## Output format
`brain/1-self/_tests/<date>-double-test.md` (a second test the same day: `<date>-double-test-2.md`),
in the format of `review-verdict`, with your own lines and sections:

    # Review of brain/1-self/
    - reviewer: sosie
    - date: 2026-11-13
    - verdict: PASS | FIX | BLOCK
    - loop: 1
    - score: 74
    - previous: 71 (2026-11-02) | none
    - after_change: 2026-11-writing-01 | none
    - subjects: <subject 1> / <subject 2> / <subject 3>

    ## Findings
    | # | Level | Where (exact quote) | Problem | Evidence (exact quote of the source or rule) |
    |---|---|---|---|---|
    | 1 | major | voice.md: "Tone: direct" | No sample of an opening. I guessed a question | writing/<kind>.md: missing, no rule on the opening |

    ## Not checked
    - Whether the pieces sound like the owner: only the owner can say.

    ## The three pieces
    ### Piece 1: <subject> (pillar: <name>)
    <the text>

    ## Score detail
    | Point | Piece 1 | Piece 2 | Piece 3 |
    |---|---|---|---|
    | 1 The opening | 0.5 | 0.5 | 0 |

    ## What to complete
    - <file>: <what is missing>. Keeper of the file: <sofia, sacha or serena>

    ## Knowledge the pieces needed (not a gap of the Self, not in the score)
    - Piece 2: <the fact that was missing>. Where it belongs: the memory, from my-knowledge/

Save the file with the Write tool, never with a shell command. Its name is fixed above: never a
name that starts with "report", "summary", "findings" or "analysis", an agent tool may refuse it.

Queue line (the choices change when the score dropped after a change, see your agent file):

    python .claude/skills/run-trace/scripts/queue.py add --from sosie --ask "Double test, likeness 74: could you have written these three pieces?" --file brain/1-self/_tests/<date>-double-test.md --choices "yes, it sounds like me|close, see my notes|no, it's not me"

## Check before you finish
- [ ] You opened no real piece, no draft, no summary, no file of `_raw/`.
- [ ] Each mark of 1 can be backed by a line of a Self file. Each 0 is in the gap list.
- [ ] The score is the sum of the table, not an impression.
- [ ] Every finding names the file that should be completed, and who keeps it.
- [ ] The earlier score was read after yours was fixed, and the report gives the difference.
- [ ] You changed no Self file.

## Common mistakes
| Mistake | What happens | Do this instead |
|---|---|---|
| Reading real pieces "to calibrate" | You test your memory, not the files | The Self files only |
| Writing well instead of writing as the files say | A high score for generic text | A guess is marked 0 and listed |
| Inventing a personal moment | A false story under the owner's name | Use only what `about-me.md` states |
| Proposing the new wording of a rule | You become an author of the Self | Name the gap and the keeper |
| Counting "no facts about the subject" as a gap | The portrait swells into a catalogue of everything the owner built | `[missing: ask the owner]`, the second list, no mark lost |
