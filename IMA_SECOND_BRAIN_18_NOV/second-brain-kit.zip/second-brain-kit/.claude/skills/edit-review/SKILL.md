---
name: edit-review
description: How Nora, the Editor, reviews a draft with fresh eyes. Check every fact against the source or summary, then the draft against voice.md, rules.md, not-me.md, the writing rules of the kind and the lessons. Each finding quotes the rule or lesson it breaks. Verdict PASS, FIX or BLOCK in review.md, two loops at most, then the queue line "read the draft". Use it to review any draft of a piece before the owner reads it. Never to rewrite one.
user-invocable: false
---

# Review a draft

## When to use
- A draft `brain/5-narrate/drafts/<slug>/piece.md` exists and nobody but its writer has read it.
- A revision came back after a FIX: this is loop 2, the last one.
- Not to write or improve a draft. A reviewer who rewrites becomes a second author, and then
  nobody reviews.

## Inputs
You read three things only, with an empty context:
1. The artifact: `brain/5-narrate/drafts/<slug>/piece.md`. You judge the text under `## Text`.
   The header above it is the writer's claim (pillar, source, length, lessons applied): check
   it, do not trust it.
2. The source it claims: the summary `brain/3-condense/summaries/<slug>/condensed.md`, or the
   source named in the header or in your task.
3. The owner's rules: `brain/1-self/voice.md`, `rules.md`, `not-me.md`,
   `brain/1-self/writing/<kind>.md`, `brain/6-debrief/lessons.md`. `about-me.md` only to check
   a personal experience.

Not the writer's message, not her reasoning. The loop number: 1 if there is no `review.md` yet.

## Steps
1. **Truth, first.** List every fact of the draft: each number, name, date, quote, and each
   claim about what someone did or said. Find each one in the source and keep the source line.
   - It contradicts the source: blocker.
   - It is not in the source: major (cut it or source it). Still there at loop 2: blocker.
   - A personal experience, or something the owner built, taught or measured, that is not in
     `about-me.md`, in the owner's note or in the checked knowledge card of the owner that the
     header names on its line `Also from:`: blocker.
   - A `[missing: ask the owner: ...]` left in the text is not a finding. Copy each one into
     the queue ask: the owner fills it, nobody else.
   - The source cannot be opened: you cannot verify. BLOCK, and say so under "Not checked".
2. **Limits.** Each "never" of `rules.md`, each entry of `not-me.md`. Crossed: blocker.
   Each word under "Private words" of `rules.md`: search the draft with Grep. Found: blocker.
3. **Voice.** Search the draft for each never-use word of `voice.md`. Then tone and habits
   against its dos and don'ts. Quote the line of `voice.md`.
4. **Shape.** Each rule of `writing/<kind>.md`: opening, structure, closing, limits. Measure
   the length, never estimate it and never copy it from the header:
   `python -c "t=open(r'brain/5-narrate/drafts/<slug>/piece.md', encoding='utf-8').read().split('## Text',1)[-1].strip(); print(len(t), 'characters,', len(t.split()), 'words')"`
   One idea only: if you can name two, it is a finding.
5. **The top alone.** Read the opening with nothing after it, then the opening, the headings
   and the first words of each paragraph. Do they carry the piece? If not: major when the
   writing rules ask for it, minor otherwise.
6. **Lessons.** Each lesson of `lessons.md` that is not retired: respected, not applicable, or
   broken. Broken: quote the lesson. A lesson that contradicts `rules.md` loses: no finding
   against the draft, and name the conflict in your final message.
7. **Decide**, by the levels of `review-verdict`.

   | Verdict | When | What happens next |
   |---|---|---|
   | BLOCK | at least one blocker | It stops. The owner is told why |
   | FIX | no blocker, at least one major | Back to the writer, with the findings |
   | PASS | no blocker, no major. Minors are listed | It goes to the owner's queue |

8. **Loop 2.** Say for each finding of loop 1: fixed or still open. Look for what the revision
   broke. There is no loop 3: after loop 2 the piece goes to the owner with the open findings.
9. **Write `review.md`**, then the queue line (see below).

## Output format
`brain/5-narrate/drafts/<slug>/review.md`, in the reviewer verdict format of `review-verdict`:

    # Review of brain/5-narrate/drafts/<slug>/piece.md
    - reviewer: nora
    - date: 2026-11-13
    - verdict: PASS | FIX | BLOCK
    - loop: 1

    ## Findings
    | # | Level | Where (exact quote) | Problem | Evidence (exact quote of the source or rule) |
    |---|---|---|---|---|
    | 1 | major | "the words of the draft" | what is wrong, in one line | writing/<kind>.md: "the rule" |

    ## Not checked
    - what you could not verify, and why ("nothing" is allowed)

    ## Checks run
    - Truth: <n> facts listed, <n> found in the source
    - Limits, Voice, Shape, The top alone, Lessons: ok, or the numbers of the findings

At loop 2 the top of the file describes loop 2, and the header and the findings table of loop 1
stay unchanged under `## Loop 1 (kept)`. The feedback loop reads this history later: the
same FIX three times in a month opens a change to the writing rules.

Queue line, after PASS or after loop 2:

    python .claude/skills/run-trace/scripts/queue.py add --from nora --ask "Read the draft: <subject>" --file brain/5-narrate/drafts/<slug>/piece.md --choices "edit|send back with a note|drop"

After loop 2 with open findings, the ask ends with "2 loops, <n> findings still open". On
BLOCK the ask is "Blocked draft: <subject>. <why>" and the choices are "send back with a note|drop".

## Check before you finish
- [ ] Every fact of the draft was looked for in the source. None was taken on trust.
- [ ] Every finding has the exact words of the draft and the exact words of the rule, lesson
      or source line.
- [ ] No finding gives the new sentence. You name the place and the rule.
- [ ] "Not checked" is filled in. A PASS covers only what you verified.
- [ ] The verdict follows the table. One blocker is a BLOCK, whatever the rest.
- [ ] You wrote one file. `piece.md` is untouched.
- [ ] The queue line is added when it is due, and its id is in your final message.

## Common mistakes
| Mistake | What happens | Do this instead |
|---|---|---|
| Rewriting a sentence "to help" | Two authors, zero review | Place, problem, rule. Nothing more |
| "Sounds off" with no rule quoted | The writer cannot fix it, the loop learns nothing | Quote the line of the file, or drop the finding |
| Checking the style and trusting the facts | A wrong number goes out under the owner's name | Truth first, every fact |
| A silent PASS when the source would not open | The worst outcome | BLOCK, and "Not checked" says why |
| Reading the writer's reasoning | You agree with her | The artifact, the source, the rules. Only these |
| A third loop | Agents argue in circles | After loop 2 the owner gets the open findings |
| Raising a lesson above a rule of the owner | The numbers beat the taste | `rules.md` wins. Name the conflict |
