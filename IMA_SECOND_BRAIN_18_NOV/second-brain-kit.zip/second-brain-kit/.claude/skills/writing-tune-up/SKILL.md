---
name: writing-tune-up
description: How Sacha, the Voice Coach, tunes the writing rules. Read the edit diffs (what the owner corrected between the draft and the posted text), the Editor's reviews, the confirmed lessons and the piece cards. Classify each correction. When the same correction appears in 3 of the last 8 pieces, propose the SMALLEST edit to writing/<kind>.md or voice.md, with a before and after example, as a proposal file (lever writing) that Diego challenges and the owner decides. Use it for the monthly tune-up, when the owner says "it's not me", and to apply, keep or roll back a writing change.
user-invocable: false
---

# Writing tune-up

## When to use
- Once a month, after the scorecard, the edit diffs and the piece cards are up to date.
- The weekly review named a writing trigger, or a lesson was confirmed for 4 weeks.
- The owner decided on one of your proposals, or says "it's not me" about a text: part B.

**Where this sits in the feedback loop.** Seven stages. One agent and its skill at each stage.
This skill is the writing lever of stage 3 and of stage 6.

| Stage | Who | Skill | Output |
|---|---|---|---|
| 1. Measure | Dexter | `scorecard` (tools `scorecard.py`, `edit_diff.py`) | numbers at 24 h, 72 h, 7 days against a fixed baseline, and what the owner changed between the draft and the posted text |
| 2. Review each piece | Diane | `post-debrief` | one card per piece: numbers, verdict, the owner's edits, what the Editor had flagged, one hypothesis |
| 3. Propose | Diane (lesson), Serena (pillar), Sacha (writing) | `lessons-ledger`, `pillar-review`, `writing-tune-up` | one proposal file per change |
| 4. Challenge | Diego | `change-challenge` | ACCEPT, NEEDS MORE EVIDENCE or REJECT, per proposal |
| 5. Decide | the human | (queue) | accept, trial for 4 weeks, reject, or reword |
| 6. Apply | the owner of the file: Diane `lessons.md`, Serena `pillars.md`, Sacha `voice.md` and `writing/<kind>.md` | same skills | the file changed, one line in the ledger |
| 7. Verify | Sosie now (Double test must not drop), Dexter and Diane at the review date | `double-test`, `scorecard` | kept, extended or rolled back |

Three levers: **lessons** (weekly, at most 10, each with evidence from 2 pieces), **pillars**
(monthly, one move at a time), **writing rules** (monthly, the smallest edit, with a before and
after example). The triggers that open a writing proposal:

- Writing: the same correction by the owner in 3 of the last 8 pieces. The same FIX from the
  Editor 3 times in a month. A lesson confirmed for 4 weeks is promoted into the writing rules.
- Any time: the owner says "it's not me". That goes straight to the rules, no numbers needed.

The owner's taste beats the numbers: a proposal that contradicts `rules.md` is dropped by Diego.

## Inputs
- `brain/6-debrief/metrics/edits/<slug>.md` and `edits.json`: the draft against the posted
  text, line by line. The tool gives no class: you do.
- `brain/5-narrate/drafts/<slug>/review.md`: the Editor's findings, loop 1 and loop 2.
- `brain/6-debrief/lessons.md` and the cards in `brain/6-debrief/reviews/posts/`.
- `brain/1-self/voice.md`, `writing/<kind>.md`, `rules.md`, `not-me.md`.
- `brain/6-debrief/changes/`: your proposals, Diego's challenges, `ledger.md`.

## Steps
### A. Propose (stage 3)
1. **Bring your open proposals up to date.** Only you write their `status:` line. `challenged`
   after NEEDS MORE EVIDENCE: add the evidence once, or wait for more pieces. `rejected` after
   REJECT: it stops there. `waiting` after ACCEPT, until the owner's decision and part B.
2. **Take the last 8 pieces that went out**, by date. Fewer than 8: say how many you have.
3. **Classify each correction of the owner**, one class each: opening, length, structure, word
   choice, claim softened, example added, closing. Then describe it closely enough to compare:
   "removed the closing question" three times is one correction. Three different closings are not.
4. **Count the Editor and the lessons.** In the reviews of the last month, loop 1 included: the
   same FIX, the same rule quoted, 3 times. In `lessons.md`: a lesson confirmed for 4 weeks.
5. **No trigger met: propose nothing.** Say "no trigger met" with the counts. It is a result.
6. **Choose the file.** How one kind of piece is built (opening, length, structure, closing):
   `writing/<kind>.md`. Words, tone and phrases that hold for every kind: `voice.md`.
7. **Write the smallest edit**: one line added, changed or removed, that contradicts neither
   `rules.md`, `not-me.md` nor the rest of the file. One change per file per month.
8. **Give a before and after example** on a real passage of a recent draft. The best "after"
   is what the owner really wrote in the posted text.
9. **Write the proposal file.** The id is `<yyyy-mm>-writing-<nn>`. Then stop: Diego is next.

### B. Apply (stage 6), only with the owner's decision
Read the decision in your task, or with `python .claude/skills/run-trace/scripts/queue.py list`.
- accept: ledger decision `accepted`. Make the change.
- trial 4 weeks: `trial`. Make the change, marked "trial until <date>".
- reject: `rejected`. Change nothing, and never propose it again.
- reword: `accepted`. Put the owner's wording in "Proposed", then make the change.
- "it's not me": `accepted`, no count, no challenge. Write the proposal with the owner's exact
  words and the text they were said about, then apply at once. Sofia logs a limit in `not-me.md`.

1. `python ops/tools/ledger.py add --id <id> --lever writing --file brain/1-self/writing/<kind>.md --summary "<one line>" --decision accepted|trial|rejected --review-date <YYYY-MM-DD>`
2. Edit the file: exactly the text of "Proposed", nothing else.
3. Add one dated line under `## Changes`, at the bottom of that file. Create the section if needed:
   `- 2026-11-13: <what changed, in one line> (change 2026-11-writing-01, accepted)`
4. `python ops/tools/ledger.py set --id <id> --status applied`
5. Set `status: applied` in the proposal file. On a reject: step 1 only, then `status: rejected`.

### C. Verify (stage 7)
End your message with "Next: run the Double test again (Sosie), same three subjects, after
change <id>". It must not drop. At the review date: did the owner stop making this correction,
did the Editor stop raising this FIX? The owner chooses.
- Keep: `python ops/tools/ledger.py set --id <id> --status kept`
- Roll back: restore the text of "Today it says", add a "Changes" line, then
  `python ops/tools/ledger.py set --id <id> --status rolled-back --note "<why>"`
- Extend: run the `ledger.py add` line again with `--decision trial` and the new
  `--review-date`, then `ledger.py set --id <id> --status applied --note "extended"`.

## Output format
`brain/6-debrief/changes/<id>-proposal.md`:

    # Change 2026-11-writing-01: <one line>
    - id: 2026-11-writing-01
    - lever: writing
    - proposed_by: sacha
    - file: brain/1-self/writing/<kind>.md
    - status: proposed

    ## Today it says        (the exact line of the file, or "nothing: a new line")
    ## Proposed             (the exact new line. Then: Before "<passage>" / After "<passage>")
    ## Evidence             (the trigger and its count. Each piece: slug, class, the two quotes)
    ## Expected effect      (the correction or the FIX that should stop)
    ## Review date          (a date, 4 weeks after the change)
    ## What could be lost   (what the old line protected)

## Check before you finish
- [ ] The trigger is met, with its count: 3 of the last 8 pieces, 3 FIX in a month, or 4 weeks.
- [ ] One line changes. The before and after example uses a real passage.
- [ ] "Today it says" holds the exact old text. Nothing contradicts `rules.md` or `not-me.md`.
- [ ] After an apply: the dated "Changes" line, the ledger line, the Double test asked for.

## Common mistakes
| Mistake | What happens | Do this instead |
|---|---|---|
| A rule from one correction | The file fills with one-off tastes | 3 of the last 8 pieces |
| Rewriting the whole file | Nobody can tell what changed, no way back | One line |
| "Be more natural" | The writer cannot obey it, the Editor cannot check it | A line one can apply, with an example |
| Counting three different closings as one | A false trigger | Describe the correction, then count |
| Editing first, proposing after | The Self changes without the owner | Proposal, Diego, the owner, then the file |
