#!/usr/bin/env python3
"""The "Waiting for you" queue: every decision that needs the human, in one place.

Commands (run from the project root):

  python .claude/skills/run-trace/scripts/queue.py add --from NAME --ask "..." [--file PATH] --choices "a|b|c"
  python .claude/skills/run-trace/scripts/queue.py list [--open] [--json]
  python .claude/skills/run-trace/scripts/queue.py resolve ID --decision "..." [--note "..."] [--via screen|alfred]
  python .claude/skills/run-trace/scripts/queue.py applied ID [ID ...]

`add` prints the id of the new item (q-001, q-002, ...).

Files, both written only by this script:
  ops/queue.json           {"items":[{"id","ts","from","ask","file","choices","status","decision","decided_ts","note",
                           "via","applied"}]}
                           status is "open" or "done". choices is a list of texts.
                           via says where the decision was given: "alfred" (in the conversation) or "screen".
                           applied is false for a decision given on the screen until an agent acted on it.
  ops/waiting-for-you.md   the readable view, oldest first, written again at every change.

Nothing in the queue is ever applied by default: an agent adds a line and stops. Only the human decides.
`resolve` records the decision. It does not apply it. A decision clicked on the screen (--via screen) is
recorded with "applied": false: no agent has acted on it yet. `list --open` shows these after the open
items, and `applied` marks them once the work is done.

`resolve` also closes the gate in the run log: when the last run line of the agent that asked says
"waiting" and no other question of that agent is open, one stop line "done" is added for that agent
(source "tool"), so the screen stops showing an agent that waits for an answer already given.

The project root is found from the location of this file (the folder that holds .claude/), so the skill
folder can be copied into another project as it is. Standard library only.
"""
from __future__ import annotations

import argparse
import json
import os
import re
import sys
import time
from datetime import datetime
from pathlib import Path

DECIDED_SHOWN = 20
GATE_DAYS = 30  # how far back the run log is read to find the last line of the agent that asked


# ---------------------------------------------------------------- helpers

def find_root() -> Path:
    """The project root: the folder that holds the .claude/ folder this script lives in."""
    here = Path(__file__).resolve()
    for parent in here.parents:
        if parent.name == ".claude":
            if parent.parent != Path.home():
                return parent.parent
            break
    env = os.environ.get("CLAUDE_PROJECT_DIR", "")
    if env and Path(env).is_dir():
        return Path(env).resolve()
    return Path.cwd()


class Stop(Exception):
    """An expected problem: one clear line for the user, no stack trace."""


def now_iso() -> str:
    return datetime.now().replace(microsecond=0).isoformat()


def explain(error: OSError, root: Path) -> str:
    """A system error in a few words, with a path from the project root, never a full one."""
    name = ""
    if error.filename:
        try:
            name = Path(str(error.filename)).resolve().relative_to(root.resolve()).as_posix()
        except (ValueError, OSError):
            name = Path(str(error.filename)).name
    reason = error.strerror or type(error).__name__
    return f"{reason}: {name}" if name else reason


def clean(text) -> str:
    """One line, no long dashes."""
    text = "" if text is None else str(text)
    text = re.sub(r"\s*" + chr(0x2014) + r"\s*", ", ", text).replace(chr(0x2013), "-")
    return " ".join(text.split())


def norm_path(root: Path, value) -> str | None:
    text = clean(value).strip('"').strip("'")
    if not text:
        return None
    path = Path(text)
    if path.is_absolute():
        try:
            text = str(path.resolve().relative_to(root.resolve()))
        except (ValueError, OSError):
            text = str(path)
    text = text.replace("\\", "/")
    return text[2:] if text.startswith("./") else text


def queue_path(root: Path) -> Path:
    return root / "ops" / "queue.json"


def view_path(root: Path) -> Path:
    return root / "ops" / "waiting-for-you.md"


class Lock:
    """A small lock file, so two agents never write the queue at the same moment."""

    def __init__(self, path: Path):
        self.path = path

    def __enter__(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        deadline = time.time() + 5
        while True:
            try:
                os.close(os.open(self.path, os.O_CREAT | os.O_EXCL | os.O_WRONLY))
                return self
            except FileExistsError:
                try:
                    if time.time() - self.path.stat().st_mtime > 30:  # left by a crashed run
                        self.path.unlink()
                        continue
                except OSError:
                    pass
                if time.time() > deadline:
                    raise Stop("The queue is busy (ops/queue.lock exists). Try again in a few seconds.")
                time.sleep(0.05)

    def __exit__(self, *exc):
        try:
            self.path.unlink()
        except OSError:
            pass


def write_text(path: Path, text: str) -> None:
    """Write through a temporary file, so a reader never sees half a file."""
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + ".tmp")
    with open(temp, "w", encoding="utf-8", newline="\n") as handle:
        handle.write(text)
    for attempt in range(10):
        try:
            os.replace(temp, path)
            return
        except PermissionError:  # Windows: another program is reading the file right now
            time.sleep(0.05)
    with open(path, "w", encoding="utf-8", newline="\n") as handle:
        handle.write(text)
    try:
        temp.unlink()
    except OSError:
        pass


def load(root: Path) -> dict:
    path = queue_path(root)
    if not path.is_file():
        return {"items": []}
    try:
        data = json.loads(path.read_text(encoding="utf-8-sig"))
    except ValueError as error:
        raise Stop(f"ops/queue.json is not valid JSON ({error}). Repair it or move it away, then try again.")
    if isinstance(data, list):
        data = {"items": data}
    if not isinstance(data, dict) or not isinstance(data.get("items"), list):
        raise Stop('ops/queue.json must look like {"items": [...]}. Repair it or move it away, then try again.')
    data["items"] = [item for item in data["items"] if isinstance(item, dict)]
    return data


def save(root: Path, data: dict) -> None:
    write_text(queue_path(root), json.dumps(data, ensure_ascii=False, indent=2) + "\n")
    write_text(view_path(root), render_view(data["items"]))


def choices_of(item: dict) -> list[str]:
    choices = item.get("choices") or []
    if isinstance(choices, str):
        choices = choices.split("|")
    return [clean(choice) for choice in choices if clean(choice)]


def is_open(item: dict) -> bool:
    return item.get("status") != "done"


def when(ts) -> str:
    return str(ts or "")[:16].replace("T", " ")


def to_apply(items: list[dict]) -> list[dict]:
    """Decided on the screen, and no agent acted on it yet."""
    return [item for item in items
            if not is_open(item) and item.get("via") == "screen" and item.get("applied") is False]


def close_gate(root: Path, items: list[dict], item: dict, decision: str) -> str:
    """The owner answered. When the last run line of the agent that asked still says "waiting", add
    the stop line that closes its gate, written the way log_run.py writes a line. Returns one line
    to print, or "". An agent with another open question still waits: nothing is written. A problem
    here never undoes the decision."""
    asker = clean(item.get("from")).lower()
    if not asker or any(is_open(other) and clean(other.get("from")).lower() == asker for other in items):
        return ""
    try:
        here = str(Path(__file__).resolve().parent)
        if here not in sys.path:
            sys.path.insert(0, here)
        import log_run
        latest = None
        for record in log_run.recent_records(root, days=GATE_DAYS):
            if str(record.get("agent", "")).lower() == asker:
                latest = record
        if not latest or latest.get("status") != "waiting":
            return ""
        summary = f"Gate closed: the owner answered {item.get('id')}: {log_run.clean(decision, 80)}"
        record = log_run.make_record(latest.get("agent") or asker, "stop", "done", latest.get("routine"),
                                     summary, source="tool")
        log_run.append_record(root, record)
        return f"Gate closed in the run log: {asker} no longer waits."
    except Exception as error:
        return f"Note: the gate of {asker} was not closed in the run log ({type(error).__name__})."


# ---------------------------------------------------------------- the readable view

def cell(text) -> str:
    return clean(text).replace("|", "/")


def file_link(path) -> str:
    path = cell(path)
    if not path:
        return ""
    if re.match(r"^([a-zA-Z]:|/|[a-z]+://)", path):
        return f"`{path}`"
    return f"[{path}](../{path.replace(' ', '%20')})"


def render_view(items: list[dict]) -> str:
    waiting = sorted((item for item in items if is_open(item)), key=lambda item: str(item.get("ts", "")))
    decided = sorted((item for item in items if not is_open(item)),
                     key=lambda item: str(item.get("decided_ts") or ""), reverse=True)
    lines = ["# Waiting for you", ""]
    if not waiting:
        lines += ["Nothing waits for you.", ""]
    else:
        count = len(waiting)
        lines += [
            f"{count} decision{'s' if count != 1 else ''} wait{'' if count != 1 else 's'} for you. "
            "The oldest is on top. Nothing here is applied by default.",
            "",
            "| id | since | who asks | what | file | choices |",
            "|---|---|---|---|---|---|",
        ]
        for item in waiting:
            lines.append("| " + " | ".join([
                cell(item.get("id")), when(item.get("ts")), cell(item.get("from")), cell(item.get("ask")),
                file_link(item.get("file")), " / ".join(cell(choice) for choice in choices_of(item)),
            ]) + " |")
        lines += [
            "",
            "To answer: tell Alfred, click in Mission Control, or run",
            '`python .claude/skills/run-trace/scripts/queue.py resolve ID --decision "..."`.',
            "",
        ]
    if decided:
        lines += ["## Decided", "", "| id | asked | who asked | what | your decision | decided | note |",
                  "|---|---|---|---|---|---|---|"]
        for item in decided[:DECIDED_SHOWN]:
            lines.append("| " + " | ".join([
                cell(item.get("id")), when(item.get("ts")), cell(item.get("from")), cell(item.get("ask")),
                cell(item.get("decision")) + (" (on the screen)" if item.get("via") == "screen" else ""),
                when(item.get("decided_ts")), cell(item.get("note")),
            ]) + " |")
        if len(decided) > DECIDED_SHOWN:
            lines += ["", f"Older decisions ({len(decided) - DECIDED_SHOWN}) are in `ops/queue.json`."]
        lines.append("")
    lines += ["_Written by queue.py at every change. Do not edit by hand._", ""]
    return "\n".join(lines)


# ---------------------------------------------------------------- commands

def next_id(items: list[dict]) -> str:
    numbers = [int(match.group(1)) for item in items
               if (match := re.fullmatch(r"q-(\d+)", str(item.get("id", ""))))]
    return f"q-{max(numbers, default=0) + 1:03d}"


def cmd_add(root: Path, args) -> None:
    asker = clean(args.asker).lower()
    ask = clean(args.ask)
    if not asker:
        raise Stop("--from is empty. Give the first name of the agent that asks, for example --from nora.")
    if not ask:
        raise Stop('--ask is empty. Write one question the human can answer, for example --ask "Read the draft?".')
    choices = [clean(choice) for choice in str(args.choices).split("|") if clean(choice)]
    if not choices:
        raise Stop('--choices is empty. Give the possible answers, for example --choices "accept|trial|reject".')
    with Lock(root / "ops" / "queue.lock"):
        data = load(root)
        item = {
            "id": next_id(data["items"]),
            "ts": now_iso(),
            "from": asker,
            "ask": ask,
            "file": norm_path(root, args.file),
            "choices": choices,
            "status": "open",
            "decision": None,
            "decided_ts": None,
            "note": None,
            "via": None,
            "applied": None,
        }
        data["items"].append(item)
        save(root, data)
    print(item["id"])


def find_item(items: list[dict], wanted: str) -> dict:
    key = wanted.strip().lower()
    if key.isdigit():
        key = f"q-{int(key):03d}"
    for item in items:
        if str(item.get("id", "")).lower() == key:
            return item
    known = ", ".join(str(item.get("id")) for item in items if is_open(item)) or "none"
    raise Stop(f'No item "{wanted}" in the queue. Open items: {known}.')


def cmd_resolve(root: Path, args) -> None:
    decision = clean(args.decision)
    if not decision:
        raise Stop('--decision is empty. Say what was decided, for example --decision "accept".')
    with Lock(root / "ops" / "queue.lock"):
        data = load(root)
        item = find_item(data["items"], args.id)
        if not is_open(item):
            raise Stop(f'{item.get("id")} is already decided ("{item.get("decision")}", {when(item.get("decided_ts"))}). '
                       "Add a new item to ask again.")
        item["status"] = "done"
        item["decision"] = decision
        item["decided_ts"] = now_iso()
        item["note"] = clean(args.note) or None
        item["via"] = args.via
        item["applied"] = False if args.via == "screen" else None
        save(root, data)
        gate = close_gate(root, data["items"], item, decision)
    print(f'{item["id"]} decided: {decision}')
    if gate:
        print(gate)


def cmd_applied(root: Path, args) -> None:
    with Lock(root / "ops" / "queue.lock"):
        data = load(root)
        found = [find_item(data["items"], wanted) for wanted in args.ids]
        still_open = [str(item.get("id")) for item in found if is_open(item)]
        if still_open:
            raise Stop(f'{", ".join(still_open)}: still open, nothing was decided yet. Nothing was marked.')
        for item in found:
            item["applied"] = True
        save(root, data)
    print("Applied: " + ", ".join(str(item.get("id")) for item in found))


def cmd_list(root: Path, args) -> None:
    if not queue_path(root).is_file():
        with Lock(root / "ops" / "queue.lock"):
            save(root, load(root))
    data = load(root)
    items = sorted(data["items"], key=lambda item: str(item.get("ts", "")))
    shown = [item for item in items if is_open(item)] if args.open else items
    pending = to_apply(items) if args.open else []
    if args.json:
        def with_keys(item: dict) -> dict:  # an item written before these two keys existed still carries them
            return {**item, "via": item.get("via"), "applied": item.get("applied")}

        out = {"items": [with_keys(item) for item in shown]}
        if args.open:
            out["to_apply"] = [with_keys(item) for item in pending]
        print(json.dumps(out, ensure_ascii=False, indent=2))
        return
    waiting = sum(1 for item in items if is_open(item))
    print(f"Waiting for you: {waiting} open, {len(items) - waiting} decided (ops/queue.json)")
    if not shown:
        print("Nothing waits for you.")
    for item in shown:
        state = "open" if is_open(item) else f'decided: {item.get("decision")}'
        print(f'{item.get("id")}  {when(item.get("ts"))}  from {item.get("from")}  [{state}]')
        print(f'    {item.get("ask")}')
        if item.get("file"):
            print(f'    file: {item.get("file")}')
        if is_open(item):
            print(f'    choices: {" | ".join(choices_of(item))}')
        elif item.get("note"):
            print(f'    note: {item.get("note")}')
    if pending:
        print("Decided on the screen, not applied yet:")
        for item in pending:
            print(f'{item.get("id")}  from {item.get("from")}  decided: {item.get("decision")}')
            if item.get("note"):
                print(f'    note: {item.get("note")}')


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="queue.py",
        description='The "Waiting for you" queue: ops/queue.json and its readable view ops/waiting-for-you.md.',
        epilog='Example: python .claude/skills/run-trace/scripts/queue.py add --from nora '
               '--ask "The draft passed the review. Read it?" --file brain/5-narrate/drafts/x/piece.md '
               '--choices "edit|send back|drop"',
    )
    sub = parser.add_subparsers(dest="command", metavar="add | list | resolve | applied")

    add = sub.add_parser("add", help="put one decision in front of the human. Prints the new id")
    add.add_argument("--from", dest="asker", required=True, help="who asks: the first name of the agent, lower case")
    add.add_argument("--ask", required=True, help="one sentence, a question the human can answer")
    add.add_argument("--file", default=None, help="the file to read before deciding, from the project root")
    add.add_argument("--choices", default="yes|no", help='the possible answers, separated by "|" (default: yes|no)')

    show = sub.add_parser("list", help="show the queue, oldest first")
    show.add_argument("--open", action="store_true",
                      help="only what still waits, then what was decided on the screen and is not applied yet")
    show.add_argument("--json", action="store_true", help="print the items as JSON")

    resolve = sub.add_parser("resolve", help="record the decision of the human. It does not apply it")
    resolve.add_argument("id", help="the id of the item, for example q-003")
    resolve.add_argument("--decision", required=True, help="what the human decided, in a few words")
    resolve.add_argument("--note", default=None, help="an optional note from the human")
    resolve.add_argument("--via", choices=("alfred", "screen"), default="alfred",
                         help="where the decision was given (default: alfred). screen: recorded as not applied yet")

    applied = sub.add_parser("applied", help="mark decided items as applied: an agent acted on the decision")
    applied.add_argument("ids", nargs="+", metavar="ID", help="one or more ids, for example q-003 q-004")
    return parser


def main() -> None:
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass
    parser = build_parser()
    args = parser.parse_args()
    root = find_root()
    try:
        if args.command == "add":
            cmd_add(root, args)
        elif args.command == "resolve":
            cmd_resolve(root, args)
        elif args.command == "applied":
            cmd_applied(root, args)
        elif args.command == "list":
            cmd_list(root, args)
        else:
            parser.print_help()
            sys.exit(2)
    except Stop as problem:
        print(f"queue: {problem}", file=sys.stderr)
        sys.exit(1)
    except OSError as error:
        print(f"queue: cannot read or write the queue ({explain(error, root)}).", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
