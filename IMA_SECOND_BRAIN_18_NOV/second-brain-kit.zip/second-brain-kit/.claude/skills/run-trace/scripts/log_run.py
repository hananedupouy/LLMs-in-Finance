#!/usr/bin/env python3
"""Run trace: every agent run leaves one start line and one stop line.

Commands (run from the project root):

  python .claude/skills/run-trace/scripts/log_run.py start --agent NAME [--routine R] [--summary "..."]
  python .claude/skills/run-trace/scripts/log_run.py stop  --agent NAME --status done|failed|blocked|waiting
         --summary "..." [--output PATH ...] [--verdict V] [--routine R]
  python .claude/skills/run-trace/scripts/log_run.py hook      (Claude Code hook: JSON on stdin, always exits 0)

Each call appends one JSON object, on one line, to ops/runs/YYYY-MM-DD.jsonl:

  {"ts":"2026-11-13T10:02:11","agent":"chloe","event":"stop","status":"done",
   "routine":"production-line","summary":"Summary of <title>, 5 sections",
   "outputs":["brain/3-condense/summaries/x/condensed.md"],"verdict":null,"source":"agent"}

  event    start or stop
  status   running (a start), then done, failed, blocked or waiting
  verdict  PASS, FIX, BLOCK, ACCEPT, NEEDS MORE EVIDENCE, REJECT, or null
  source   agent (the agent's own call), hook (the Claude Code hook) or tool (ops/tools/radar.py logs itself)

The hook mode is called by Claude Code on SubagentStart and SubagentStop (see .claude/settings.json).
It is written to survive anything:
  - it accepts any JSON on stdin, or none, and tries several field names for the agent and the event;
  - it appends what it received to ops/runs/_hook-raw.jsonl, for debugging (home folder replaced by "~");
  - it prints nothing and always exits 0, so it can never disturb or block a session.
Rules of the hook mode:
  - no agent name in the payload: nothing is logged (the raw line is still kept);
  - a stop is logged only when the hook logged a start for the same run before. Claude Code also fires
    "subagent stop" for its own helper agents, and those have no start;
  - a hook stop line copies the status, summary, outputs and verdict of the agent's own stop line when
    there is one, so the two lines never disagree. Otherwise it says "done" with the first line of the
    agent's last message.
  Hook lines carry one extra field, "agent_id", used to pair a stop with its start.

The project root is found from the location of this file (the folder that holds .claude/), so the skill
folder can be copied into another project as it is. Standard library only.
"""
from __future__ import annotations

import argparse
import json
import os
import re
import sys
from datetime import datetime, timedelta
from pathlib import Path

STATUSES = ("done", "failed", "blocked", "waiting")
VERDICTS = ("PASS", "FIX", "BLOCK", "ACCEPT", "NEEDS MORE EVIDENCE", "REJECT")
RAW_NAME = "_hook-raw.jsonl"
RAW_MAX_BYTES = 5_000_000
SUMMARY_MAX = 300

AGENT_KEYS = ("agent_type", "subagent_type", "agent_name", "agentType", "subagentType", "agentName",
              "subagent_name", "agent", "subagent", "name")
EVENT_KEYS = ("hook_event_name", "hookEventName", "hook_event", "event_name", "eventName", "event", "hook", "type")
ID_KEYS = ("agent_id", "agentId", "subagent_id", "subagentId", "task_id", "taskId")
MESSAGE_KEYS = ("last_assistant_message", "lastAssistantMessage", "message", "result", "summary")


# ---------------------------------------------------------------- helpers

def find_root() -> Path:
    """The project root: the folder that holds the .claude/ folder this script lives in."""
    here = Path(__file__).resolve()
    for parent in here.parents:
        if parent.name == ".claude":
            if parent.parent != Path.home():
                return parent.parent
            break
    env = os.environ.get("CLAUDE_PROJECT_DIR", "")
    if env and Path(env).is_dir():
        return Path(env).resolve()
    return Path.cwd()


def now() -> datetime:
    return datetime.now().replace(microsecond=0)


def clean(text, limit: int | None = None) -> str:
    """One line, no long dashes, cut to a limit."""
    text = "" if text is None else str(text)
    text = re.sub(r"\s*" + chr(0x2014) + r"\s*", ", ", text).replace(chr(0x2013), "-")
    text = " ".join(text.split())
    if limit and len(text) > limit:
        text = text[: limit - 3].rstrip() + "..."
    return text


def norm_path(root: Path, value) -> str:
    text = str(value).strip().strip('"').strip("'")
    if not text:
        return ""
    path = Path(text)
    if path.is_absolute():
        try:
            text = str(path.resolve().relative_to(root.resolve()))
        except (ValueError, OSError):
            text = str(path)
    text = text.replace("\\", "/")
    return text[2:] if text.startswith("./") else text


def runs_dir(root: Path) -> Path:
    return root / "ops" / "runs"


def append_line(path: Path, obj: dict, ascii_only: bool = False) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    line = json.dumps(obj, ensure_ascii=ascii_only, separators=(",", ":")) + "\n"
    with open(path, "a", encoding="utf-8", newline="\n") as handle:
        handle.write(line)


def append_record(root: Path, record: dict) -> Path:
    path = runs_dir(root) / f"{record['ts'][:10]}.jsonl"
    append_line(path, record)
    return path


def make_record(agent, event, status, routine=None, summary="", outputs=None, verdict=None, source="agent") -> dict:
    return {
        "ts": now().isoformat(),
        "agent": agent,
        "event": event,
        "status": status,
        "routine": routine or None,
        "summary": clean(summary, SUMMARY_MAX),
        "outputs": list(outputs or []),
        "verdict": verdict,
        "source": source,
    }


def recent_records(root: Path, days: int = 2) -> list[dict]:
    """The run records of today and yesterday, oldest first."""
    records: list[dict] = []
    today = now().date()
    for back in range(days - 1, -1, -1):
        path = runs_dir(root) / f"{(today - timedelta(days=back)).isoformat()}.jsonl"
        if not path.is_file():
            continue
        try:
            lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
        except OSError:
            continue
        for line in lines:
            try:
                record = json.loads(line)
            except ValueError:
                continue
            if isinstance(record, dict):
                records.append(record)
    return records


def fail(message: str) -> None:
    print(f"log_run: {message}", file=sys.stderr)
    sys.exit(1)


def explain(error: OSError, root: Path) -> str:
    """A system error in a few words, with a path from the project root, never a full one."""
    name = ""
    if error.filename:
        try:
            name = Path(str(error.filename)).resolve().relative_to(root.resolve()).as_posix()
        except (ValueError, OSError):
            name = Path(str(error.filename)).name
    reason = error.strerror or type(error).__name__
    return f"{reason}: {name}" if name else reason


def agent_name(value) -> str:
    name = clean(value).lower()
    if not name:
        fail("--agent is empty. Give your first name in lower case, for example --agent chloe.")
    return name


def norm_verdict(value):
    if value is None:
        return None
    key = re.sub(r"[\s_\-]+", " ", str(value).strip()).upper()
    if key in ("", "NONE", "NULL"):
        return None
    if key not in VERDICTS:
        fail(f'unknown verdict "{value}". Use one of: {", ".join(VERDICTS)}.')
    return key


# ---------------------------------------------------------------- start and stop

def cmd_start(root: Path, args) -> None:
    record = make_record(agent_name(args.agent), "start", "running", clean(args.routine), args.summary)
    path = append_record(root, record)
    print(f"run-trace: {record['agent']} start -> {norm_path(root, path)}")


def cmd_stop(root: Path, args) -> None:
    agent = agent_name(args.agent)
    status = str(args.status).strip().lower()
    if status not in STATUSES:
        fail(f'unknown status "{args.status}". Use one of: {", ".join(STATUSES)}.')
    outputs = [norm_path(root, item) for group in (args.output or []) for item in group]
    outputs = [item for item in outputs if item]
    routine = clean(args.routine)
    if not routine:
        # Keep the routine given at the start, so the two lines of a run agree.
        for previous in reversed(recent_records(root)):
            if previous.get("agent") == agent and previous.get("source") == "agent":
                if previous.get("event") == "start":
                    routine = previous.get("routine") or ""
                break
    record = make_record(agent, "stop", status, routine, args.summary, outputs, norm_verdict(args.verdict))
    path = append_record(root, record)
    verdict = f" {record['verdict']}" if record["verdict"] else ""
    print(f"run-trace: {agent} stop {status}{verdict} -> {norm_path(root, path)}")


# ---------------------------------------------------------------- hook

def first_text(payload: dict, keys) -> str:
    """The first non-empty text found under one of the keys, here or one level down."""
    scopes = [payload] + [payload[k] for k in ("tool_input", "toolInput", "data", "input") if isinstance(payload.get(k), dict)]
    for scope in scopes:
        for key in keys:
            value = scope.get(key)
            if isinstance(value, dict):
                value = value.get("name") or value.get("type") or value.get("id")
            if isinstance(value, (str, int)) and not isinstance(value, bool) and str(value).strip():
                return str(value).strip()
    return ""


def hook_event(payload: dict) -> str | None:
    name = first_text(payload, EVENT_KEYS).lower()
    if "start" in name:
        return "start"
    if "stop" in name or "finish" in name or "complete" in name or name.endswith("end"):
        return "stop"
    return None


def hook_agent(payload: dict) -> str:
    name = clean(first_text(payload, AGENT_KEYS)).lower()
    return name.split(":")[-1].strip()  # "plugin:agent" becomes "agent"


def find_open_start(records: list[dict], agent: str, agent_id: str) -> dict | None:
    """The hook start line that this stop closes, or None."""
    by_id: dict[str, dict] = {}
    no_id: list[dict] = []
    for record in records:
        if record.get("source") != "hook" or record.get("agent") != agent:
            continue
        rid = str(record.get("agent_id") or "")
        if record.get("event") == "start":
            if rid:
                by_id[rid] = record
            else:
                no_id.append(record)
        elif record.get("event") == "stop":
            if rid and rid in by_id:
                del by_id[rid]
            elif no_id:
                no_id.pop()
            elif by_id and not rid:
                by_id.popitem()
    if agent_id and agent_id in by_id:
        return by_id[agent_id]
    if no_id:
        return no_id[-1]
    if not agent_id and by_id:
        return list(by_id.values())[-1]
    return None


def own_line_after(records: list[dict], start: dict, agent: str, event: str) -> dict | None:
    """The agent's own start or stop line written after a given hook start line, the latest one."""
    position = next((index for index, record in enumerate(records) if record is start), -1)
    found = None
    for record in records[position + 1:]:
        if record.get("source") == "agent" and record.get("agent") == agent and record.get("event") == event:
            found = record
    return found


def shorten(value, home_forms, limit: int = 2000):
    """A copy of the payload that is safe to keep: long texts cut, home folder hidden."""
    if isinstance(value, str):
        for form in home_forms:
            value = value.replace(form, "~")
        return value if len(value) <= limit else value[:limit] + "...[cut]"
    if isinstance(value, dict):
        return {str(k): shorten(v, home_forms, limit) for k, v in list(value.items())[:200]}
    if isinstance(value, list):
        return [shorten(v, home_forms, limit) for v in value[:200]]
    return value


def write_raw(root: Path, payload, text: str, logged: bool, reason: str) -> None:
    home = str(Path.home())
    home_forms = [home, home.replace("\\", "/"), home.replace("\\", "\\\\")]
    line = {"ts": now().isoformat(), "logged": logged, "reason": shorten(reason, home_forms)}
    if payload is not None:
        line["payload"] = shorten(payload, home_forms)
    else:
        line["raw"] = shorten(text, home_forms)
    path = runs_dir(root) / RAW_NAME
    try:
        if path.is_file() and path.stat().st_size > RAW_MAX_BYTES:
            os.replace(path, path.with_name("_hook-raw.old.jsonl"))
    except OSError:
        pass
    append_line(path, line, ascii_only=True)


def hook_log(root: Path, payload) -> tuple[bool, str]:
    """Write the run record for one hook event. Returns (logged, reason)."""
    if not isinstance(payload, dict):
        return False, "no JSON object on stdin"
    event = hook_event(payload)
    if event is None:
        return False, "the event is not a start or a stop"
    agent = hook_agent(payload)
    if not agent:
        return False, "no agent name in the payload"
    agent_id = first_text(payload, ID_KEYS)
    if event == "start":
        record = make_record(agent, "start", "running", source="hook")
        record["agent_id"] = agent_id
        append_record(root, record)
        return True, ""
    records = recent_records(root)
    start = find_open_start(records, agent, agent_id)
    if start is None:
        return False, "stop without a start logged by the hook (helper agent of the session, or start not seen)"
    own_stop = own_line_after(records, start, agent, "stop")
    if own_stop:
        record = make_record(agent, "stop", own_stop.get("status") or "done", own_stop.get("routine"),
                             own_stop.get("summary") or "", own_stop.get("outputs") or [],
                             own_stop.get("verdict"), "hook")
    else:
        own_start = own_line_after(records, start, agent, "start") or {}
        message = first_text(payload, MESSAGE_KEYS)
        first_line = next((line for line in message.splitlines() if line.strip()), "")
        record = make_record(agent, "stop", "done", own_start.get("routine"), clean(first_line, 160), source="hook")
    record["agent_id"] = agent_id or str(start.get("agent_id") or "")
    append_record(root, record)
    return True, ""


def cmd_hook(root: Path) -> None:
    """Never raises, never prints, always exits 0."""
    try:
        sys.stdout = open(os.devnull, "w", encoding="utf-8")
        sys.stderr = open(os.devnull, "w", encoding="utf-8")
    except Exception:
        pass
    text, payload, logged, reason = "", None, False, ""
    try:
        if sys.stdin is not None and not sys.stdin.isatty():
            data = sys.stdin.buffer.read(10_000_000)
            text = data.decode("utf-8", errors="replace").lstrip(chr(0xFEFF)).strip()
        if text:
            try:
                payload = json.loads(text)
            except ValueError:
                payload = None
        logged, reason = hook_log(root, payload)
    except BaseException as error:  # noqa: BLE001 - a hook must never fail
        reason = f"error: {type(error).__name__}: {error}"
    try:
        if os.environ.get("RUN_TRACE_RAW", "1") != "0":
            write_raw(root, payload, text, logged, reason)
    except BaseException:  # noqa: BLE001
        pass
    os._exit(0)


# ---------------------------------------------------------------- main

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="log_run.py",
        description="Run trace: append one start or stop line to ops/runs/YYYY-MM-DD.jsonl.",
        epilog='Example: python .claude/skills/run-trace/scripts/log_run.py stop --agent chloe --status done '
               '--summary "Summary of the source, 5 sections" --output brain/3-condense/summaries/x/condensed.md',
    )
    sub = parser.add_subparsers(dest="command", metavar="start | stop | hook")

    start = sub.add_parser("start", help="the first thing an agent does")
    start.add_argument("--agent", required=True, help="your first name in lower case (the name of your agent file)")
    start.add_argument("--routine", default="", help="the routine you run in, for example production-line")
    start.add_argument("--summary", default="", help="one sentence: what you are about to do")

    stop = sub.add_parser("stop", help="the last thing an agent does, also when the run failed")
    stop.add_argument("--agent", required=True, help="your first name in lower case")
    stop.add_argument("--status", default="done", help="done, failed, blocked or waiting (default: done)")
    stop.add_argument("--summary", default="", help="one sentence: what you produced, or why it failed")
    stop.add_argument("--output", "--outputs", nargs="+", action="append", metavar="PATH",
                      help="each file you wrote, from the project root. Several paths, or several --output")
    stop.add_argument("--verdict", default=None, help="reviewers only: " + ", ".join(VERDICTS))
    stop.add_argument("--routine", default="", help="the routine you run in (default: the one given at the start)")

    sub.add_parser("hook", help="for the Claude Code hook: reads JSON on stdin, prints nothing, always exits 0")
    return parser


def main() -> None:
    root = find_root()
    if len(sys.argv) > 1 and sys.argv[1] == "hook" and not {"-h", "--help"} & set(sys.argv[2:]):
        cmd_hook(root)
        return
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass
    parser = build_parser()
    args = parser.parse_args()
    try:
        if args.command == "start":
            cmd_start(root, args)
        elif args.command == "stop":
            cmd_stop(root, args)
        else:
            parser.print_help()
            sys.exit(2)
    except OSError as error:
        fail(f"cannot write the run log ({explain(error, root)}).")


if __name__ == "__main__":
    main()
