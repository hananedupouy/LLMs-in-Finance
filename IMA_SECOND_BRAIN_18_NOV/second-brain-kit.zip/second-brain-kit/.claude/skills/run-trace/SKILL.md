---
name: run-trace
description: Leave a trace of every run. Use it at the start and at the end of any agent run, and each time a decision must wait for the human (a gate). It writes the run log and the "Waiting for you" queue that Mission Control shows.
user-invocable: false
allowed-tools: Bash(python .claude/skills/run-trace/scripts/*) PowerShell(python .claude/skills/run-trace/scripts/*)
---

# Run trace

House rule 7: every run leaves a trace. No trace, no trust.

Three lines to know. Run them from the project root. NAME is your first name in lower case, the
name of your agent file.

## 1. The start line: the first thing you do

```
python .claude/skills/run-trace/scripts/log_run.py start --agent NAME [--routine R] [--summary "what you are about to do"]
```

## 2. The stop line: the last thing you do, also when the run failed

```
python .claude/skills/run-trace/scripts/log_run.py stop --agent NAME --status done|failed|blocked|waiting --summary "..." [--output PATH ...] [--verdict V] [--routine R]
```

| Field | What to write |
|---|---|
| `--status` | `done`: the work is finished. `failed`: say why in the summary. `blocked`: an input is missing, or a reviewer said BLOCK. `waiting`: you put a line in the queue |
| `--summary` | One plain sentence: what you produced. Nothing private |
| `--output` | Every file you wrote, from the project root. Several paths are allowed |
| `--verdict` | Reviewers only: `PASS`, `FIX`, `BLOCK`, or for a change: `ACCEPT`, `"NEEDS MORE EVIDENCE"`, `REJECT` |
| `--routine` | The routine you run in, for example `production-line` |

## 3. The queue line: at a human gate

When the next step is a decision of the human, do not decide. Put one line in the queue, then stop
with `--status waiting`.

```
python .claude/skills/run-trace/scripts/queue.py add --from NAME --ask "one question the human can answer" --file PATH --choices "a|b|c"
```

It prints the id of the item (for example `q-003`). `--file` is the file to read before deciding.

```
python .claude/skills/run-trace/scripts/queue.py list --open
python .claude/skills/run-trace/scripts/queue.py resolve ID --decision "..." [--note "..."] [--via screen]
python .claude/skills/run-trace/scripts/queue.py applied ID [ID ...]
```

`resolve` records what the human decided. Only the human decides: Alfred runs it when the human
answers in the chat, Mission Control runs it (`--via screen`) when the human clicks. It does not
apply the decision. A decision made on the screen is listed by `list --open` under "Decided on
the screen, not applied yet" until Alfred resumed the agent and ran `applied ID`.
`resolve` also closes the gate in the run log: when the agent that asked still shows `waiting`,
the tool writes its closing line. Nobody writes a line for another agent by hand.

The choices of a first version are always `approve|change`. The human answers "approve", or
"change:" followed by what to change. A change the human dictates is applied and approved: the
same file gets no second queue line.

## When you write a file

- Save it with the Write tool, never with a shell command: a long text with quotes breaks the
  command and nothing is written.
- Never start a file name with `summary`, `report`, `findings` or `analysis`, in any case: an
  agent tool may refuse the write. Your skill gives the name of each file you write.

## Rules

- One start line, one stop line, per run. A run that fails still gets its stop line.
- Nothing in the queue is applied by default. If the human does nothing, nothing changes.
- Never edit `ops/runs/`, `ops/queue.json` or `ops/waiting-for-you.md` by hand. The two scripts are
  their only writers, with two more for the run log: `ops/tools/radar.py` and
  `ops/tools/library.py` write their own start and stop lines (`"agent":"radar"` or
  `"agent":"library"`, `"source":"tool"`), so both are seen running and done like an agent.
- A Claude Code hook also logs each subagent start and stop (`"source":"hook"`). It is a safety net,
  not a replacement: only you know your summary, your outputs and your verdict.

## Where it goes

| File | Content |
|---|---|
| `ops/runs/YYYY-MM-DD.jsonl` | One JSON line per start and per stop: `ts, agent, event, status, routine, summary, outputs, verdict, source` |
| `ops/queue.json` | The queue: `{"items":[{id, ts, from, ask, file, choices, status, decision, decided_ts, note, via, applied}]}` |
| `ops/waiting-for-you.md` | The same queue, readable, oldest first. Written again at every change |

To reuse this skill in another project, copy the folder `run-trace/` into its `.claude/skills/`.
The scripts find the project root from their own location and create `ops/` when it is missing.
