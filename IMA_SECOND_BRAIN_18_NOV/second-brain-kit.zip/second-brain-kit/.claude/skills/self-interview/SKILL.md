---
name: self-interview
description: How Sofia, the Biographer, interviews the owner and writes who they are. Five short rounds (gaps, proof, stories, beliefs, then audience, goals and limits), one question at a time, twelve questions for the full interview and six for the short one, answers kept word for word, every claim tagged "stated by you" or "inferred". The portrait goes to brain/1-self/about-me.md and the limits to rules.md and not-me.md, and nothing is saved before the owner approved it. Use it at Onboarding, and to update the Self when a new fact, a document or a limit arrives.
user-invocable: false
---

# The Self interview

## When to use
- Onboarding: there is no `brain/1-self/about-me.md`, or it is thin.
- A new fact or a new document about the owner arrived (a role, a talk, a result).
- The owner stated a limit: "never", "it's not me", "from now on". Go to step 9.
- Not to describe the owner's voice (Sacha) or to choose the pillars (Serena).

Most people only give facts. The interview goes after what no document says: the stories, the
beliefs, the limits. They are what makes a text sound like one person and not like anybody.

## Inputs
- `brain/BRAIN.md`: who the owner is, what the brain produces. A project manager is not asked
  the questions of a writer.
- `brain/1-self/_raw/`: the documents the owner dropped (a bio, pieces, a transcript). Optional.
  A PDF, a Word file or slides have a text copy next to them (`cv.pdf.txt`, made by
  `library.py convert`): read the copy.
- `brain/1-self/_raw/<date>-interview.md`: the interview so far. It is your memory between two
  calls: each call starts with an empty context.
- The owner's last answer, word for word, in the message that called you.
- The length the owner chose, in your task: the full interview (12 questions) or the short one (6).
- Never `my-knowledge/`: the owner's courses, slides and books are knowledge, filed at Step E.

## Steps
1. **Find where the interview stands.** Open the interview file that still says
   `status: in progress`. None: create one for today and start at round 1.
2. **Save the last answer first**, word for word, under its question. Keep the hesitations,
   the strong words, the short sentences: they are samples of the owner's spoken voice.
3. **Ask the next question. One, and only one.** Short, concrete, about a real moment. Twelve
   questions at most for the five rounds of the full interview, six for the short one (the
   table after this one). Skip what the documents already answer.

   | Round | About | Questions that work |
   |---|---|---|
   | 1. Gaps | What the documents do not say | "Your bio stops two years ago. What happened since?" |
   | 2. Proof | What the owner made and is proud of | "Which piece of work would you show first? What did it change?" |
   | 3. Stories | Lived moments | "Tell me about a time it went wrong." "When did you change your mind?" |
   | 4. Beliefs | What they think that others do not | "What do most people in your field get wrong?" |
   | 5. Audience, goals, limits | Direction and edges | "Who do you want to help?" "Where do you want to be in 12 months?" "What will you never do or talk about?" |

   Fit the words to the job in `BRAIN.md` ("What is a good week for this project?"). An answer
   stays vague: ask once for an example, then move on.

   **The short interview: six questions**, in this order. It goes for what the Self cannot be
   built without. Skip one that the documents already answer, and take the next.

   | # | Round | The question |
   |---|---|---|
   | 1 | Proof | "Which piece of work would you show first? What did it change?" |
   | 2 | Stories | "Tell me about a time it went wrong, in a few lines." |
   | 3 | Stories | "When did you change your mind about something in your field?" |
   | 4 | Beliefs | "What do most people in your field get wrong?" |
   | 5 | Audience, goals | "Who do you want to help, and what should the next 12 months bring you?" |
   | 6 | Limits | "What will you never do, say or talk about? As many as you can, five if possible. And is there a name the brain must never write: an employer, a client, a person?" |

4. **How the question reaches the owner.** Called by Alfred: your final message is the round
   number and the question, nothing else. He shows it and brings the answer back. Started
   directly by the owner (`claude --agent sofia`): ask, and wait.
5. **Count before you propose.** The Self asks for 5 lived moments and 5 "never". You have
   fewer, from the answers and the documents together: ask ONE last question that gives the
   count. "I have 3 stories and 4 'never'. The Self asks for 5 of each. Give me the missing ones
   now, a few lines each, or say later." The owner says later: write what you have and say the
   count in your final message. Never invent one, and never ask this question twice.
6. **Write the proposal** `brain/1-self/_raw/self-proposed.md` (format below).
   - The portrait: one fact per line, each line ending with its tag.
     `[stated by you: interview, round 3]`: the owner said it, in these words.
     `[stated by you: _raw/<file>]`: it is written in a document the owner gave.
     `[inferred from: <what>]`: you deduced it. Keep these few: the owner confirms or cuts.
   - The limits: each "never", "always" and "not me" of round 5, in the owner's exact words.
     A name the brain must never write goes under "Private words", one per line.
   - **A portrait, not a catalogue: 80 lines at most.** "Proof" holds five lines at most, the
     work the owner would show first. Everything else the owner built, taught or published is
     knowledge, not identity: it is filed at Step E from `my-knowledge/` and found in the memory.
     Write one last line under "Proof": `More of my work: in the memory (my-knowledge/)`.
     "Stories" holds five to seven moments, three lines each at most.
   - Save the file with the Write tool, never with a shell command.
7. **Stop at the gate.** Mark the interview file `status: complete`. Add the queue line:

       python .claude/skills/run-trace/scripts/queue.py add --from sofia --ask "Read your portrait and your limits: is it you?" --file brain/1-self/_raw/self-proposed.md --choices "approve|change"

8. **Apply the decision**, when you are called with it. One review, not several.
   - `approve`: save each part of the proposal in its file, under the headings that file has.
   - `change: <the owner's words>` (or "edit"): apply each correction word for word, tag it
     `[stated by you: correction, <date>]`, remove what the owner cut, then save. A change the
     owner dictated is approved: add no new queue line. Your final message lists the lines you
     changed. Only a line the owner never saw and did not dictate needs their eyes: quote it.
   - "no", "reject", "it is not me": change nothing. Ask what was wrong, as one question.
   The owner answered you directly: record it first with
   `python .claude/skills/run-trace/scripts/queue.py resolve <id> --decision "approve"`.
9. **An update later** takes the same path: proposal, queue line, decision, save.
   - A new fact or document: only the changed lines of the portrait.
   - A limit the owner states: one line, their exact words, the date. A subject or a thing
     they never do goes to `rules.md`. A style, a word or an idea that "is not me" goes to
     `not-me.md`. A change they refused as a matter of taste goes to `not-me.md` with its id.
   - **One rule, one home.** A limit is written once, in `rules.md` or `not-me.md`. `voice.md`,
     the writing rules and the rubric point to it, they do not copy it. A rule copied in four
     files is changed in one and stays wrong in three.

## Output format
The interview file, `brain/1-self/_raw/<date>-interview.md`:

    # Interview of 2026-11-13
    - status: in progress | complete

    ## Round 1, question 1
    Q: <your question>
    A: <the answer, word for word>

The proposal, `brain/1-self/_raw/self-proposed.md`. Only the parts that change:

    # Proposed for your Self
    - date: 2026-11-13
    - status: waits for the owner

    ## For about-me.md
    Facts, Proof, Stories, Beliefs, Audience, Goals: the six sections, one tagged fact per line.

    ## For rules.md
    - Never: "<the owner's words>" (2026-11-13)
    - Always: "<the owner's words>" (2026-11-13)
    - Private words: <a name the brain must never write, one per line>

    ## For not-me.md
    - Subject: "<the owner's words>" (2026-11-13)
    - Style or word: "<the owner's words>" (2026-11-13)

The Self files keep the headings of the template. `about-me.md`: Facts, Proof, Stories,
Beliefs, Audience, Goals. `rules.md`: Never, Always, Private words, From my corrections.
`not-me.md`: Subjects I do not touch, Styles and words that are not mine, Changes I rejected.
"Stories" holds five to seven lived moments, three lines each at most, in the owner's words.
"Private words" is read by `library.py` before it files a document, and by the Editor.

## Check before you finish
- [ ] Every answer is in the interview file, word for word.
- [ ] Every line of the portrait ends with a tag. Every limit is a quote, with its date.
- [ ] A stranger could introduce the owner in one minute from `about-me.md`.
- [ ] "Stories" has moments, not adjectives. Fewer than five: say so, do not invent one.
- [ ] The portrait is 80 lines or fewer, and "Proof" five lines or fewer.
- [ ] A Self file changed only after the owner's answer, and the queue item says so.

## Common mistakes
| Mistake | What happens | Do this instead |
|---|---|---|
| Three questions in one message | The owner answers the easiest one | One question |
| Polishing an answer or a limit | The Self sounds like you | Word for word |
| "Passionate, results-driven" | It describes everybody | A moment, a figure, a name |
| An inference with no tag | A guess becomes a fact about the owner | `[inferred from: ...]`, or cut it |
| Saving a Self file to "go faster" | The Self changed without the owner | Proposal, queue, decision |
| Holding the interview in your head | The next call starts empty | The interview file, at every call |
| A new review after a change the owner dictated | The owner reads the same file three times | Apply it, say what changed, stop |
| Listing every course, lab and build under "Proof" | A catalogue of 100 lines, no portrait | Five lines. The rest is knowledge, filed at Step E |
