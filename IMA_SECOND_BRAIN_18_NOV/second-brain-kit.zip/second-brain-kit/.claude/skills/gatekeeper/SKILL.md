---
name: gatekeeper
description: How Carl, the Gatekeeper, filters what the radar brings before anything reaches Condense. He scores every item of brain/2-ears/radar/<date>.json from 0 to 1 against the owner's rubric (brain/1-self/rubric.md) with three questions (fit to a pillar, substance, use), keeps 0.7 or more and never more than 20 a day, best first, and writes brain/2-ears/shortlist/<date>.md with one reason per kept item and the list of what he skipped. Also how Serena drafts the rubric from the pillars, the owner's profile and the rules. Use it to score today's radar, to draft or change the rubric, and to check a shortlist.
user-invocable: false
---

# Gatekeeper: a small, high-quality list before Condense

## When to use
- The owner says "score today's radar", "what is worth reading today?", or the radar just ran.
- There is no rubric yet, or the owner wants to change it (part A, Serena).
- Not for what the owner captures by hand, and not for the owner's own documents: the owner
  already chose them. The gate is only for what arrives by itself.

The radar brings everything that is new, about 60 items a day. Nobody reads 60 abstracts with
the coffee. Carl reads them all, against the owner's taste written down, and leaves 20 at most.
Condense then works only on what the owner picked from those.

## How it works
```
brain/2-ears/radar/<date>.json     every new item, same detail (radar.py)
brain/1-self/rubric.md             what scores high and low, for this owner (Serena drafts, the owner approves)
        |
Carl                               three questions per item, one score from 0 to 1
        |
brain/2-ears/shortlist/<date>.md   kept: 0.7 or more, 20 at most, best first, one reason each
                                   skipped: one line each, with its score
        |
the owner picks: /capture <link>   Emma files it. Then Condense: Chloe, Cato
```

One file, one writer: the rubric is Serena's (approved by the owner), the shortlist is Carl's.
Carl never captures, never summarizes, never opens a paper. He reads the radar data only.

## A. The rubric (Serena drafts it, the owner approves it)

The rubric is the owner's taste, written so that an agent can apply it. It is not invented:
every line comes from a file of the Self.

| Section of the rubric | Taken from |
|---|---|
| **Topics that score high**: one line per pillar that a radar item can feed, with the topics and ideas to look for | `pillars.md`: the promise and the audience of each pillar |
| **Substance that scores high**: what makes an item worth keeping | `about-me.md`, Beliefs (for example "reliability over demos", "the honest version") |
| **What scores low** | `rules.md` and `not-me.md`: subjects refused, styles refused |
| **Hard no**: score 0, whatever the rest | `rules.md`, the lines under "Never" that a radar item can break: a subject the owner refuses to read about. A rule about how the owner writes (a word, a tone, a format) is never a Hard no: it says nothing about a paper |
| **Audience** | `about-me.md`, Audience, one line |

Steps for Serena:
1. Read `pillars.md`, `about-me.md`, `rules.md`, `not-me.md`. Copy the template
   `brains/_template/1-self/rubric.md` if the brain has no rubric. Never overwrite an approved one.
2. One line per pillar under "Topics that score high". A pillar the radar cannot feed (a
   personal story, for example) is named under "Not fed by the radar".
3. Every line ends with its origin in brackets, for example `(pillars.md, Agents You Can Trust)`.
4. The rubric fits on one screen: about 15 lines. A longer one is a second set of pillars.
   Keep the last block of the template, "How Carl scores", as it is: the three questions, the
   weights, the two bars and one worked example. The owner sees how a line becomes a score.
5. Write `status: draft` at the top, and a queue line: "Approve the rubric of the Gatekeeper",
   choices `approve|change`. The owner edits it in their own words, then `status: approved`
   and the date.

## B. The scoring (Carl)

Three questions per item. Each answer is 0, 0.5 or 1. Nothing in between: an agent that gives
0.73 pretends a precision it does not have.

| Question | Weight | 1 | 0.5 | 0 |
|---|---|---|---|---|
| **Fit**: does it serve one pillar of the rubric? | 0.5 | squarely the topics of one pillar | near a pillar, the angle is a stretch | no pillar |
| **Substance**: does it bring something to keep? | 0.3 | data, code, a measured result, or a failure told honestly | a clear idea or method, no proof yet | an announcement, a launch, an opinion |
| **Use**: could it become a piece for this audience? | 0.2 | new for the memory and useful to the audience of the rubric | useful but narrow, or close to something already in memory | already in memory, or not for this audience |

**Score = 0.5 x Fit + 0.3 x Substance + 0.2 x Use.** A line of "Hard no": the score is 0.

What the weights mean, said simply:
- **No pillar, no pass.** With Fit at 0 the best score is 0.5. With Fit at 0.5 an item needs
  full Substance and full Use (0.75).
- An on-pillar item with real substance passes (0.8 and up). An on-pillar announcement stops at
  0.6 or 0.7.

**The two bars, together.** Keep 0.7 or more, and never more than 20, best first. Equal scores:
the pillar that has fewer items so far goes first, then the newest. The number of the day is
what it is: 4 good items is a good morning, the list is never padded to reach 20.

### Steps for Carl
1. Read `brain/1-self/rubric.md`. Missing, or `status: draft`: stop. Queue line "The Gatekeeper
   needs an approved rubric", and say Serena drafts it (part A). Never score with your own taste.
2. Read `brain/2-ears/radar/<date>.json` (today, or the date asked). Missing: say "no radar
   today", suggest `python ops/tools/radar.py`. You never run the radar yourself.
3. Already in memory? For each link: `python ops/tools/memory_index.py find "<link>"`. Found:
   Use is 0, and the skipped line says "already in memory".
4. Score every item with the three questions, from its title and text only. Never from what you
   know of the authors, the lab or the brand. Every item: the radar gives each one the same
   detail on purpose. The same link under two sources (an arXiv paper found by both searches):
   score it once, list it once, and the second copy is a skipped line "duplicate of <title>".
   A duplicate never takes two of the 20 places.
5. Keep the two bars. Write the shortlist (format below).
6. Queue line: "Shortlist of <date>: <k> kept out of <n>", file the shortlist, choices
   `picked|nothing today`.

## Output format
`brain/2-ears/shortlist/<date>.md`:

    # Shortlist of <date>

    > Written by Carl, the Gatekeeper. <n> items of radar/<date>.json scored against the rubric
    > approved on <date>. <k> kept: 0.7 or more, 20 at most, best first. Keep one with /capture.

    ## Kept

    ### 1. <title>
    - score: 0.85 (fit 1, substance 1, use 0.5), pillar: <pillar>
    - why: <one sentence> Rubric: "<the line of the rubric it meets, quoted>"
    - <source name>, <date>, <authors>
    - /capture <link>

    ## Skipped

    | Score | Title | The weak point |
    |---|---|---|
    | 0.60 | <title> | substance 0: a launch, no result |

Your final message: `Shortlist of <date>: <k> kept out of <n> (<count per pillar>). Top 3: <titles>.`
Then the path.

## Check before you finish
- [ ] Every item of the radar data is in the shortlist, kept or skipped. Count them.
- [ ] No kept item under 0.7, never more than 20.
- [ ] Every kept item quotes a real line of the rubric, word for word.
- [ ] Every score is 0.5 x Fit + 0.3 x Substance + 0.2 x Use, with answers 0, 0.5 or 1.
- [ ] Nothing was captured, summarized or fetched.

## Common mistakes
| Mistake | What happens | Do this instead |
|---|---|---|
| Scoring without a rubric, "from the pillars" | Carl's taste, not the owner's | Stop, Serena drafts, the owner approves |
| Scores like 0.73 | False precision, scores that cannot be explained | 0, 0.5 or 1 per question, then the formula |
| Scoring a famous lab higher | The brand wins over the content | Title and text only |
| Padding the list to 20 | The owner reads weak items again | Keep what passes, even 3 |
| Dropping the skipped list | The owner cannot see what was cut, nor correct the rubric | Every item appears, kept or skipped |
| Capturing the kept items | The inbox fills without the owner | The owner picks, with `/capture` |
| Scoring what the owner captured by hand | The owner's choice is judged again | The gate is for the radar only |

## When the owner disagrees
The owner says "this one should have passed" or "why is this here?": it is the rubric that is
wrong, not the score. Note the case in the queue for Serena. She proposes the smallest change to
the rubric, the owner approves it. Carl never adjusts a score by hand.

The rubric changed and was approved again: the shortlist of the day was written under the old
one. Carl scores the same day again, at once, and replaces it. Nobody waits for the owner to ask.
