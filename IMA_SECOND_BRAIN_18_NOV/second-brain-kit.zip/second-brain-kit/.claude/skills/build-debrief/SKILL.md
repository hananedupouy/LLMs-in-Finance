---
name: build-debrief
description: Build Step D, Debrief (what worked, what to change), of your own brain. Launch it with /build-debrief. It explains the seven stages of the feedback loop in one screen, checks what exists, creates what is missing, asks which result you measure, at which moments and against which baseline, calls Dexter, Diane, Serena, Sacha and Diego in order, stops at the gate where you decide each change, and ends on the "Done when" checklist of the step, ticked honestly. Use it once a few pieces went out. It changes no rule without your decision.
user-invocable: true
---

# Build Step D: Debrief

## When to use
- A few pieces went out through Step N and you want the brain to learn from them: review
  each piece, then change the lessons, the pillars and the writing rules when the evidence
  says so. With fewer than 3 pieces the loop runs and proposes nothing.
- Not for the weekly run of a brain that is built: say "weekly council" or "monthly tune-up"
  to Alfred.

You are the session the reader talks to. You explain, you check, you ask, you call the agents,
you tick. You write no card, no lesson and no proposal yourself.

## Inputs
- `brain/BRAIN.md` (`sample_data`), `brain/5-narrate/drafts/<slug>/piece.md` and `review.md`,
  `brain/5-narrate/posted/`: the pieces that went out.
- `brain/1-self/pillars.md`, `voice.md`, `writing/<kind>.md`: the files the loop may change.
- `brain/6-debrief/`, and `brains/_template/6-debrief/` if it is there.
- The agents `dexter`, `diane`, `diego`, `serena`, `sacha`, `sosie`, their skills, and the tools
  `ops/tools/scorecard.py`, `edit_diff.py`, `ledger.py`.

## Steps
1. **Explain the loop in one screen.** Show this to the reader before anything else.

   Seven stages. One agent and its skill at each stage.

   | Stage | Who | Skill | Output |
   |---|---|---|---|
   | 1. Measure | Dexter | `scorecard` (tools `scorecard.py`, `edit_diff.py`) | numbers at 24 h, 72 h, 7 days against a fixed baseline, and what the owner changed between the draft and the posted text |
   | 2. Review each piece | Diane | `post-debrief` | one card per piece: numbers, verdict, the owner's edits, what the Editor had flagged, one hypothesis |
   | 3. Propose | Diane (lesson), Serena (pillar), Sacha (writing) | `lessons-ledger`, `pillar-review`, `writing-tune-up` | one proposal file per change |
   | 4. Challenge | Diego | `change-challenge` | ACCEPT, NEEDS MORE EVIDENCE or REJECT, per proposal |
   | 5. Decide | the human | (queue) | accept, trial for 4 weeks, reject, or reword |
   | 6. Apply | the owner of the file: Diane `lessons.md`, Serena `pillars.md`, Sacha `voice.md` and `writing/<kind>.md` | same skills | the file changed, one line in the ledger |
   | 7. Verify | Sosie now (Double test must not drop), Dexter and Diane at the review date | `double-test`, `scorecard` | kept, extended or rolled back |

   Three levers: **lessons** (weekly, at most 10, each with evidence from 2 pieces), **pillars**
   (monthly, one move at a time), **writing rules** (monthly, the smallest edit, with a before
   and after example). Triggers that open a proposal:

   - Pillar: 4 pieces in a row under the baseline, or above it. 2 pieces outside every pillar
     above the baseline. No piece on a pillar for 4 weeks.
   - Writing: the same correction by the owner in 3 of the last 8 pieces. The same FIX from the
     Editor 3 times in a month. A lesson confirmed for 4 weeks is promoted into the writing rules.
   - Any time: the owner says "it's not me". That goes straight to the rules, no numbers needed.

   The owner's taste beats the numbers: a proposal that contradicts `rules.md` is dropped by Diego.

2. **Check the brain and the kit.** No piece in `posted/`: stop, `/build-narrate` first. An
   agent file is missing: name it, skip its stage, mark its lines of the checklist "not built".
3. **Show what exists.** The pieces that have a draft and a record. In `brain/6-debrief/`:
   the readings in `metrics/posts.json`, the baseline (set or empty), the cards, the weekly
   reviews, `lessons.md`, the proposals with their status, the ledger.
4. **Create what is missing.** The folders `metrics/edits/`, `reviews/posts/` and `changes/`:
   copy what `brains/_template/6-debrief/` holds and the brain lacks, never overwrite. Not
   `lessons.md`, not a scorecard, not `changes/ledger.md`: Diane and the tools write them.
5. **Ask, in one message:**
   - "Which result do you measure?" The tool reads four counts per reading: `views`,
     `reactions`, `comments`, `reposts`. A result that does not fit (a status report has no
     views): the answer is "no numbers". Then leave `posts.json` out, and the loop runs on
     the reader's edits and the Editor's findings only.
   - "At which moments?" 24 h, 72 h and 7 days. One reading per moment. Keep them forever.
   - "What is your baseline?" The medians of your long history, and where they come from. No
     history: your first 8 weeks become the baseline. It is fixed once, and never recomputed
     from the pieces being judged.
6. **Write the data, with the reader's own figures only.** They dictate, you type.
   - `brain/6-debrief/metrics/baseline.json`:
     `{"views_7d_median":0,"reaction_rate_median":0.0,"comment_rate_median":0.0,"source":"..."}`
   - `brain/6-debrief/metrics/posts.json`: `{"sample_data": false, "posts": [...]}`. Each piece
     has `slug`, `date`, `title`, `pillar`, `kind`, `format`, `hook_type`, `chars`, `draft`,
     `posted`, and `readings` with the keys `24h`, `72h`, `7d`, each one holding the four counts.
   - A reading the reader does not have stays out. Figures invented to try the loop:
     `"sample_data": true` here, and `sample_data: yes` in `brain/BRAIN.md`.
7. **Call the agents, in this order.** One at a time. A failed step stops the chain.
   1. Dexter: the edit diffs and the scorecard (stage 1).
   2. Diane: one card per piece (stage 2), then the weekly review.
   3. Propose (stage 3): Diane for a lesson that 2 pieces support, Serena when a pillar trigger
      is met, Sacha when a writing trigger is met. No trigger: no proposal. On a first run
      that is the normal result.
   4. Diego, on each proposal (stage 4).
   5. The gate (stage 5). Show each proposal with its challenge. The reader chooses: accept,
      trial 4 weeks, reject or reword.
      `python .claude/skills/run-trace/scripts/queue.py resolve <id> --decision "<their words>"`
   6. Apply (stage 6): call the owner of the file with the decision, word for word.
   7. Verify (stage 7): Sosie runs the Double test after a change to a Self file. The review
      date is in the ledger: tell it to the reader.
8. **Finish on the checklist.** Tick only what you verified, with the evidence.

## Output format
Your last message, after the paths written:

    STEP D, DEBRIEF: done when
    [x] Each result has three readings at the same three moments         (4 of 4 pieces)
    [x] You can say, for your last result, "reach problem" or "conversion problem"
        (<slug>: reach problem, score 38)
    [ ] lessons.md has between 3 and 10 lessons, each with evidence from two results   (found: 1)
    [ ] At least one lesson was rejected by the Skeptic, and one was retired by the numbers
    [ ] Your last draft was checked against the lessons before you saw it
    Numbers: real | sample numbers | none in this brain
    Not built: <what, and which agent file was missing>
    Next: the weekly council, on <date>. Then the monthly tune-up.

The list is the "Done when" of Step D. After a first run most boxes
stay empty: that is the honest result.

## Check before you finish
- [ ] The reader saw the seven stages before the first agent ran.
- [ ] Every figure in `posts.json` and `baseline.json` came from the reader, or is marked sample.
- [ ] No Self file and no lesson changed without the reader's decision in the queue.
- [ ] Each change applied has its proposal, its challenge and its line in the ledger.
- [ ] Each tick has a path or a count behind it. An item you could not verify stays empty.

## Common mistakes
| Mistake | What happens | Do this instead |
|---|---|---|
| Comparing with last week | The yardstick sinks with the results | A fixed baseline |
| Inventing numbers to see the loop turn | Lessons built on nothing | Mark them as sample, or run with no numbers |
| Forcing a proposal on the first run | A rule made from one piece | "No trigger met" is a result |
| Skipping Diego to save time | A wrong lesson steers every future piece | Every proposal is challenged |
| Applying a change the reader has not decided | The brain changes who the owner is | The queue, then the owner of the file |
| Reading the numbers every hour | Anxiety, no information | Three moments |
