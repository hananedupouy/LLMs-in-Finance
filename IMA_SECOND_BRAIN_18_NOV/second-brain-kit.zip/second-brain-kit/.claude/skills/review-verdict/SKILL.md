---
name: review-verdict
description: The shared verdict format and the six independence rules of the four reviewers, Sosie, Cato, Nora and Diego. Use it each time a reviewer writes its review file (Double test, fact-check, draft review, challenge of a change), so that the four verdicts have the same shape and Mission Control can read them. Not for producing or repairing the thing under review.
user-invocable: false
---

# The reviewer's verdict

## When to use
- You are a reviewer and you are about to write your review file.
- You are Alfred and you must read a verdict to decide the next step of a routine.
- Not to produce, improve or repair the artifact. A reviewer who repairs becomes a second
  author, and then nobody reviews.

## Inputs
You read three things only, with an empty context: the artifact, the reference it claims to come
from, and the owner's rules (the Self files and the lessons).

| Reviewer | Artifact (its author) | Reference | Your one file |
|---|---|---|---|
| sosie | the Self files (Sofia, Sacha, Serena) | the Self files themselves | `brain/1-self/_tests/<date>-double-test.md` |
| cato | a summary (Chloe) | `brain/2-ears/sources/<slug>.md` | `brain/3-condense/summaries/<slug>/fact-check.md` |
| nora | a draft (Naomi) | the checked summary, the Self, the lessons | `brain/5-narrate/drafts/<slug>/review.md` |
| diego | a change proposal (Diane, Serena, Sacha) | the numbers, `rules.md`, `not-me.md` | `brain/6-debrief/changes/<id>-challenge.md` |

The loop number comes from your task. Not given: 1 if your review file does not exist yet, else 2.

## Steps
1. **Check the six independence rules.** One does not hold: stop and say which one.
   1. Another agent: you did not produce what you review.
   2. Fresh eyes: you start from the files. You do not read the author's message or reasoning.
   3. Three things only: the artifact, its reference, the owner's rules.
   4. No edit: you write one file, your review. You never touch the artifact.
   5. A verdict with evidence, not a rewrite: each finding names the exact place and quotes the
      source line or the rule it breaks.
   6. Two loops at most: after loop 2 the artifact goes to the owner with the open findings.
2. **Run the checks of your own skill**: `double-test`, `fact-check`, `edit-review` or
   `change-challenge`.
3. **Give each finding a level.**
   - `blocker`: it is false, it contradicts the source or a rule of the owner, or the reference
     could not be opened.
   - `major`: it must be corrected before the artifact is used.
   - `minor`: worth saying. It stops nothing.
4. **Derive the verdict from the levels.** Do not soften it.

   | Verdict | When | What happens next |
   |---|---|---|
   | BLOCK | at least one blocker | It stops. The owner is told why |
   | FIX | no blocker, at least one major | Back to the author, once, with the findings |
   | PASS | no blocker, no major. Minors are listed | The routine goes on |

   Diego uses three other words: ACCEPT (fit to show the owner), NEEDS MORE EVIDENCE (it may
   come back with more), REJECT (it stops, for example against `rules.md`).
5. **Fill "Not checked"**, write your file, and give the same verdict word to `--verdict` in
   your stop line.

## Output format
    # Review of <path of the artifact>
    - reviewer: cato
    - date: 2026-11-13
    - verdict: PASS | FIX | BLOCK
    - loop: 1

    ## Findings
    | # | Level | Where (exact quote) | Problem | Evidence (exact quote of the source or rule) |
    |---|---|---|---|---|
    | 1 | blocker | "adoption grew by 73 %" | The figure contradicts the source | source, "Results": "adoption grew by 37 %" |

    ## Not checked
    - what you could not verify, and why ("nothing" is allowed)

Rules of the format:
- The title and the four header lines come first, in this order, one `key: value` per line, with
  ONE verdict word. Your own lines may follow `loop` (Sosie: `score`, `previous`. Cato: `compared`).
- "Where" and "Evidence" are exact quotes, in double quotes, short enough to be found with a
  search. Something that is absent: write `missing`. Replace a `|` inside a quote with `/`.
- One finding per row, numbered from 1. No finding: keep the two header rows of the table and
  write "No finding." under it.
- "Not checked" is mandatory. Your own sections come after it (for example `## Checks run`).
- Loop 2: the top of the file describes loop 2 and says, for each finding of loop 1, fixed or
  still open. The header and the table of loop 1 stay unchanged under `## Loop 1 (kept)`.

## Check before you finish
- [ ] The verdict follows the table. One blocker is a BLOCK, whatever the rest.
- [ ] Every finding has the exact words of the artifact and the exact words of the source or rule.
- [ ] No finding gives the corrected text. You name the place and the rule.
- [ ] "Not checked" is filled in. A PASS covers only what you verified.
- [ ] You wrote one file, yours. The artifact is untouched.
- [ ] The verdict word in the file and in your stop line are the same.

## Common mistakes
| Mistake | What happens | Do this instead |
|---|---|---|
| A silent PASS when the reference would not open | The worst outcome: unverified work looks verified | BLOCK, and "Not checked" says why |
| A finding with no quote ("the tone is off") | The author cannot fix it | Quote the place and the rule, or drop the finding |
| Rewriting "to help" | Two authors, zero review | Place, problem, evidence. Nothing more |
| Softening a blocker into a FIX | A false statement goes on | The table decides, not your mood |
| Reading the author's reasoning first | You agree with it | The artifact, the reference, the rules. Only these |
| A third loop | Agents argue in circles | After loop 2 the owner gets the open findings |
| Two verdict words ("PASS with reserves") | The screen and Alfred cannot read it | One word. The reserves are minor findings |
