---
name: recall
description: How Alfred answers a memory question from the files only, such as "what do I know about X?", "did I already use it?", "have I read something on Y?", "what did I learn about Z?". Search the memory index, read the summaries found, check what was drafted and what went out, answer in a few lines, cite every file used, and say plainly when the memory holds nothing. Works in a new session with no history. Never an answer from general knowledge without saying so.
user-invocable: false
---

# Recall: answer from the memory

## When to use
- The owner asks what the brain knows about a subject, a source, a person, a figure.
- The owner asks whether something was already read, drafted or used.
- Before a routine starts on a subject, to say "you already have this".
- Not to search the web, not to summarize a new source (Chloe), not to give your own view.

A new session knows nothing. It reads the folders. The memory is plain files, on four shelves:

| Shelf | Folder | It holds |
|---|---|---|
| Who I am | `brain/1-self/` | the portrait, the voice, the pillars, the rules |
| What I know | `brain/3-condense/` | the index, one faithful summary per source, its fact-check |
| What I did | `brain/5-narrate/` | the drafts, and in `posted/` what really went out |
| What I learned | `brain/6-debrief/` | the cards of the pieces, the lessons, the changes |

## Inputs
- The question, in the owner's words.
- `brain/BRAIN.md`: the active brain. The answer is about this brain only.
- Nothing from this conversation counts as memory unless a file says it.

## Steps
1. **Turn the question into two or three searches**: the subject, another word for it, a name.
2. **Search the index**, once per search:
   `python ops/tools/memory_index.py find "<words>"`
   Each line found gives: date, slug, title, source, pillar, status, the path of the summary.
   A source that starts with `my-knowledge/` is the owner's own material: say "yours" next to
   it in the answer. Any other source is from outside: say where it came from.
3. **Read each summary found**, in full: `brain/3-condense/summaries/<slug>/condensed.md`. Then
   the first lines of `fact-check.md` next to it: the verdict, or "no fact-check yet".
4. **Did I already use it?** Three places, in this order:
   - the status of the index line: `new`, `summarized`, `checked`, `drafted` or `used`;
   - `brain/5-narrate/posted/`: search the slug and the words with Grep. A file there means it
     went out, on the date in its name;
   - `brain/5-narrate/drafts/<slug>/`: a draft exists, with or without its review.
   The index and the folders disagree: say both, do not pick one.
5. **The other shelves**, with Grep on the same words:
   - `brain/6-debrief/lessons.md` and `brain/6-debrief/reviews/`: what was learned about it;
   - `brain/2-ears/inbox/`: captured, not read yet;
   - `brain/1-self/pillars.md`: the pillar it belongs to.
6. **Answer in a few lines** (format below). Each fact carries the file it comes from. Copy
   figures exactly, from the summary.
7. **The memory holds nothing**: say it in the first line, and say where you looked. Offer two
   ways on: capture a source (`/capture`), or an answer from general knowledge, labelled as not
   from the memory, only if the owner asks for it.
8. **Leave the trace**, two lines, with the routine `memory-question`: the start line before the
   first search, the stop line after the answer (skill `run-trace`).
   `python .claude/skills/run-trace/scripts/log_run.py start --agent alfred --routine memory-question --summary "Memory question: <X>"`
   `python .claude/skills/run-trace/scripts/log_run.py stop --agent alfred --status done --summary "Memory question: <X>. <found N sources | nothing found>"`

## Output format
    From the memory of <brain name>:

    What you know about <X>
    - <fact, with its figure> [brain/3-condense/summaries/<slug>/condensed.md]
    - <fact> [brain/3-condense/summaries/<slug>/condensed.md]
    Source: <title>, read on <date>. Fact-check: PASS [.../fact-check.md]

    Did you already use it?
    - <No, never | Drafted, not sent | Yes, on <date>> [brain/3-condense/index.md, <the file in posted/ or drafts/>]

    What you learned about it        (only if a file says something)
    - <lesson, quoted> [brain/6-debrief/lessons.md]

    Files read: <every path>

When nothing is found:

    The memory of <brain name> holds nothing about <X>.
    I searched: the index ("<words>", "<words>"), posted/, drafts/, the lessons, the inbox.
    You can capture a source with /capture. I can also answer from general knowledge if you
    ask: it would not come from your memory, and I will say so.

Five to ten lines. No introduction, no advice the owner did not ask for.

## Check before you finish
- [ ] Every sentence of the answer has a file path next to it.
- [ ] You opened each file you cite. You did not answer from the index line alone.
- [ ] "Used" comes from the status and from `posted/`, not from a guess.
- [ ] Figures are copied from the summary, with their unit.
- [ ] Nothing comes from general knowledge, or it is labelled as such, in so many words.
- [ ] An unchecked summary is called unchecked.
- [ ] The answer fits in ten lines. The run has its start line and its stop line.

## Common mistakes
| Mistake | What happens | Do this instead |
|---|---|---|
| Answering from what you know of the subject | The owner believes they read it | Files only, or the label "not from your memory" |
| "I think you wrote about this" | A false memory | The index status and the file in `posted/` |
| Citing the index and not opening the summary | A title is not knowledge | Read the summary, cite it |
| One search word | A summary under another word is missed | Two or three searches |
| Hiding that nothing was found | The owner trusts an empty answer | Say it in the first line |
| A long report | The owner asked a question | Five to ten lines, with paths |
