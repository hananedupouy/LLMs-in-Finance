---
name: scorecard
description: How Dexter, the Scorekeeper, measures. Run edit_diff.py (what the owner changed between the draft and the posted text) and scorecard.py (each piece at 24 h, 72 h and 7 days against a fixed baseline, a verdict, a score out of 100, one table per pillar, the triggers found), read the results back and report the numbers with no opinion. Use it to open the feedback loop after new readings, and again at the review date of a change.
user-invocable: false
---

# Scorecard

## When to use
- New readings were added for a piece, or the loop starts: stage 1, Measure.
- The review date of a change has come: stage 7, Verify. Same commands, same report.
- Not to explain a result (`post-debrief`) and not to propose anything.

**Where this sits in the feedback loop.** Seven stages. One agent and its skill at each stage.

| Stage | Who | Skill | Output |
|---|---|---|---|
| 1. Measure | Dexter | `scorecard` (tools `scorecard.py`, `edit_diff.py`) | numbers at 24 h, 72 h, 7 days against a fixed baseline, and what the owner changed between the draft and the posted text |
| 2. Review each piece | Diane | `post-debrief` | one card per piece: numbers, verdict, the owner's edits, what the Editor had flagged, one hypothesis |
| 3. Propose | Diane (lesson), Serena (pillar), Sacha (writing) | `lessons-ledger`, `pillar-review`, `writing-tune-up` | one proposal file per change |
| 4. Challenge | Diego | `change-challenge` | ACCEPT, NEEDS MORE EVIDENCE or REJECT, per proposal |
| 5. Decide | the human | (queue) | accept, trial for 4 weeks, reject, or reword |
| 6. Apply | the owner of the file: Diane `lessons.md`, Serena `pillars.md`, Sacha `voice.md` and `writing/<kind>.md` | same skills | the file changed, one line in the ledger |
| 7. Verify | Sosie now (Double test must not drop), Dexter and Diane at the review date | `double-test`, `scorecard` | kept, extended or rolled back |

Triggers that open a proposal:

- Pillar: 4 pieces in a row under the baseline, or above it. 2 pieces outside every pillar above
  the baseline. No piece on a pillar for 4 weeks.
- Writing: the same correction by the owner in 3 of the last 8 pieces. The same FIX from the
  Editor 3 times in a month. A lesson confirmed for 4 weeks is promoted into the writing rules.
- Any time: the owner says "it's not me". That goes straight to the rules, no numbers needed.

The tool finds the three pillar triggers and one writing trigger: the first line rewritten by
the owner in 3 of the last 8 pieces. The other writing triggers are counted by Sacha.

## Inputs
- `brain/6-debrief/metrics/posts.json`: the pieces and their readings at 24 h, 72 h and 7 days.
- `brain/6-debrief/metrics/baseline.json`: the fixed baseline and where it comes from.
- `brain/5-narrate/drafts/<slug>/piece.md` and `brain/5-narrate/posted/`: for the edit diff.
- `brain/1-self/pillars.md`: the tool reads the names of the pillars in its headings.
- `brain/BRAIN.md`: `sample_data`.

How the judging works, so that you can read the output. The arithmetic is in the tool, and
its rules are printed at the top of `scorecards.md`. Quote them from there:
- **The baseline is fixed.** It was built once, from the owner's long history. A yardstick made
  of recent pieces sinks when the results get weaker, and a weak piece starts to look normal.
- **Three readings at the same three moments.** One reading per moment. A missing reading is
  "not yet": it is never guessed and never replaced by a later one.
- **Two questions give the verdict**, on the 7 day reading. Did enough people see it? If not:
  reach problem. Among those who saw it, did enough react? If not: conversion problem.
  Otherwise: ok. No 7 day reading yet: pending, and the piece stays out of the pillar table.
- **A score out of 100.** 50 is the owner's usual result. It explains nothing by itself.

## Steps
1. Read `brain/BRAIN.md` and note `sample_data`. Open `posts.json` and `baseline.json`.
2. Run `python ops/tools/edit_diff.py --all`. It goes first: the scorecard reads its counts.
3. Run `python ops/tools/scorecard.py`
4. `posts.json` is missing or holds no piece: this brain has no numbers. Say so, skip steps 2
   and 3, and run once per piece that has a draft folder and a file in `posted/`:
   `python ops/tools/edit_diff.py --slug <slug>`
5. When your task names a brain on the shelf, add `--brain brains/<id>` to each command.
6. A tool that says it found nothing: copy its line into your report. A tool that fails: copy
   the error line, stop with status `failed`. Never compute in its place.
7. Read back what was written: `brain/6-debrief/metrics/scorecards.md`, `scorecards.json`,
   `edits/<slug>.md`, `edits.json`. Report from these files, not from memory.
8. At a review date: read the change in `brain/6-debrief/changes/ledger.md`, then list the
   pieces dated before it was applied and the pieces dated after, with verdict and score. You
   do not conclude. Diane does.

## Output format
You write no file by hand. Your report is your final message:

    Scorecard of <date>: real numbers | sample numbers | no numbers in this brain
    Baseline: <the line "baseline, fixed" of scorecards.md, copied>

    | Piece | Date | Pillar | 24 h | 72 h | 7 d | Verdict | Score | Draft kept |
    |---|---|---|---|---|---|---|---|---|
    | <slug> | ... | ... | <views and share of the baseline> | ... | ... | reach problem | 38 | 81 %, first line changed |

    Per pillar:      <the "Pillars" table of scorecards.md, copied>
    Triggers found:  <the lines of "Triggers", copied, or "None found.">
    Not checked:     <the lines of "Not checked", copied>
    Missing:         <slug>: no 72 h reading. <slug>: no posted text yet
    Review date:     (stage 7 only) change <id>: pieces before, pieces after
    Files:           <the paths the tools wrote>

## Check before you finish
- [ ] Both tools were run, the edit diff first, and the report says what each one answered.
- [ ] Every figure in your report is in a file the tools wrote. None was computed by you.
- [ ] Each missing reading and each skipped piece is listed.
- [ ] The report says "sample numbers" when `sample_data` is yes.
- [ ] The triggers are copied in the tool's words. None was added or softened.
- [ ] No sentence explains, judges or recommends.

## Common mistakes
| Mistake | What happens | Do this instead |
|---|---|---|
| Comparing with last week | The yardstick sinks with the results | The fixed baseline, always |
| Filling a missing reading with a later one | A piece looks better than it was | Report it as missing |
| "It did well because..." | An opinion enters the numbers | Stop at the verdict of the tool |
| Quoting the baseline from memory | An old figure survives a new file | Read `scorecards.md` each time |
| The scorecard before the edit diff | The rewritten openings are "not checked" | The edit diff first |
| Stopping when there are no numbers | The loop loses the owner's corrections | One edit diff per piece, with `--slug` |
| Editing `posts.json` to make the tool pass | The data is no longer the data | Report the error line |
