---
name: build-orient
description: Build Step O, Orient (what to do next), of your own brain. Launch it with /build-orient. It checks that a rhythm is written and that the memory holds candidates, asks the few questions it needs, calls Serena for the rhythm if it is missing and Olivia for the plan of the next two weeks (two proposals per slot), lets you choose, and ends on the "Done when" checklist of the step, ticked honestly. Use it after /build-condense.
user-invocable: true
---

# Build Step O: Orient

## When to use
- The memory holds a few checked summaries or captured ideas, and you want to know what to
  produce next.
- You have no rhythm yet (which kind of piece, on which days) and want to set one.
- Not to write the pieces (`/build-narrate`). Not to change the pillars: the plan follows them.

A store of good material does nothing by itself. This step crosses what you have, who you are
and when you act, and puts two options per slot in front of you. You choose. You stop searching.

You are the session the reader talks to. You check, you ask, you call the agents, you tick.

## Inputs
- `brain/BRAIN.md` (`piece_kinds`), `brain/1-self/pillars.md` (the pillars, their share, the
  rhythm), `rules.md`, `not-me.md`.
- `brain/3-condense/index.md`, `brain/2-ears/inbox/` (cards with `type: idea`),
  `brain/6-debrief/lessons.md` and `brain/5-narrate/posted/` if they exist.
- `brain/4-orient/plan.md`, if a plan was already made.
- The agents: `.claude/agents/olivia.md`, and `serena.md` for the rhythm.

## Steps
1. **Check the brain.** No `brain/BRAIN.md`, or not the reader's: stop, `/build-self` first.
2. **Check the kit.** `olivia.md` exists: if not, name it and stop. `serena.md` is needed only
   when the rhythm is not written.
3. **Show what exists.**
   - The rhythm: quote the lines of `pillars.md` that give it, or say "not written".
   - The candidates: the lines of the index per status, and the idea cards. Fewer than four
     candidates: say that the plan will have holes, and that `/build-ears` and
     `/build-condense` fill the store.
   - The plan: its dates and its status, or "none". Its "Rejected" list, if any.
4. **Create what is missing.** Nothing by hand: `plan.md` is Olivia's file, the rhythm is
   Serena's. Copy what `brains/_template/4-orient/` holds and the brain lacks, never overwrite.
5. **Ask, in one message**, only what is not written yet:
   - "Which kind of piece, on which days? Which days stay empty?"
   - "Can you hold that for three months? If you hesitate, take one slot less."
   - "Is something fixed in the next two weeks that the plan must respect (an event, a
     deadline, days off)?"
6. **Call the agents, in this order.**
   1. Serena, only if the rhythm is not written: give her the reader's answers, word for word.
      The rhythm is hers to write in `pillars.md`, by her own rules. The reader says yes in
      the queue before Olivia uses it.
   2. Olivia: the plan of the 14 days that start tomorrow, with what is fixed. She writes
      `brain/4-orient/plan.md` and adds the queue line.
7. **Let the reader choose.** For each slot: A, B, new proposals, or a note of their own.
   Time it. Then call Olivia with the choices, word for word: she marks the option kept, moves
   each refused proposal to "Rejected", and sets `status: approved`.
8. **Finish on the checklist.** Tick only what you verified, with the evidence.

## Output format
Your last message to the reader:

    Step O, Orient
    Plan:     brain/4-orient/plan.md, <first day> to <last day>, status <proposed or approved>
    Slots:    <n> with two proposals, <n> with one, <n> empty

    Done when
    [x] Your rhythm is written, and you can hold it for three months
        proof: pillars.md, "<the line>", and you said yes
    [x] Each slot of the next 7 days shows two proposals or one ready piece
        proof: 3 slots of 3 in plan.md
    [ ] A rejected proposal never came back
        not yet: 1 proposal rejected today. Check it when the next plan is built
    [ ] An idea captured on Monday has 3 angles by Tuesday
        not built: this kit has no agent that turns an idea into angles
    [x] Choosing your week takes 10 minutes
        proof: you took 6 minutes

    Next: /build-narrate

The list is the "Done when" of Step O. One line needs the Angle Finder, an
agent that is not in this kit: it stays empty, with the reason. The line about rejections can
be ticked only from the second plan on, when "Rejected" was carried over and obeyed.

## Check before you finish
- [ ] The rhythm in `pillars.md` was written by Serena and approved by the reader.
- [ ] The plan was written by Olivia. Every proposal names an index slug or an inbox file.
- [ ] The reader chose. You did not approve the plan for them.
- [ ] A slot with one proposal or none is reported, not hidden.
- [ ] Each tick has its evidence. What cannot be verified yet stays empty, with the reason.

## Common mistakes
| Mistake | What happens | Do this instead |
|---|---|---|
| A rhythm copied from someone else | It is dropped after three weeks | The reader's own days, one slot less if in doubt |
| Planning with an empty store | A plan full of holes, or of inventions | Fill the store first: Ears, then Condense |
| Adding "good ideas" of your own to the plan | Subjects with no source behind them | Only the index and the inbox |
| Approving the plan to finish the step | The brain decided for the reader | The reader chooses, slot by slot |
| Ticking "never came back" on day one | Nothing was tested | Leave it empty until the second plan |
| Starting to write during the planning | Neither gets done | Choose first, write after |
