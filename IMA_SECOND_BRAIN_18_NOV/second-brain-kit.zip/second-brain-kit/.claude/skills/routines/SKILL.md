---
name: routines
description: The fixed chains that Alfred follows, step by step. Onboarding, the Production Line (source, summary, fact-check, draft, review, then the owner's gate), the memory question, the Weekly Council, the Monthly Tune-up (the seven stages of the feedback loop) and the brain switch. For each one, who is called, in which order, with which brief, and where the chain stops for the owner. Use it each time the owner launches a routine or answers a gate.
user-invocable: false
---

# The routines

## When to use
- The owner says the phrase of a routine (they are in `ops/routines.json`, shown on the screen).
- The owner answers a gate: resume the routine at the step after it.
- Not to do a step yourself. You call the agent whose job it is, you read what it wrote.

A fixed chain cannot forget the fact-check, cannot skip the owner's approval, and runs the
same way every time. That is why you do not improvise the order.

## Inputs
- The routine, and its subject: a slug, a file, a brain id, or the owner's question.
- `brain/BRAIN.md`: the active brain and its `piece_kinds`.
- The open gates: `python .claude/skills/run-trace/scripts/queue.py list --open`.

## Steps
The six rules of every routine:
1. **One step at a time.** Call the agent, wait for its final message, check that the files it
   names exist, then go on. The brief gives: the routine id, the slug or the paths, the loop
   number, and after a gate the owner's decision, word for word.
2. **A gate stops the chain.** The agent at the gate adds the queue line. Check it with
   `queue.py list --open`, add it yourself if it is missing, tell the owner, stop with
   `--status waiting`. Never assume yes. If the owner does nothing, nothing happens.
3. **A failed step stops the chain.** So does a BLOCK. Report it, never skip it.
4. **A review is never optional.** No fast mode skips Sosie, Cato, Nora or Diego. Two loops
   at most, then the owner gets the open findings.
5. **To resume:** `python .claude/skills/run-trace/scripts/queue.py resolve <id> --decision "<the owner's words>"`,
   then the next step. No routine ever sends or publishes anything. The owner decided on the
   screen: `queue.py list --open` shows it under "Decided on the screen, not applied yet". Do
   not resolve it again: resume the agent that asked with the decision, then `queue.py applied <id>`.
6. **One review per first version.** The owner answers "approve" or "change: ...". A change the
   owner dictates is applied by the keeper of the file and counts as approved: no second queue
   line for the same file, no round to polish.

### Onboarding (`onboarding`)
1. Sofia: the interview, six questions (short) or twelve (full), as the owner chose. Relay each
   question to the owner and each answer back, word for word (continue the same Sofia when you
   can, else call her again: her interview file keeps the state). She ends with a proposal.
   GATE: the owner approves the portrait and the limits.
2. Sofia, with the decision: saves `about-me.md`, `rules.md` and `not-me.md` in `brain/1-self/`.
3. Sacha and Serena, called in the same message: `voice.md` and `writing/<kind>.md`, and
   `pillars.md` with the rhythm. Two GATES that arrive together: the owner answers each.
4. Sosie: the Double test. GATE: the owner reads the three pieces. She judges the voice and the
   limits. The knowledge the pieces needed is listed apart and never counts. On FIX with a
   major gap of the Self, the keeper of that file completes it, then Sosie runs once more.

### Production Line (`production-line`)
0. The source is not in `brain/2-ears/sources/`: Emma files it first ("file this source").
1. Chloe: `brain/3-condense/summaries/<slug>/condensed.md`, index status `summarized`.
2. Cato: `fact-check.md`. PASS: go on. FIX at loop 1: Chloe revises once, then Cato, loop 2.
   BLOCK, or FIX at loop 2: STOP. The summary cannot feed a draft. Cato added the queue line.
3. Naomi: `brain/5-narrate/drafts/<slug>/piece.md`, from a 3-line brief (subject, the path of
   the checked summary, intent). Index status `drafted`.
4. Nora: `review.md`. FIX: Naomi revises, Nora reviews again. Two loops at most.
5. GATE: the owner reads the text (queue line by Nora). The owner edits it and sends it.
6. Later, only on the owner's word "published": ask for the text as it went out and the date,
   then call Noah with the owner's exact words and that text. Noah writes
   `brain/5-narrate/posted/<date>-<slug>.md` (never the draft, never guessed) and sets the index
   status `used`. You never write that record yourself.

### The memory question (`memory-question`)
You answer it yourself, with the skill `recall`. No agent, no gate. Files only, each one cited.

### Weekly Council (`weekly-council`)
1. Dexter: the scorecards and what the owner changed (`scorecard.py`, `edit_diff.py --all`).
2. Diane: one card per piece, the weekly review, the lesson proposals.
3. Diego: challenges each proposal. Only ACCEPT reaches the queue.
4. GATE: the owner accepts, tries for 4 weeks, rejects or rewords each lesson.
5. Diane, with the decisions: applies them to `lessons.md`, one ledger line each.
6. Olivia: the plan of the next two weeks. GATE: the owner chooses for each slot.

### Monthly Tune-up (`monthly-tune-up`): the seven stages of the feedback loop
1. Measure. Dexter: scorecards, edit diffs, the triggers found.
2. Review each piece. Diane: the cards of the month.
3. Propose, only when a trigger is met: Diane (a lesson), Serena (one pillar move), Sacha (the
   smallest writing edit). One proposal file per change in `brain/6-debrief/changes/`.
4. Challenge. Diego: ACCEPT, NEEDS MORE EVIDENCE or REJECT, one challenge file per proposal.
5. Decide. GATE: the owner accepts, tries for 4 weeks, rejects or rewords. STOP here. A change
   refused as a matter of taste: Sofia logs it in `not-me.md`, so it is never proposed again.
6. Apply. The keeper of the file, called with the decision: Diane `lessons.md`, Serena
   `pillars.md`, Sacha `voice.md` and `writing/<kind>.md`. Each writes its ledger line.
7. Verify. Now: Sosie runs the Double test again, on the same three subjects. The score must
   not drop: if it does, GATE "roll back, or keep anyway". At the review date: Dexter, then
   Diane, say kept, extended or rolled back.

### Brain switch (`brain-switch`)
1. `python ops/tools/switch_brain.py list` when the id is not sure.
2. `python ops/tools/switch_brain.py use <id>`.
3. Read `brain/BRAIN.md` again. Tell the owner: the name, what it produces, its `piece_kinds`,
   sample data or not. Forget the Self of the brain you left: every agent reads the new one.
4. List the open gates: some may belong to the brain you left. Say so.

## Output format
After each stop, to the owner:

    Routine: production-line on <slug>          Stopped at: GATE "you read the text"
    Ran:     chloe (done), cato (PASS, loop 1), naomi (done), nora (PASS, loop 2)
    Written: brain/3-condense/summaries/<slug>/condensed.md, .../fact-check.md,
             brain/5-narrate/drafts/<slug>/piece.md, .../review.md
    Waiting: q-004, from nora: "Read the draft: <subject>" (edit / send back with a note / drop)

## Check before you finish
- [ ] Every step of the chain ran, in order, or the chain stopped and you said where and why.
- [ ] No reviewer was skipped. No agent was called for a loop 3.
- [ ] At a gate, the queue line exists, once, and you stopped.
- [ ] Your start line and your stop line carry the routine id.
- [ ] Every path you report exists.

## Common mistakes
| Mistake | What happens | Do this instead |
|---|---|---|
| Doing a small step yourself "to save time" | One agent, two jobs, nobody checks | Call the agent |
| Going on after a FIX at loop 2 | A draft built on an unchecked summary | Stop, the owner decides |
| Treating a queue line as approved | The brain decides for the owner | Wait for the answer |
| Two queue lines for one gate | The owner answers twice | Check `list --open` before you add |
| Passing your own summary of a file in the brief | The reviewer reads your view | Pass paths, not opinions |
| Running two routines on one slug | Two writers on one file | One routine at a time per piece |
