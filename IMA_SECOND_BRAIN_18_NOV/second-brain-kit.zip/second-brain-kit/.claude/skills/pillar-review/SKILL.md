---
name: pillar-review
description: How Serena, the Brand Strategist, reviews the pillars once a month. Read the per-pillar table and the triggers of the scorecard, the piece cards, pillars.md and about-me.md, and propose at most ONE pillar move (rebalance the mix, reword a promise, retire, or add as a 4-piece trial) as a proposal file (lever pillar) that Diego challenges and the owner decides. A pillar is never judged on views alone. Use it for the monthly pillar review and to apply, keep or roll back a pillar change once the owner has decided.
user-invocable: false
---

# Pillar review

## When to use
- Once a month, after the scorecard and the piece cards are up to date.
- The weekly review named a pillar trigger.
- The owner decided on one of your proposals, or says "it's not me" about a pillar: part B.

**Where this sits in the feedback loop.** Seven stages. One agent and its skill at each stage.
This skill is the pillar lever of stage 3 and of stage 6.

| Stage | Who | Skill | Output |
|---|---|---|---|
| 1. Measure | Dexter | `scorecard` (tools `scorecard.py`, `edit_diff.py`) | numbers at 24 h, 72 h, 7 days against a fixed baseline, and what the owner changed between the draft and the posted text |
| 2. Review each piece | Diane | `post-debrief` | one card per piece: numbers, verdict, the owner's edits, what the Editor had flagged, one hypothesis |
| 3. Propose | Diane (lesson), Serena (pillar), Sacha (writing) | `lessons-ledger`, `pillar-review`, `writing-tune-up` | one proposal file per change |
| 4. Challenge | Diego | `change-challenge` | ACCEPT, NEEDS MORE EVIDENCE or REJECT, per proposal |
| 5. Decide | the human | (queue) | accept, trial for 4 weeks, reject, or reword |
| 6. Apply | the owner of the file: Diane `lessons.md`, Serena `pillars.md`, Sacha `voice.md` and `writing/<kind>.md` | same skills | the file changed, one line in the ledger |
| 7. Verify | Sosie now (Double test must not drop), Dexter and Diane at the review date | `double-test`, `scorecard` | kept, extended or rolled back |

Three levers: **lessons** (weekly, at most 10, each with evidence from 2 pieces), **pillars**
(monthly, one move at a time), **writing rules** (monthly, the smallest edit, with a before and
after example). The triggers that open a pillar proposal:

- Pillar: 4 pieces in a row under the baseline, or above it. 2 pieces outside every pillar above
  the baseline. No piece on a pillar for 4 weeks.
- Any time: the owner says "it's not me". That goes straight to the rules, no numbers needed.

The owner's taste beats the numbers: a proposal that contradicts `rules.md` is dropped by Diego.

## Inputs
- `brain/6-debrief/metrics/scorecards.md`: the sections "Pillars" and "Triggers".
- The cards in `brain/6-debrief/reviews/posts/` and the weekly reviews of the month.
- `brain/1-self/pillars.md` (the owner's pillars, one `##` heading each), `about-me.md`, `rules.md`, `not-me.md`.
- `brain/6-debrief/changes/`: your proposals, Diego's challenges, `ledger.md`.
- No numbers in this brain (`posts.json` missing or with no piece): only "no piece on a pillar
  for 4 weeks" can be seen, from the dates in `brain/5-narrate/posted/`. Say so in the evidence.

## Steps
### A. Propose (stage 3)
1. **Bring your open proposals up to date.** Only you write their `status:` line. `challenged`
   after NEEDS MORE EVIDENCE: add the evidence once, or wait for more pieces. `rejected` after
   REJECT: it stops there. `waiting` after ACCEPT, until the owner's decision and part B.
2. **One move a month.** A file `<this yyyy-mm>-pillar-*-proposal.md` already exists: stop.
3. **Recount the triggers yourself.** For each pillar, list its last pieces by date with their
   verdict. A piece at `pending` does not count. No trigger without the pieces named.
4. **No trigger met: propose nothing.** Say "no trigger met" with the counts. It is a result.
5. **Choose the smallest move that answers the trigger.**
   - 4 pieces in a row under the baseline: reword the promise, rebalance the mix down, or retire.
   - 4 pieces in a row above the baseline: rebalance the mix up.
   - 2 pieces outside every pillar above the baseline: add one as a 4-piece trial, never a sixth.
   - No piece on a pillar for 4 weeks: rebalance the mix down, or retire.
6. **Say what else the pillar serves** (its `serves` line): a goal of the owner, the right
   readers answering, trust. Never views alone: such a pillar is reworded or rebalanced, not retired.
7. **A new pillar needs proof.** Quote the line of `about-me.md` that shows the owner has read,
   used or lived the subject. No such line: no proposal. Check `not-me.md` and `rules.md` too.
8. **Write the proposal file.** The id is `<yyyy-mm>-pillar-<nn>`. "Today it says" holds the
   exact lines of `pillars.md` that would change. Then stop: Diego is next. No queue line.

### B. Apply (stage 6), only with the owner's decision
Read the decision in your task, or with `python .claude/skills/run-trace/scripts/queue.py list`.
- accept: ledger decision `accepted`. Make the change.
- trial 4 weeks: `trial`. Make the change, marked "trial until <date>".
- reject: `rejected`. Change nothing, and never propose it again.
- reword: `accepted`. Put the owner's wording in "Proposed", then make the change.
- "it's not me", said of a pillar: `accepted`, with no challenge. Write the proposal with the
  owner's exact words, then make the change at once. Sofia logs the words in `not-me.md`.

1. `python ops/tools/ledger.py add --id <id> --lever pillar --file brain/1-self/pillars.md --summary "<one line>" --decision accepted|trial|rejected --review-date <YYYY-MM-DD>`
2. Edit `pillars.md`: only the lines of the move. Each pillar keeps its `## <name>` heading. A
   trial pillar is `## <name> (trial: 4 pieces, change <id>)`, a retired one becomes a line
   under `## Retired`. The shares still cover the whole mix.
3. `python ops/tools/ledger.py set --id <id> --status applied`
4. Set `status: applied` in the proposal file. On a reject: step 1 only, then `status: rejected`.

### C. Verify (stage 7)
`pillars.md` is a Self file: end your message with "Next: run the Double test again (Sosie), same
three subjects, after change <id>". It must not drop. At the review date the owner chooses.
- Keep: `python ops/tools/ledger.py set --id <id> --status kept`
- Roll back: restore the text of "Today it says", then
  `python ops/tools/ledger.py set --id <id> --status rolled-back --note "<why>"`
- Extend: run the `ledger.py add` line again with `--decision trial` and the new
  `--review-date`, then `ledger.py set --id <id> --status applied --note "extended"`.

## Output format
`brain/6-debrief/changes/<id>-proposal.md`:

    # Change 2026-11-pillar-01: <one line>
    - id: 2026-11-pillar-01
    - lever: pillar
    - proposed_by: serena
    - file: brain/1-self/pillars.md
    - status: proposed

    ## Today it says        (the exact lines of pillars.md that would change)
    ## Proposed             (the exact new lines. The move: rebalance, reword, retire or trial)
    ## Evidence             (the trigger, its count, each piece with its date and verdict)
    ## Expected effect      (what should move, and by when)
    ## Review date          (a date. For a trial: when 4 pieces will have their 7 day reading)
    ## What could be lost   (what the pillar serves besides views, and who would miss it)

## Check before you finish
- [ ] One move, and only one this month. The trigger is named with its count and its pieces.
- [ ] "What could be lost" says what the pillar serves besides views.
- [ ] A new pillar quotes its proof from `about-me.md`. Nothing breaks `rules.md` or `not-me.md`.
- [ ] `pillars.md` changed only after the owner's decision, and the ledger has its line.

## Common mistakes
| Mistake | What happens | Do this instead |
|---|---|---|
| Retiring a pillar after two weak pieces | The owner loses a subject to bad luck | 4 in a row, or nothing |
| Judging on views alone | The owner becomes what the metric likes | Say what else the pillar serves |
| Three moves at once | Nobody knows which one worked | One move a month |
| A new pillar because others do well with it | The owner talks about what was never lived | Proof in `about-me.md` |
| Editing `pillars.md`, then asking | The Self drifts without the owner | Proposal, Diego, the owner, then the file |
