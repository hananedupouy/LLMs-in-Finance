---
name: mission-control-design
description: The design rules of Mission Control and how to add or restyle one of its pages. The look (warm off-white, white cards with large round corners, round avatars in an orange or teal gradient, a monospace pill), the layout of each page, the three files to edit and the checks to run after a change. Use it when the owner wants a new page, another color, another font, a column added to a table, or the same look on another screen. Not to start the screen (skill mission-control).
---

# Mission Control: the design rules

## When to use
- "Add a page that shows ...", "add a column", "change the colors", "make the text bigger".
- A new kind of file appeared in the brain and the screen should show it.
- Not to start or install the screen (`mission-control`). Not to fix a card (`agent-card`).

## The three files
All in `.claude/skills/mission-control/`. No build step, no library.

| File | Holds | Rule |
|---|---|---|
| `scripts/serve.py` | reads the project and returns ONE object at `/api/state` | it reads, it never invents a value |
| `assets/app.js` | one function per page, named `view...`, which returns HTML from that object | every value goes through `esc()` |
| `assets/app.css` | the look. The colors and the font are variables at the top | no color written outside `:root` |

## The look
- **Background** warm off-white `--bg`. **Cards** white, corners of 22 px, a soft shadow. Never a border around a card.
- **Avatars** round, with initials (first name, then title). Orange gradient: a worker. Teal
  gradient: a reviewer. Dark: governance. The human is a rounded square.
- **A step** is a round badge with its letter, in the color of the step (`ops/method.json`).
- **Status** is a dot of 9 px: grey idle, orange and pulsing running, green done, amber waiting, red failed or blocked.
- **A script with no AI** (the radar, the library) has a grey square avatar and the tag "tool".
  Its big state is a flag: a pill in monospace capitals (RUNNING NOW, FINISHED, FAILED).
- **A verdict or a status word** is a pill (`tag()` picks the tone from the word: good, warn, bad, info).
- **Section labels** in the sidebar: small capitals, wide letter spacing, the faintest ink.
- **The pill** at the top right: monospace capitals. It names the active brain, says "real numbers"
  or "sample numbers", and counts what waits for the human.
- **Font** a system stack, rounded when one is installed. No web font, no icon library, no CDN:
  the screen must work with the network off.
- **Words** plain and short. A page starts with one sentence that says what it is for.

## The pages
| Route | Function | Shows |
|---|---|---|
| `#/` | `viewHome` | where you are (the steps, built or not), what to do now, your computer, waiting for you (each card shows its file, its choices and a box "Change something"), running now (since when, for how long), the runs of today |
| `#/team` | `viewTeam` | the chart: human, headquarters, the steps, the reviewers |
| `#/agent/<name>` | `viewAgent` | the card, the skills, the last outputs, the last runs |
| `#/step/<letter>` | `viewStep` | the question of the step, its agents, its files. On Ears, your knowledge: the library script (running now, finished or failed), the totals, the folders. Then the radar: its sources, the runs of each day, what Carl kept |
| `#/memory` | `viewMemory` | the four shelves, the index, the file tree |
| `#/loop` | `viewLoop` | the seven stages, triggers, proposals, ledger, pillars, pieces |
| `#/routines` | `viewRoutines` | each chain, with its gates and its phrase |
| `#/runs` | `viewRuns` | every run, with two filters |
| `#/skills` | `viewSkills` | every skill, who uses it |
| `#/file/<path>` | `viewFile` | one file of the project, rendered, read-only |

## Add a page
1. **Data.** Does `/api/state` already hold what the page needs? Open
   `http://127.0.0.1:8770/api/state` and look. If not, add one reader function in `serve.py`
   and one key in `build_state()`. The reader returns an empty list when the file is missing.
2. **View.** In `app.js`, write `function viewThing() { return `...`; }`. Reuse the helpers:
   `agentRow(a)`, `avatarByName(name)`, `tag(word)`, `fileLink(path)`, `when(ts)`, `num(n)`,
   `sinceLine(ts)` (since when and for how long). A fold that must stay as the owner left it:
   `<details data-keep="name">`. A text the owner types: `data-note`, kept in `S.drafts`.
3. **Route.** Add the page to the object `views` in `render()`, and one line to `renderSide()`.
4. **Empty state.** Say what is missing and which skill or command creates it.
5. **Restart** `serve.py` if you changed it. The page itself only needs a reload.

## Restyle
- A color, a radius, the font: change the variable in `:root` of `app.css`. Nothing else.
- The color of a step: `ops/method.json`, key `color` of the step.
- Bigger text for a projector: `html { font-size: 17px; }` in `app.css`, or zoom the browser.
- The order of the agents inside a step: the list `agents` of the step in `ops/method.json`.

## Check before you finish
- [ ] `python .claude/skills/mission-control/scripts/serve.py --check` runs with no error.
- [ ] `node --check .claude/skills/mission-control/assets/app.js` passes, when node is installed.
- [ ] The page was opened in a browser, and the console shows no error.
- [ ] The new page was looked at with data AND with an empty project.
- [ ] No address outside 127.0.0.1 appears in the three files.
- [ ] Every value shown comes from a file. Nothing is hard-coded to look alive.

## Common mistakes
| Mistake | What happens | Do this instead |
|---|---|---|
| Writing a file's text into the page without `esc()` | A file can inject markup into the screen | `esc()` on every value, `md()` for a markdown file |
| A number computed in `app.js` | The screen and the files disagree | Compute in a tool, write it in a file, show the file |
| A link to a font or a script on the internet | The screen breaks offline, on stage | System fonts, no library |
| A new write route in `serve.py` | The screen becomes a second writer of the brain | One write only: the decision on a queue item |
| A page for one agent only | The screen stops being generic | Read the card and the files, never a name |
