---
name: change-challenge
description: How Diego, the Skeptic, challenges a proposed change of one of the three levers (lesson, pillar, writing) before it reaches the owner. Five checks on each proposal, namely enough evidence, another explanation, sample size said honestly, conflict with rules.md or not-me.md, and reversible and small enough. Verdict ACCEPT, NEEDS MORE EVIDENCE or REJECT in changes/<id>-challenge.md. On ACCEPT, the queue line for the owner. Use it for every proposal file in 6-debrief/changes/ that has no challenge yet.
user-invocable: false
---

# Challenge a change

## When to use
- A file `brain/6-debrief/changes/<id>-proposal.md` exists with no `<id>-challenge.md`.
- A proposal came back with more evidence after NEEDS MORE EVIDENCE: loop 2, the last one.
- Not for a change that comes from the owner's own "it's not me": it is already decided.

**Where this sits in the feedback loop.** Seven stages. One agent and its skill at each stage.
This skill is stage 4. Nothing reaches stage 5 without it.

| Stage | Who | Skill | Output |
|---|---|---|---|
| 1. Measure | Dexter | `scorecard` (tools `scorecard.py`, `edit_diff.py`) | numbers at 24 h, 72 h, 7 days against a fixed baseline, and what the owner changed between the draft and the posted text |
| 2. Review each piece | Diane | `post-debrief` | one card per piece: numbers, verdict, the owner's edits, what the Editor had flagged, one hypothesis |
| 3. Propose | Diane (lesson), Serena (pillar), Sacha (writing) | `lessons-ledger`, `pillar-review`, `writing-tune-up` | one proposal file per change |
| 4. Challenge | Diego | `change-challenge` | ACCEPT, NEEDS MORE EVIDENCE or REJECT, per proposal |
| 5. Decide | the human | (queue) | accept, trial for 4 weeks, reject, or reword |
| 6. Apply | the owner of the file: Diane `lessons.md`, Serena `pillars.md`, Sacha `voice.md` and `writing/<kind>.md` | same skills | the file changed, one line in the ledger |
| 7. Verify | Sosie now (Double test must not drop), Dexter and Diane at the review date | `double-test`, `scorecard` | kept, extended or rolled back |

Three levers: **lessons** (weekly, at most 10, each with evidence from 2 pieces), **pillars**
(monthly, one move at a time), **writing rules** (monthly, the smallest edit, with a before and
after example). Triggers that open a proposal:

- Pillar: 4 pieces in a row under the baseline, or above it. 2 pieces outside every pillar above
  the baseline. No piece on a pillar for 4 weeks.
- Writing: the same correction by the owner in 3 of the last 8 pieces. The same FIX from the
  Editor 3 times in a month. A lesson confirmed for 4 weeks is promoted into the writing rules.
- Any time: the owner says "it's not me". That goes straight to the rules, no numbers needed.

The owner's taste beats the numbers: a proposal that contradicts `rules.md` is dropped by Diego.

## Inputs
You read three things, with an empty context:
1. The artifact: `brain/6-debrief/changes/<id>-proposal.md`, and the file it wants to change.
2. The evidence at its source: `brain/6-debrief/metrics/scorecards.md` and `scorecards.json`,
   `metrics/edits/`, the cards in `reviews/posts/`, the Editor's `review.md` files,
   `lessons.md`, `changes/ledger.md`.
3. The owner's rules: `brain/1-self/rules.md`, `not-me.md`, and `about-me.md` for a new pillar.

`brain/BRAIN.md` tells you if the numbers are sample numbers (`sample_data: yes`).

## Steps
1. **Enough evidence.** Recount it yourself. Do not trust the count of the proposal.
   - Lesson: at least 2 pieces, named. Open each card: does it say what the proposal says?
   - Pillar: is the trigger really met? Name the 4 pieces in a row, the 2 pieces outside every
     pillar, or the 4 weeks with no piece. A new pillar: the proof line is in `about-me.md`.
   - Writing: open each edit diff. Is it the same correction, in 3 of the last 8 pieces? Or
     the same FIX, 3 times in a month? Or a lesson confirmed for 4 weeks?
2. **Another explanation.** The day, the hour, the format, the subject, luck. Write down each
   one that fits the same pieces as well as the proposal does.
3. **Sample size, said honestly.** "3 pieces out of 8", never "most pieces". Does the proposal
   say how small its sample is? With sample numbers, your file says "sample numbers".
4. **Conflict with the owner's taste.** Search `rules.md` and `not-me.md` for what the change
   would break. Look in the ledger and in the retired lessons for a change the owner already
   refused. The owner's taste wins: REJECT, and quote the rule.
5. **Reversible and small enough.** "Today it says" holds the exact text of the file: compare.
   One change only. A review date. Writing: one line, with a before and after example. Pillar:
   one move, and a new pillar comes as a 4-piece trial. Lesson: at most 10 after the change.
6. **Decide.**

   | Verdict | When |
   |---|---|
   | REJECT | Check 4 fails. Or the evidence says the opposite. Or a new pillar has no proof |
   | NEEDS MORE EVIDENCE | Check 1, 2, 3 or 5 fails. Say exactly what is missing |
   | ACCEPT | The five checks hold. It means "fit to show the owner", not "apply" |

7. **Write the challenge file.** You never edit the proposal: its writer updates its status.
8. **On ACCEPT, add the queue line:**
   `python .claude/skills/run-trace/scripts/queue.py add --from diego --ask "Change <id>: <one line>" --file brain/6-debrief/changes/<id>-proposal.md --choices "accept|trial 4 weeks|reject|reword"`
9. **Two loops at most.** After a second NEEDS MORE EVIDENCE the proposal goes to the owner
   with the open findings: add the same queue line, and start the ask with "Not enough
   evidence after 2 challenges:".

## Output format
`brain/6-debrief/changes/<id>-challenge.md`, in the reviewer verdict format of `review-verdict`:

    # Review of brain/6-debrief/changes/<id>-proposal.md
    - reviewer: diego
    - date: 2026-11-13
    - verdict: ACCEPT | NEEDS MORE EVIDENCE | REJECT
    - loop: 1

    ## Findings
    | # | Level | Where (exact quote) | Problem | Evidence (exact quote of the source or rule) |
    |---|---|---|---|---|
    | 1 | major | "in 3 of the last 8 pieces" | 2 of the 3 are the same day and format | edits/<slug>.md: "..." |

    ## Not checked
    - what you could not verify, and why ("nothing" is allowed)

    ## Checks run
    - Evidence: <what you recounted, and the count you found>
    - Another explanation: <each one you tried, and whether it holds>
    - Sample size: <n> pieces out of <n>. Real numbers or sample numbers
    - Conflict with rules.md or not-me.md: none, or the rule quoted
    - Reversible and small: yes, or what is missing

Levels: blocker (it leads to REJECT), major (it leads to NEEDS MORE EVIDENCE), minor.

## Check before you finish
- [ ] You recounted the evidence at its source, and your count is in the file.
- [ ] At least one other explanation was tried and written down.
- [ ] The sample size is a number, and "sample numbers" is said when it applies.
- [ ] `rules.md` and `not-me.md` were searched. A conflict is a REJECT.
- [ ] "Not checked" is filled in. The proposal file is untouched.
- [ ] On ACCEPT the queue line is added, with the four choices, and its id is in your message.

## Common mistakes
| Mistake | What happens | Do this instead |
|---|---|---|
| ACCEPT because the story is plausible | A wrong rule steers every future piece | Recount, then decide |
| Trusting the count of the proposal | The proposer checks herself | Open the cards and the diffs |
| "Most pieces" | Three pieces look like a law | The number, out of how many |
| Weighing a taste rule against the numbers | The owner becomes what the metric likes | Conflict means REJECT |
| Rewriting the proposal to make it pass | You become its second author | Findings only |
| A third challenge | Agents argue in circles | After loop 2 it goes to the owner |
