---
name: build-self
description: Build Step S, Self (who I am), of your own second brain. Launch it yourself with /build-self. It checks what exists in brain/1-self/, creates what is missing, asks the few questions it needs, calls Sofia, then Sacha and Serena together, then Sosie, with one review per agent, and ends on the Done when checklist of the Self step, ticked honestly. Use it first, before any other build skill, or again later to complete the Self. It never overwrites a file.
argument-hint: "[nothing, or the id of a new brain]"
user-invocable: true
---

# Build Step S: Self

The question of the step: who am I, how do I speak, what do I want, what do I refuse?
Everything the brain writes later rests on this step. Skip it and you get text that could have
been written by anybody.

## When to use
- The reader starts their own brain and launches `/build-self`. It is the first step.
- The Self exists and the reader wants to complete it: the skill only fills what is missing.
- Not to change one rule (say "it's not me" to Alfred). Not to switch to another brain.

You are the session the reader talks to. You never write a Self file yourself: each one has a
keeper. You check, you ask, you call the agents in order, you relay, you tick the list.

## Inputs
| Needed | Where | If it is missing |
|---|---|---|
| The active brain | `brain/BRAIN.md`, its `owner` is the reader | Step 1 creates it |
| The empty brain of the kit | `brains/_template/` | Say so and stop: there is nothing to copy |
| The reader's documents (optional) | `my-documents/` at the root of the folder, copied by step 1 into `brain/1-self/_raw/`: a CV, a bio, pieces they wrote, a transcript | The interview is enough to start |
| The team of the step | `.claude/agents/sofia.md`, `sacha.md`, `serena.md`, `sosie.md` | Name the missing file, skip its step |

`my-knowledge/` is not an input of this step. Courses, slides, a book, notebooks: they say what
the reader knows, not who the reader is. Never open that folder here, never copy from it. It is
filed at Step E (`/build-ears`).

## Steps
1. **Check the brain.** Read `brain/BRAIN.md`, show its name and its owner, and ask: "Is this
   the brain you want to build?" It is not, or there is none: start a new one.
   - Ask, in one message: a short id (lower case with dashes), the reader's first name, what the
     brain helps to produce in one line, the kinds of pieces (for example `post`).
   - One command creates the brain from `brains/_template/`, puts it in use and copies the files
     of `my-documents/` into `brain/1-self/_raw/` (copied, never moved, never overwritten):
     `python ops/tools/switch_brain.py new <id> --owner "<first name>" --produces "<one line>" --kinds "<kind>,<kind>" --name "<title>"`
   - The brain existed already: `python ops/tools/switch_brain.py documents` copies the files of
     `my-documents/` that are not yet in `_raw/`.
   - Then, always: `python ops/tools/library.py convert brain/1-self/_raw`. A PDF, a Word file
     or slides get a text copy next to them (`cv.pdf.txt`) that the agents can read. A file it
     cannot read is named with what to do: tell the reader, and go on.
   - Keep the list of the files copied for step 5.
2. **Check the kit.** The four agent files exist. One is missing: say which one, skip its
   step, and write "not built" on its lines of the checklist.
3. **Show what exists**, in one short table: `about-me.md`, `voice.md`, `pillars.md`,
   `rules.md`, `not-me.md`, `writing/<kind>.md` for each kind, the latest test of `_tests/`.
   A file that still holds only the guiding lines of the template counts as empty.
4. **Create what is missing, without content.** A missing file that has a model in
   `brains/_template/1-self/`: copy the model. Never overwrite. The content comes from the
   keeper of the file, not from you.
5. **Ask, in one message:**
   - "I copied <n> documents from `my-documents/` into `brain/1-self/_raw/`: <their names>. Which
     of them are pieces you are proud of?" None copied: "You can drop your CV and a few pieces you
     wrote in `my-documents/` now and tell me, or start with the interview alone."
   - "Is there a period that is not your voice, to leave out?"
   - "The short interview (6 questions, about 15 minutes) or the full one (12 questions, about
     45 minutes)?"
6. **Call the agents.** Four reviews in all, one per agent. Say at the start: "Four things to
   read: your portrait, your voice, your pillars, then three test pieces."
   1. Sofia: the interview, short or full as the reader chose. Show each question as she wrote
      it, send back each answer word for word. She ends with a proposal: the portrait and the
      limits. Review 1. On the reader's answer she saves `about-me.md`, `rules.md`, `not-me.md`.
   2. Sacha and Serena, in the same message (two Agent calls, they do not read each other's
      file): `voice.md` and `writing/<kind>.md` from the reader's own pieces and answers, and
      `pillars.md` from the portrait and from what the reader's own pieces are about. Reviews 2
      and 3 arrive together: the reader answers them in the order they like.
   3. Sosie: the Double test, on one subject from each of three pillars. Review 4 is step 7.
   **How a review goes.** The same four rules for every agent:
   - Say where to read: the file is shown on the screen under "Waiting for you", and give its
     path. Say the two answers: "approve", or "change:" followed by what to change.
   - Record the answer: `python .claude/skills/run-trace/scripts/queue.py resolve <id> --decision "<their words>"`.
   - A change the reader dictates is applied by the keeper of the file, word for word, and it
     counts as approved. No second review of the same file: show in three lines what changed.
     The reader can say "change:" again at any time, today or in a month.
   - With its first version an agent may ask three questions at most, each with the choice it
     made by default. A question the reader does not answer keeps its default. Never start a
     second round to polish. What stays open goes to the list of step 8.
7. **Read the three pieces with the reader.** "Which of these could you have written?" Their
   answer is the result of the test. The test judges the voice and the limits. A fact the pieces
   lacked about a subject (a figure, a lab, something the reader built) is not a gap of the
   Self: Sosie lists it apart, and it becomes knowledge to file at Step E. On FIX with a major
   gap of the Self: the keeper of that file completes it once, then Sosie runs once more. A
   minor gap goes to the list of step 8.
8. **Finish on the "Done when" checklist** of the step (see "Output format"), ticked honestly: a box is ticked
   only when a file or the reader's own answer proves it. Otherwise "not yet", and what it needs.
   Then ONE list "Open points": everything the agents left open, one line each. None of them
   blocks the next step.

## Output format
Your last message to the reader:

    Step S, Self
    Created:  <the files created, or "nothing, all was there">
    Written:  about-me.md (Sofia), voice.md and writing/<kind>.md (Sacha), pillars.md (Serena)
    Double:   likeness <score>, verdict <PASS, FIX or BLOCK>, brain/1-self/_tests/<file>

    Done when
    [x] A stranger who reads the Self files could introduce you correctly in one minute
        proof: the Double test, and your answer "yes, it sounds like me"
    [ ] voice.md contains at least 10 of your sentences, quoted exactly
        not yet: 6 found. Give Sacha four more pieces of yours
    [x] about-me.md holds at least 5 moments that only you lived
        proof: 7 moments in the section "Stories"
    [x] about-me.md is a portrait, not a catalogue
        proof: 62 lines, 5 lines under "Proof"
    [ ] rules.md contains at least 5 "never"
        not yet: 3 found. Tell Alfred two more, in your words
    [x] The Double test fooled you at least once
        proof: you said piece 2 could be yours

    Open points (none blocks the next step)
    - Sacha: the closing line of a post, default "a question to the reader". Say "change:" to set another
    - Sosie: the pieces needed facts about <subject>: file your material at Step E

    Next: /build-ears. Before it, put what you know (courses, slides, a book, notes) in my-knowledge/

In this kit the lived moments are in the section "Stories" of `about-me.md`, not in a file of
their own. The portrait is 80 lines or fewer: what the reader built or taught goes to the memory.

## Check before you finish
- [ ] Every Self file was written by its keeper, after the reader's answer. None by you.
- [ ] Each ticked box names its proof: a count, a quote or the reader's answer.
- [ ] No existing file was overwritten.
- [ ] Each agent had one review. No file was reviewed twice unless the reader asked.
- [ ] Nothing waits in the queue without the reader knowing it.
- [ ] `my-knowledge/` was not opened.
- [ ] The reader knows the next step.

## Common mistakes
| Mistake | What happens | Do this instead |
|---|---|---|
| Writing `voice.md` yourself to go faster | A generic voice, and no keeper | Call Sacha |
| Ticking every box | The reader trusts a Self that is thin | Count, quote, or write "not yet" |
| Adjectives ("warm, direct") | An agent cannot imitate an adjective | Sentences the reader really wrote |
| Skipping the limits | The brain proposes what embarrasses the reader | Five "never", from day one |
| The Double test before the approvals | It tests files the reader has not read | Approvals first |
| Building in the demo brain | The reader's Self mixes with someone else's | A new brain, with its own id |
| A new review after each change the reader dictates | Six rounds on one file, a step of two hours | The change is applied and approved. One review per agent |
| Everything the reader built listed in `about-me.md` | A catalogue no agent can imitate | Five lines of proof. The rest is knowledge: `my-knowledge/` |
| Reading the reader's courses and slides "to know them better" | The step never ends, and Ears is done twice | `my-documents/` only. The knowledge waits for Step E |
