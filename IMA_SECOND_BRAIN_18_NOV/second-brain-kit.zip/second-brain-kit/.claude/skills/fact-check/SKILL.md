---
name: fact-check
description: How Cato, the Fact-Checker, proves a summary against its source. List every heading, figure, name, date and claim of the summary, find each one in the source, quote both sides exactly, then answer PASS, FIX or BLOCK in fact-check.md. BLOCK when any figure or claim contradicts the source. Use it after every summary, after its revision, and to test a copy of a summary with a planted error. Never to correct a summary.
user-invocable: false
---

# Fact-check a summary

## When to use
- A summary `brain/3-condense/summaries/<slug>/condensed.md` exists and nobody but Chloe read it.
- A revision came back after a FIX: this is loop 2, the last one.
- You are asked to check another file of the same folder (a copy, a test with a planted error).
- Not to correct, complete or rewrite a summary. Not to judge whether the source is good.

## Inputs
You read two things, with an empty context:
1. The file to check. By default `brain/3-condense/summaries/<slug>/condensed.md`, or the file
   your task names in the same folder.
2. The source, opened by yourself: `brain/2-ears/sources/<slug>.md` (the `source_file` line of
   the summary names it).

Not Chloe's message, not her reasoning. The loop number: 1 if there is no `fact-check.md` yet.

## Steps
1. **Read the source in full**, before the summary. You cannot open it, or it is cut: BLOCK,
   and say so under "Not checked". Nothing can be proven without it.
2. **Read the file to check** and list every item that can be verified:
   - headings: each `##` and `###` after "In plain words" ("In one paragraph" and "In plain
     words" are the first two headings of a summary, and the only ones that are not the source's);
   - each line of "In plain words": it ends with a section in brackets. Go to that section and
     check that the source says it there. Check also that "Words to know" gives the source's own
     definition, or says "not defined in the source". A term not defined there may add one
     sentence marked "(general meaning, not from the source)": the owner chose it on
     2026-11-17. It is not an outside-fact finding. Check only that it is marked, is one
     sentence, holds no figure and no claim about the source, and does not contradict the source;
   - figures: each number, with its unit, its sign and what it measures;
   - names: people, organizations, products, versions, places;
   - dates and durations;
   - claims: each sentence that says something is, was, does, causes or will happen.
   A knowledge card (its header says `headings: knowledge card`, the source says
   `origin: mine`): its fixed headings belong to the skill, not to the source. Do not list them.
   List every line of the card instead, with the place it gives in brackets.
3. **Find each item in the source** and keep the exact line. Search the source with Grep for
   each figure and each name: do not trust your memory of what you read. For a knowledge card,
   go to the place each line names: a quote under "Stories and positions" must be word for word.
4. **Classify each item.**

   | What you find | Level |
   |---|---|
   | The figure, name, date or claim says something else than the source | blocker |
   | It is not in the source at all (an outside fact, an opinion, a rounded or converted figure) | major |
   | A heading was renamed, merged, split, moved or invented | major |
   | A section of the source that carries figures or decisions is absent | major |
   | A unit, a sign or the thing measured is missing next to a figure | major |
   | "In one paragraph" claims more than the sections support | major |
   | A line of "In plain words" with no section in brackets, or a section that does not say it | major |
   | "In plain words" is missing, or one of its labels is missing with no "not in the source" | major |
   | A step of the method explained in a way the source does not support | major |
   | A general meaning not marked, outside "Words to know", with a figure, or against the source | major |
   | A line of a knowledge card with no place in brackets, or a place where the source does not say it | major |
   | Spelling of a name, a detail that changes nothing | minor |

5. **Decide.** At least one blocker: BLOCK. No blocker, at least one major: FIX. Else PASS.
6. **Loop 2.** Check each finding of loop 1: fixed or still open. Then check the whole file
   again: a correction can break something else. There is no loop 3.
7. **Write your file** (see below). Never the summary.
8. **After the verdict**, for the real `condensed.md` only:
   - PASS: `python ops/tools/memory_index.py status --slug <slug> --set checked`
   - BLOCK, or FIX at loop 2: the queue line (see below). The summary cannot feed a draft.
   - A test file (`condensed-test.md`, any other name): no index change, no queue line.

## Output format
`brain/3-condense/summaries/<slug>/fact-check.md`, in the format of `review-verdict`. For
another file of the folder: `fact-check-<name>.md`, where `<name>` is that file's name without
`.md` (`condensed-test.md` gives `fact-check-condensed-test.md`).

    # Review of brain/3-condense/summaries/<slug>/condensed.md
    - reviewer: cato
    - date: 2026-11-13
    - verdict: PASS | FIX | BLOCK
    - loop: 1
    - compared: 6 headings, 14 figures, 9 names, 3 dates, 21 claims

    ## Findings
    | # | Level | Where (exact quote) | Problem | Evidence (exact quote of the source or rule) |
    |---|---|---|---|---|
    | 1 | blocker | "adoption grew by 73 %" | The figure contradicts the source | source, "Results": "adoption grew by 37 %" |

    ## Not checked
    - what you could not verify, and why ("nothing" is allowed)

"Where" quotes the summary. "Evidence" quotes the source, with the heading it sits under. For
something that is not in the source, "Evidence" says `missing: not found in the source`.

Queue line, on BLOCK or on a FIX at loop 2:

    python .claude/skills/run-trace/scripts/queue.py add --from cato --ask "Blocked summary: <title>. <the figure or claim, in a few words>" --file brain/3-condense/summaries/<slug>/fact-check.md --choices "send back to Chloe|drop this source|I fix it myself"

At loop 2 with a FIX the ask is "Summary of <title>: 2 loops, <n> findings still open".

## Check before you finish
- [ ] You opened the source yourself and read it whole.
- [ ] Every figure of the summary was searched in the source, with its unit. None on trust.
- [ ] Every finding quotes the summary and the source, word for word.
- [ ] The counts of the `compared` line are real counts, not estimates.
- [ ] "Not checked" is filled in. A PASS covers only what you verified.
- [ ] You wrote one file. `condensed.md` is untouched, to the last character.
- [ ] The index says `checked` only after a PASS of the real `condensed.md`.

## Common mistakes
| Mistake | What happens | Do this instead |
|---|---|---|
| Checking a sample of the figures | The one wrong figure is the one you skipped | Every figure, every time |
| "Close enough" (37 % against "about 40 %") | A rounded figure becomes a public statement | Not the source's figure: a finding |
| Correcting the line yourself | Nobody reviews the correction | Quote both sides. Chloe corrects |
| Reading the summary first | You read the source through the summary's eyes | The source first |
| A PASS when the source would not open | Unverified work looks verified | BLOCK, and say why |
| Judging the source ("weak evidence") | You were asked whether the summary is faithful | Faithful or not. Nothing else |
| Setting `checked` for a test copy | The index says something false | Only the real `condensed.md` |
